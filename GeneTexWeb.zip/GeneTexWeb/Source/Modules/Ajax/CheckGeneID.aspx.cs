﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using System.Text;

public partial class Modules_Ajax_CheckGeneID : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    [System.Web.Services.WebMethod]
    public static string CheckGeneID(string GeneID, string ResearchArea, string GeneIDErr)
    {
        try
        {
            ResearchArea = "";
            GeneIDErr = "";
            GeneID = GeneID.Replace("\r\n", ",");

            if (!string.IsNullOrEmpty(GeneID))
            {
                GeneIDErr = BLL.CheckGeneID(ref GeneID);
                ResearchArea = BLL.GetResearchArea(GeneID);
            }

            GeneID = "{\"GeneID\": \"" + GeneID.Replace("\r\n", "<br>") + "\"," +
                        "\"ResearchArea\": \"" + ResearchArea.Replace("\r\n", "<br>") + "\"," +
                        "\"GeneIDErr\": \"" + GeneIDErr.Replace("\r\n", "<br>") + "\"}";

            return GeneID;
        }
        catch(Exception ex)
        {
            return ex.Message;
        }
    }
}
