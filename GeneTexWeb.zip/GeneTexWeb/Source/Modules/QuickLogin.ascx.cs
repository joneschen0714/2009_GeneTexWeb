﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.Member;
using df = Icon.Definition;

public partial class Modules_QuickLogin : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //若已登入，show Member Info 及 Log out
        if (MemberInfo.CheckMemberLogin())
        {
            tMemberLogin.Visible = false;
            //讀取目前Member資料
            MemberInfo mi = df.OnlineMemberInfoList[df.PersonalMemberID.Value];
            lblLoginInfo.Text = "Welcome " + mi.FirstName + " " + mi.LastName;
        }
        else
        {
            if (Request.Cookies["autologin"] != null && Request.Cookies["autologin"].Values["account"] != null && Request.Cookies["autologin"].Values["password"] != null)
            {
                string strAcct = Request.Cookies["autologin"].Values["account"].ToString();
                string strPwd = Request.Cookies["autologin"].Values["password"].ToString();
                string strUrl = string.Format("~/WebPage/Member/Login.aspx?type=register&acct={0}&pwd={1}&autologin=Y", strAcct, strPwd);
                Response.Redirect(strUrl);
            }
            else
            {
                tMemberLogin.Visible = true;
                lblLoginInfo.Text = "";
            }
        }
    
    }

    //事件 - 登入按鈕
    protected void btnSignIn_Click(object sender, EventArgs e)
    {
        //設定帳號&密碼的Url參數
        Security sec = new Security();
        string strAcct = sec.EncryptQueryString(txtAccount.Text);
        string strPwd = sec.EncryptPassWord(txtPassword.Text);

        //跨頁執行自動登入程序
        string strUrl = string.Format("~/WebPage/Member/Login.aspx?type=register&acct={0}&pwd={1}", strAcct, strPwd);

        if (chAutoLogin.Checked)
            strUrl += "&autologin=Y";

        Response.Redirect(strUrl);
    }
}
