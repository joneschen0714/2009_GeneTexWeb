﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using Icon;
using Icon.DataBase;
using df = Icon.Definition;

public partial class Modules_ProductAttachment : System.Web.UI.UserControl
{
    DataBase db = new DataBase(Icon.Definition.WebConnStr);
    string strCatNo;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //若為產品內頁
            if (Request.Url.AbsoluteUri.Contains("ProductDetail.aspx"))
            {
                strCatNo = BLL.GetCatNo(Request.QueryString["CatNo"], Request.QueryString["CatalogItemID"]); //取得CatNo
                DataBind();
            }
        }
    }


    public override void DataBind()
    {
        //參數
        SqlParams param = new SqlParams();
        param.Add("CatNo", strCatNo);

        //資料欄位
        db.SqlParams = param;
        db.StrSQL = "SELECT pa.Id, pa.CatNo, pa.Name FileName, pa.Path FilePath, pa.Type FileType, pa.Description, pa.sort, CASE WHEN pc.Name IS NULL THEN '' ELSE pc.Name END SpecificityName, pc.s_Name SpecificitySName " +
                    "FROM ProductAttachment pa " +
                    "LEFT OUTER JOIN tb_ProductClass pc ON (pa.Specifity = pc.Id) AND (pc.Type='AntigenSpecies') " +
                    "WHERE (pa.CatNo = @CatNo) AND (pa.Enabled = 1)";
        DataTable dt = db.ExecuteDataTable();

        #region 建立檔案資訊
        DataTable dtSpecificity = dt.DefaultView.ToTable(true, "SpecificityName");
        if (dtSpecificity.Rows.Count > 0)
            palPicture.Visible = true;
        foreach (DataRow rowSpecificity in dtSpecificity.Rows)
        {
            string strSpecificity = rowSpecificity["SpecificityName"].ToString();

            #region Attachment Tab
            string strAttachmentID = "";
            if (strSpecificity == "")
            {
                strAttachmentID = "Attachment_none";
                liAttachmentTab.Text += "<a href='#' jTag='" + strAttachmentID.Replace(" ", "") + "' GroupTag='AttachmentTab' class='a2'>N/A</a>　";
            }
            else
            {
                strAttachmentID = "Attachment_" + strSpecificity;
                liAttachmentTab.Text += "<a href='#' jTag='" + strAttachmentID.Replace(" ", "") + "' GroupTag='AttachmentTab' class='a2'>" + strSpecificity + "</a>　";
            }
            #endregion

            #region Attachment Info
            string strItemContent = "";
            foreach (DataRow rowAttachItem in dt.Select("SpecificityName = '" + strSpecificity + "'"))
            {
                string strFileType = rowAttachItem["FileType"].ToString();
                if (strFileType == "Image")
                {
                    strItemContent += string.Format("<div style='border-Top:#000000 1px dashed;padding:10px 0 10px 0;'  align='center' ><img src='{1}' onclick=\"{3}\" /></div><b><label>{0}</label></b><br /><label>{2}</label>",
                                                              rowAttachItem["FileName"],
                                                              ResolveClientUrl("~/thumbnail.ashx?width=200&file=" + rowAttachItem["FilePath"]),
                                                              rowAttachItem["Description"],
                                                              "window.open('" + ResolveUrl(rowAttachItem["FilePath"].ToString()) + "')");
                }
                else if (strFileType == "File")
                {
                    string strFilePath = rowAttachItem["FilePath"].ToString();
                    FileInfo fi = new FileInfo(strFilePath);
                    string strPath = strFilePath.Replace("~", "").Replace(fi.Name, "");

                    strItemContent += string.Format("<div  style='border-Top:#000000 1px dashed;padding:10px 0 10px 0;' ><img src='{0}' /><a href='#' onclick=\"{1}\" class='a2'>{2}</a></div> {3}",
                                                              ResolveClientUrl("~/Images/Controls/save.png"),
                                                              "window.open('" + ResolveUrl("~/Controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(fi.Name)) + "');",
                                                              rowAttachItem["FileName"],
                                                              rowAttachItem["Description"]);
                }
            }
            liAttachmentContent.Text += string.Format("<div id='{1}' GroupTag='AttachmentTabContent'>{0}</div>", strItemContent, strAttachmentID.Replace(" ", ""));
            #endregion
        }
        #endregion
    }
}