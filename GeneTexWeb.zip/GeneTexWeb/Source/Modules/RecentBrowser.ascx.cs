﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using Icon;

public partial class Modules_RecentBrowser : System.Web.UI.UserControl
{
	protected void Page_Init(object sender, EventArgs e)
	{
		
	}

    protected void Page_Load(object sender, EventArgs e)
    {
		imgTitle.ImageUrl = Resources.Public.Img_RecentBrowser;
		this.Visible = false;
		ReadCookie();
    }

	public void ReadCookie()
	{
        string strVaule = "";
		int iCatItemID = 0;

		if (Request.Cookies["historybrowser"] == null) return;
		if (Request.Cookies["historybrowser"].Values["product"] == null) return;
		

		if (Request.Url.AbsoluteUri.Contains("ProductDetail.aspx"))
		{
			iCatItemID = BLL.GetCatalogItemID(Request.QueryString["CatNo"], Request.QueryString["CatalogItemID"]);
		}

		strVaule = Request.Cookies["historybrowser"].Values["product"].ToString();
		DataBase db = new DataBase(Icon.Definition.WebConnStr);

        if (strVaule != "")
        {
            Char[] spitchar = new Char[] { Convert.ToChar(",") };
			SqlParams param = new SqlParams();
			string[] cookievalue = strVaule.Split(spitchar);
			string strPara = "";
			string strCookies = "";
			string strWhere = " WHERE";
			for (int i = 0; i < cookievalue.Length; i++)
            {
				if (i < 6) //只抓前五個cookie
				{
					strPara = "Id"+i.ToString();
					param.Add(strPara, cookievalue[i]);
					strCookies += cookievalue[i] + ",";
					strPara = "@" + strPara;
					strWhere += " ci.Id = " + strPara + " OR";
				}
            }
			char[] charsToTrim = { ',' };
			Request.Cookies["historybrowser"].Values["product"] = strCookies.Trim(charsToTrim); //只留前五個cookie

			strWhere = strWhere.Remove(strWhere.Length - 3);

			db.SqlParams = param;
			string strSql = "SELECT ci.CatNo, p.ProductName, ci.Id AS CatalogItemID FROM CatalogItem ci" +
								" INNER JOIN Product p ON p.CatNo = ci.CatNo" + strWhere;
							
			db.StrSQL = strSql;
			DataTable dt = db.ExecuteDataTable();
			if (dt != null && dt.Rows.Count > 0)
			{
				if (iCatItemID > 0)
				{
					dt.DefaultView.RowFilter = "CatalogItemID <>" + iCatItemID.ToString();
					if (dt.Rows.Count == 1 && dt.Rows[0]["CatalogItemID"].ToString() == iCatItemID.ToString())
						this.Visible = false;
				}
				this.Visible = true;
				reptRecentBrowser.DataSource = dt;
				reptRecentBrowser.DataBind();
			}
			else
				this.Visible = false;
        }
    }

	protected void reptRecentBrowser_ItemDataBound(object sender, RepeaterItemEventArgs e)
	{
		if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
		{
			DataRowView rowView = (DataRowView)e.Item.DataItem;

			//取得控制項
			HyperLink hyProductName = (HyperLink)e.Item.FindControl("hyProductName");

			Label lblCatNo = (Label)e.Item.FindControl("lblCatNo");

			//設定值
			hyProductName.Text = rowView["ProductName"].ToString();
			hyProductName.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + rowView["CatalogItemID"].ToString();

			lblCatNo.Text = string.Format("{0}", rowView["CatNo"]);
		}
	}

}
