﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Modules_WebService_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /*
        bool bResult;

        //建立Product WebService物件
        ws_Product.Product p = new ws_Product.Product();
        p.Credentials = System.Net.CredentialCache.DefaultCredentials;


        //p.WriteProductType("GTX99996", "2207,2209,2211,2213,2309,2312,2314,4201,4202,4301,4302,4401,4402");

        
        //建立欲Upload的產品資訊 - Xml格式
        string strProductXml = "";
        strProductXml = "<ProductInfo><CatNo><![CDATA[GTX77817]]></CatNo><GeneID><![CDATA[]]></GeneID><OfficalName><![CDATA[NR4A1]]></OfficalName><Status><![CDATA[Active]]></Status><AuditStatus><![CDATA[Nopass]]></AuditStatus><ProductName><![CDATA[NR4A1 antibody]]></ProductName><ProductDescription><![CDATA[Rabbit Polyclonal Antibody to NR4A1]]></ProductDescription><Synonyms><![CDATA[NR4A1 HGNC:7980 GFRP1 HMR MGC9485 N10 NAK-1 NGFIB NP10 NUR77 TR3 NR4A1 NR4A1 nuclear receptor subfamily 4 group A member 1]]></Synonyms><ProductType><![CDATA[1,12]]></ProductType><Background><![CDATA[NR4A1 is a member of the steroid-thyroid hormone-retinoid receptor superfamily. Expression is induced by phytohemagglutinin in human lymphocytes and by serum stimulation of arrested fibroblasts. The encoded protein acts as a nuclear transcription factor. Translocation of the protein from the nucleus to mitochondria induces apoptosis. Three transcript variants encoding two distinct isoforms have been identified for this gene.  Variant (3), also known as TRC&beta;, contains multiple differences compared to variant 1. The resulting isoform (b) contains a shorter and distinct C-terminus compared to isoform a. ]]></Background><Clonality><![CDATA[Polyclonal]]></Clonality><CloneNo><![CDATA[]]></CloneNo><Host><![CDATA[Rabbit]]></Host><Isotype><![CDATA[IgG]]></Isotype><LightChain><![CDATA[]]></LightChain><Immunogen><![CDATA[Polyclonal antibody produced in rabbits immunized with a synthetic peptide corresponding to a region of human NR4A1.]]></Immunogen><AntigenSpecies><![CDATA[Human]]></AntigenSpecies><TestedApplications><![CDATA[IHC (Formalin-fixed paraffin-embedded sections), Western blot. The usefulness of this product in other applications has not been determined.]]></TestedApplications><ApplicationNote><![CDATA[WB: Suggested dilution at 1.0-10.0 ug/ml in 5% skim milk / PBS buffer. IHC-P: 4-8ug/ml. Optimal dilutions should be determined by end-user. ]]></ApplicationNote><Specificity><![CDATA[]]></Specificity><CrossReactivity><![CDATA[]]></CrossReactivity><SpeciesCrossReactivity><![CDATA[Human. Others not determined.]]></SpeciesCrossReactivity><PositiveControls><![CDATA[Jurkat cell lysate, human stomach and liver tissue]]></PositiveControls><Target><![CDATA[NR4A1]]></Target><CellularLocalization><![CDATA[]]></CellularLocalization><Conjugation><![CDATA[]]></Conjugation><ConjuationNote><![CDATA[]]></ConjuationNote><FormSupplied><![CDATA[Liquid]]></FormSupplied><Conc><![CDATA[1]]></Conc><Purification><![CDATA[Rabbit Ig G is purified by peptide affinity chromatography method.]]></Purification><PurificationNote><![CDATA[]]></PurificationNote><StorageBuffer><![CDATA[PBS with 2% sucrose]]></StorageBuffer><StorageInstruction><![CDATA[Store at -20 °C or below. Avoid repeat freeze-thaw cycles.]]></StorageInstruction><IsDryIce><![CDATA[False]]></IsDryIce><SupplierName><![CDATA[Aviva]]></SupplierName><SupplierCatNo><![CDATA[ARP31941_P050]]></SupplierCatNo><ApplicationAbbrev><![CDATA[IHC-P, WB]]></ApplicationAbbrev><Notes><![CDATA[For research use only not for diagnostic, human, or veterinary use.]]></Notes><ConcentrationUnit><![CDATA[mg/ml]]></ConcentrationUnit><PredictedTargetSize><![CDATA[Calculated MW = 34 kDa. Differences in calculated versus apparent molecular weight may be due to post-translational modifications or protein hydrophobicity. ]]></PredictedTargetSize><FullName><![CDATA[]]></FullName><Grade><![CDATA[OEM]]></Grade><Creater><![CDATA[9]]></Creater><Updater><![CDATA[9]]></Updater></ProductInfo>";

        bResult = p.UploadProductInfo(strProductXml); //上傳產品資訊, 回傳作業成功與否的狀態
        







        
        //圖片資訊 - Xml格式
        string strImg1 = "<Image>" +
                            "<CatNo>GTX12345678</CatNo>" +
                            "<Name>GTX100032 WB Image</Name>" +
                            "<FileName>aust_flag.jpg</FileName>" +
                            "<Type>Image</Type>" +
                            "<Description>Sample(30 μg of whole cell lysate)<br />A:HeLa S3(GTX14654)<br />10% SDS PAGE<br />GTX100032 diluted at 1:1000</Description>" +
                            "<Enabled>True</Enabled>" +
                            "<Sort>1</Sort>" +
                        "</Image>";

        //檔案轉成byte[]
        byte[] bImg1 = Setting.ConvertFileToByte("Y:\\GeneTexWeb\\Source\\Images\\Flag\\aust_flag.jpg");

        //把資訊跟圖片加入至object二維陣列
        object[][] oImages = new object[1][];
        oImages[0] = new object[] { strImg1, bImg1 };

        bResult = p.UploadAttachmentInfo(oImages); //上傳圖片資訊, 回傳作業成功與否的狀態
        */
    }
}
