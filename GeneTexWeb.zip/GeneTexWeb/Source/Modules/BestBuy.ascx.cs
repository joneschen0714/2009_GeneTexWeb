﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class Modules_BestBuy : System.Web.UI.UserControl
{
	protected void Page_Init(object sender, EventArgs e)
	{
		//多語系設定
		hyView.Text = Resources.Public.View;
        imgTitle.ImageUrl = Resources.Public.Home_Img_BestBuy;
	}


	protected void Page_Load(object sender, EventArgs e)
	{
		DataBind();
	}


	public override void DataBind()
	{
        DataTable dt = BLL.GetBestBuy();
		reptProduct.DataSource = dt;
		reptProduct.DataBind();
	}


	protected void reptProduct_ItemDataBound(object sender, RepeaterItemEventArgs e)
	{
		if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
		{
			DataRowView rowView = (DataRowView)e.Item.DataItem;

			//取得控制項
			HyperLink hyProductName = (HyperLink)e.Item.FindControl("hyProductName");
			Label lblTestedApplications = (Label)e.Item.FindControl("lblTestedApplications");
			Label lblCatNo = (Label)e.Item.FindControl("lblCatNo");
			Label lblPrice = (Label)e.Item.FindControl("lblPrice");

			//設定值
			hyProductName.Text = rowView["ProductName"].ToString();
			hyProductName.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + rowView["CatalogItemID"].ToString();
			lblTestedApplications.Text = rowView["ApplicationAbbrev"].ToString();
			lblCatNo.Text = rowView["CatNo"].ToString();
			lblPrice.Text = BLL.SetMoneyFormat("USD", rowView["PromotionPrice"].ToString(), 2);
		}
	}
}
