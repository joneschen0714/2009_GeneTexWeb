﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Modules_MemberMenu : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //設定SiteMapDataSource
            SiteMapDataSource smds = new SiteMapDataSource();
            smds.ShowStartingNode = false;
            smds.SiteMapProvider = "MenuProvider";

            string strTmp = "", strTmpColl = "", strItems = "";
            foreach (SiteMapNode node in smds.Provider.RootNode.ChildNodes) //循序讀取第一層主選單
            {
                //判斷是否為會員功能
                if (node.Title == "Member Info")
                {
                    //循序讀取第二層主選單
                    foreach (SiteMapNode subNode in node.ChildNodes)
                    {
                        string strParentVisible = subNode["Visible"];

                        //判斷是否顯示
                        if (strParentVisible != "false")
                        {
                            //累加選單項目
                            strItems += string.Format("<li><a href='{1}'><img src='{0}' />{2}</a></li>",
                                                        ResolveClientUrl(subNode["ImgSrc"]),
                                                        ResolveUrl(subNode.Url),
                                                        subNode.Title);
                        }
                    }
                }
            }

            liMemberMenu.Text = string.Format("<ul>{0}<ul>", strItems);
        }
    }
}
