﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class Modules_FreeTrialProduct : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //多語系設定
        hyMore.Text = Resources.Public.More;
        imgTitle.ImageUrl = Resources.Public.Home_Img_FreeTrial;
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        DataBind();
    }


    public override void DataBind()
    {
        DataTable dt = BLL.GetTop5FreeTrialProduct();

        reptFreeTrial.DataSource = dt;
        reptFreeTrial.DataBind();
    }


    protected void reptFreeTrial_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            //取得控制項
            HyperLink hyProductName = (HyperLink)e.Item.FindControl("hyProductName");
            Label lblTestedApplications = (Label)e.Item.FindControl("lblTestedApplications");
            Label lblCatNo = (Label)e.Item.FindControl("lblCatNo");

            //設定值
            hyProductName.Text = rowView["ProductName"].ToString();
            hyProductName.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID="+ rowView["CatalogItemID"].ToString();
            lblTestedApplications.Text = string.Format("({0})", rowView["ApplicationAbbrev"]);
            lblCatNo.Text = string.Format("{0}", rowView["CatNo"]);
        }
    }
}
