﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using Icon;
using df = Icon.Definition;

public partial class Modules_ProductsView : System.Web.UI.UserControl
{
    DataBase db = new DataBase(Icon.Definition.WebConnStr);


    protected void Page_Init(object sender, EventArgs e)
    {
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("Type", "A");

            CatalogID = BLL.GetCatalogID(htParams);

            DataTable dtView = BLL.GetFirstNodeResearchArea();
            if (dtView != null && dtView.Rows.Count > 0)
            {
                reptProductView.DataSource = BLL.SelectTop(10, dtView);
                reptProductView.DataBind();
            }
        }
    }


    protected void reptProductView_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            HyperLink hlName = (HyperLink)e.Item.FindControl("hlName");
            hlName.Text = string.Format("{0}", rowView["Name"]);

            if (CatalogID != "")
                hlName.NavigateUrl = string.Format("~/WebPage/Product/Catalog.aspx?CatalogID={0}&SearchArea={1}", CatalogID, rowView["SystemParamID"]);
        }
    }

    public string CatalogID
    {
        get
        {
            if (ViewState["CatalogID"] != null)
                return ViewState["CatalogID"].ToString();
            else
                return "";
        }
        set { ViewState["CatalogID"] = value; }
    }
}
