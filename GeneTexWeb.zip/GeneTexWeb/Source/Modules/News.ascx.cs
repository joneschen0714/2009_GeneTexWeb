﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using df = Icon.Definition;

public partial class Modules_News : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //語系設定
        hyMore.Text = Resources.Public.More;
        hyViewDetail.Text = Resources.Public.ViewDetail;
        imgTitle.ImageUrl = Resources.Public.Home_Img_News;
        lblNoData.Text = Resources.ErrMsg.NoData;
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        DataBind();
    }


    public override void DataBind()
    {
        DataRow rowNews = BLL.GetTop1News();

        if (rowNews != null) //若有資料
        {
            lblSubject.Text = rowNews["Name"].ToString();
            ImgNews.ImageUrl = rowNews["ImgSrc"].ToString();
            ImgNews.Style.Add("cursor", "pointer");
            ImgNews.Attributes.Add("onclick", string.Format("location.href='{0}'", ResolveClientUrl("~/WebPage/Public/NewsDetail.aspx?Type=News&NewsID=" + rowNews["Id"].ToString())));

            liContent.Text = rowNews["Description"].ToString();
            hyViewDetail.NavigateUrl = "~/WebPage/Public/NewsDetail.aspx?Type=News&NewsID=" + rowNews["Id"].ToString();
            palNews.Visible = true;
        }
        else
        {
            palEmpty.Visible = true;
        }
    }
}
