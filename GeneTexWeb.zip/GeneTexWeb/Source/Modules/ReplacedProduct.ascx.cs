﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class ReplacedProduct : System.Web.UI.UserControl
{
	protected void Page_Init(object sender, EventArgs e)
	{
	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			//若為產品內頁
			imgTitle.ImageUrl = Resources.Public.Img_ReplacedProduct;
			if (Request.Url.AbsoluteUri.Contains("ProductDetail.aspx"))
			{
				string strCatNo = BLL.GetCatNo(Request.QueryString["CatNo"], Request.QueryString["CatalogItemID"]); //取得CatNo
				DataTable dt = BLL.GetProductRelated(strCatNo, "Replaced");

				if (dt != null && dt.Rows.Count > 0)
				{
					reptReplacedProduct.DataSource = dt;
					reptReplacedProduct.DataBind();
				}
				else
					this.Visible = false;
			}
		}
	}

	protected void reptReplacedProduct_ItemDataBound(object sender, RepeaterItemEventArgs e)
	{
		if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
		{
			DataRowView rowView = (DataRowView)e.Item.DataItem;

			//取得控制項
			HyperLink hyProductName = (HyperLink)e.Item.FindControl("hyProductName");

			Label lblPrice = (Label)e.Item.FindControl("lblPrice");
			Label lblCatNo = (Label)e.Item.FindControl("lblCatNo");

			//設定值
			hyProductName.Text = rowView["ProductName"].ToString();
			hyProductName.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + rowView["CatalogItemID"].ToString();

			decimal dPricePromotionPrice = Convert.ToDecimal(rowView["PromotionPrice"]);
			decimal dPrice = Convert.ToDecimal(rowView["Price"]);

			if (dPricePromotionPrice > dPrice || dPricePromotionPrice == 0)
			{
				dPricePromotionPrice = dPrice;
			}

			lblPrice.Text = BLL.SetMoneyFormat(rowView["CurrencyName"].ToString(), dPricePromotionPrice.ToString(), Convert.ToInt16(rowView["DecimalNum"]));
			lblCatNo.Text = string.Format("{0}", rowView["CatNo"]);

		}
	}
}
