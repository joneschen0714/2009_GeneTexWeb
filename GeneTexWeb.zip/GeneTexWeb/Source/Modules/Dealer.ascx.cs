﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using System.Data.SqlClient;

public partial class Modules_Dealer : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        imgTitle.ImageUrl = Resources.Public.Home_Img_Distributors;
       
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
            InitLocalDealer();
    }

    private void InitLocalDealer()
    {
         string strUserIP = this.GetClientIP();

        //string strUserIP = "121.14.0.30";
        string strPath = AppDomain.CurrentDomain.RelativeSearchPath + "\\";
        IPInfo.IPInfo ipinfo = new IPInfo.IPInfo(strPath);
        bool bIsOK = ipinfo.GetIPInfo(strUserIP);
        string strContent = string.Empty;
        if (bIsOK)
        {
            string countryCode = ipinfo.CountryCode;
            Response.Write(countryCode);
            Hashtable htParams = new Hashtable();
            htParams.Add("UnderCountryCode", countryCode);
            DataTable dtDealers = Icon.BLL.GetLocalDealers(htParams);
            if (dtDealers != null && dtDealers.Rows.Count > 0)
            {
                strContent = "<ul>";                
                foreach (DataRow dr in dtDealers.Rows)
                {
                    strContent += "<li>  <a href=" + dr["Url"].ToString() + ">" + dr["Name"].ToString() + "</a></li>";
                    //strContent += "<li>" + dr["Address"].ToString() + "</li>";
                    //strContent += "<li>" + dr["City"].ToString() + dr["County"].ToString() + "</li>";
                    //strContent += "<li>" + dr["State"].ToString() + dr["Country"].ToString() + dr["Zip"].ToString() + "</li>";
                    //strContent += "<li> Tel: " + dr["Tel"].ToString() + "</li>";
                    //strContent += "<li> Fax: " + dr["Fax"].ToString() + "</li>";
                    //strContent += "<li> E-mail: " + dr["Email"].ToString() + "</li>";
                }
                strContent += "</ul>";
            }
            liDealer.Text = strContent;
        }
        else
            divLocalDealer.Visible = false;
    }

    private string GetClientIP()
    {
        string ip=string.Empty;
        if (HttpContext.Current.Request.ServerVariables["HTTP_VIA"] != null)
        {
            ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (!string.IsNullOrEmpty(ip))
            {
                return ip.Split(new char[] { ',' })[0];
            }
            else
            {
                return HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
        }
        else
        {
            return HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}