﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon.DataBase;
using Icon;

public partial class Modules_PromotionNews : System.Web.UI.UserControl
{
    DataBase db = new DataBase(Icon.Definition.WebConnStr);
    string strCulture;

    protected void Page_Init(object sender, EventArgs e)
    {
        //多語系設定
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系
        DataBind();
    }


    public override void DataBind()
    {
        DataTable dtNews = BLL.GetTopNPromotionNews(3);

        if (dtNews.Rows.Count > 0)
        {
            reptPromotion.DataSource = dtNews;
            reptPromotion.DataBind();
        }
       
    }


    protected void reptPromotion_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        DataRowView rowView = (DataRowView)e.Item.DataItem;

        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) //資料列
        {
            HyperLink hlPromotion = (HyperLink)e.Item.FindControl("hlPromotion");
            Label lblDate = (Label)e.Item.FindControl("lblDate");
            DateTime dtStart = Convert.ToDateTime(rowView["StartDate"]);

            //設定值
            hlPromotion.Text = rowView["Name"].ToString();
            hlPromotion.NavigateUrl = "~/WebPage/Product/PromotionDetail.aspx?PromotionID=" + rowView["ID"].ToString(); //連結促銷訊息內文

            lblDate.Text = string.Format(" {0}. {1}", dtStart.ToString("MMM"), dtStart.Day);
        }
    }

}
