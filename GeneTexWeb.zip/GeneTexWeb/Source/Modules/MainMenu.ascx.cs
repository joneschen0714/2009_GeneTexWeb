﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;

public partial class Modules_MainMenu : System.Web.UI.UserControl
{
    string strCulture;

    protected void Page_Load(object sender, EventArgs e)
    {
        strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系

        //取得當地國家的SiteMapDataSource
        SiteMapDataSource smds = Definition.SiteMapDataSource;
        smds.ShowStartingNode = false;

        #region 第一層主選單
        string strTmp = "", strTmpColl = "";
        foreach (SiteMapNode node in smds.Provider.RootNode.ChildNodes) //循序讀取第一層主選單
        {
            //－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－
            #region 第二層動態選單
            string strSubMenu = "", strSubItem = "", strSubItemColl = "";
            foreach (SiteMapNode subNode in node.ChildNodes) //循序讀取第二層主選單
            {
                //判斷是否顯示子節點
                string strVisible = subNode["Visible"];
                if (strVisible != "false")
                {
                    //動態子選單項目
                    strSubItem = "<li><a href='{Url}'>{Text}</a></li>"
                                  .Replace("{Url}", ResolveUrl(subNode.Url))
                                  .Replace("{Text}", subNode.Title);

                    strSubItemColl += strSubItem; //累加動態子選單項目
                }
            }

            //組成子選單項目
            if (strSubItemColl != "")
            {
                strSubMenu = "<div class='divSubMenu'><ul class='subMenu'>{SubMainMenuItems}</ul></div>"
                            .Replace("{SubMainMenuItems}", strSubItemColl); //組成子選單集合項目
            }
            #endregion
            //－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－

            //判斷是否顯示主節點
            string strParentVisible = node["Visible"];
            if (strParentVisible != "false")
            {
                string strUrl = (node.Url == "" ? "" : ("href='" + ResolveUrl(node.Url) + "'"));
                strTmp = "<li><a class='MainMenuTrigger' {Url}>{Title}</a>{SubMainMenu}</li>"
                       .Replace("{Title}",node.Title)
                       .Replace("{Url}", strUrl)
                       .Replace("{SubMainMenu}", strSubMenu);

                strTmpColl += strTmp;
            }
        }

        liMainMenu.Text = "<ul id='p7menubar'>{MenuMenuItem}</ul>"
                        .Replace("{MenuMenuItem}", strTmpColl);
        #endregion
    }
}
