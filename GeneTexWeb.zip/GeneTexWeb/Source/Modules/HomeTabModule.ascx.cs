﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;

public partial class Modules_HomeTabModule : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CreateNewProduct();
            CreateResearchArea();
            CreatePromotionNews();
        }
    }

    private void CreateNewProduct()
    {
        DataTable dt = BLL.GetTopNewProducts();
        if (dt != null && dt.Rows.Count > 0)
        {
            DataTable dtNewProduct = BLL.SelectTop(6, dt);

            lblNewProductCount.Text = string.Format("{0} New Products in {1}", dt.Rows.Count, DateTime.Today.ToString("MMM", CultureInfo.CreateSpecificCulture("en-US")));

            foreach (DataRow rowNewProduct in dtNewProduct.Rows)
            {
                TableRow tbRow = new TableRow();
                TableCell cellCatNo = new TableCell();
                TableCell cellSpace = new TableCell();
                TableCell cellProductName = new TableCell();

                tbRow.Height = 20;
                cellSpace.Width = 10;

                string strUrl = ResolveClientUrl("~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + rowNewProduct["CatalogItemID"].ToString());

                cellCatNo.Text = string.Format("<a href=\"{0}\" class='fontStyle00'>{1}</a>", strUrl, rowNewProduct["CatNo"]);
                cellProductName.Text = string.Format("<div class='TextEllipsis' style='width:115px;' title='{0}'><nobr>{0}</nobr></div>", rowNewProduct["ProductName"]);

                tbRow.Cells.Add(cellCatNo);
                tbRow.Cells.Add(cellSpace);
                tbRow.Cells.Add(cellProductName);

                tbNewProduct.Rows.Add(tbRow);
            }

            linkNewProductMore.NavigateUrl = "~/WebPage/Product/Catalog.aspx?CatalogID=" + dt.Rows[0]["CatalogID"].ToString();
        }
    }

    private void CreateResearchArea()
    {
        Hashtable htParams = new Hashtable();
        htParams.Add("Type", "A");

        string strCatalogID = BLL.GetCatalogID(htParams);

        DataTable dtView = BLL.GetFirstNodeResearchArea();
        DataTable dtResearch = BLL.SelectTop(7, dtView);

        if (dtView != null && dtResearch.Rows.Count > 0)
        {
            foreach (DataRow row in dtResearch.Rows)
            {
                TableRow tbRow = new TableRow();
                TableCell cellResearch = new TableCell();

                tbRow.Height = 19;

                string strUrl = ResolveClientUrl("~/WebPage/Product/Catalog.aspx?CatalogID=" + strCatalogID + "&Research=" + row["SystemParamID"].ToString());

                cellResearch.Text = string.Format("<a href=\"{1}\" class='fontStyle00'>{0}</a>",
                                                    row["Name"],
                                                    strUrl);

                tbRow.Cells.Add(cellResearch);
                tbResearchArea.Rows.Add(tbRow);
            }
        }

        linkResearchMore.NavigateUrl = "~/WebPage/Product/ResearchAreaPage.aspx";
    }

    private void CreatePromotionNews()
    {
        DataTable dtNews = BLL.GetTopNPromotionNews(3);

        if (dtNews.Rows.Count > 0)
        {
            foreach (DataRow row in dtNews.Rows)
            {
                TableRow tbRow = new TableRow();
                TableCell cellPromotion = new TableCell();

                tbRow.Height = 20;

                string strUrl = ResolveClientUrl("~/WebPage/Product/PromotionDetail.aspx?PromotionID="+row["ID"].ToString());
                DateTime dtStart = Convert.ToDateTime(row["StartDate"]);

                cellPromotion.Text = string.Format("<a href=\"{1}\" class='fontStyle00'>{0}</a><label class='fontStyle03'>{2}</label>",
                                                    row["Name"],
                                                    strUrl,
                                                    string.Format(" {0}. {1}", dtStart.ToString("MMM"), dtStart.Day));

                tbRow.Cells.Add(cellPromotion);
                tbPromotionNews.Rows.Add(tbRow);
            }
        }
    }
}
