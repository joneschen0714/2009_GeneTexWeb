﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using df = Icon.Definition;

public partial class Modules_WelcomeMsg : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //語系設定
        imgTitle.ImageUrl = Resources.Public.Home_Img_Welcome;
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        DataBind();
    }


    public override void DataBind()
    {
        DataRow rowNews = BLL.GetTop1WelcomeNews();

        if (rowNews != null) //若有資料
        {
            //ImgNews.ImageUrl = "~/thumbnail.ashx?max=100&file=" + rowNews["ImgSrc"].ToString();
            ImgNews.ImageUrl = rowNews["ImgSrc"].ToString();
            liContent.Text = rowNews["Content"].ToString();
            palNews.Visible = true;
        }
    }
}