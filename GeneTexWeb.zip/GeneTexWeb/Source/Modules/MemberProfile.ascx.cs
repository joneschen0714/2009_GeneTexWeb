﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class Modules_MemberProfile : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //控制項顯示文字設定 & 相關設定
            lblAccount.Text = "User Name *";
            lblTitle.Text = "Prefix *";
            lblFirstName.Text = "First Name *";
            lblLastName.Text = "Last Name *";
            lblEmail.Text = "Email Address *";
            lblPhoneExt.Text = "Phone & Ext";
            lblFax.Text = "Fax";
            lblInstitution.Text = "Institution";
            lblPosition.Text = "Position *";
            //lblResearchArea.Text = "Research area *";
            lblPassword.Text = "Password *";
            lblReEnterPassword.Text = "ReEnter Password *";
            lblPasswordQ.Text = "Password Question *";
            lblPasswordA.Text = "Password Answer *";

            lblAddress1.Text = "Address1";
            lblAddress2.Text = "Address2";
            lblCity.Text = "City";
            lblState.Text = "State/Province";
            lblZip.Text = "Zip";
            lblCountry.Text = "Country";

            //設定DropDownList資料來源
            ddlPasswordQ.DataSource = BLL.GetSystemParams("PasswordQ");
            ddlPasswordQ.DataBind();
            ddlPasswordQ.Items.Insert(0, new ListItem("--select question--", "0"));

            ddlTitle.DataSource = BLL.GetSystemParams("Title");
            ddlTitle.DataBind();
            ddlTitle.Items.Insert(0, new ListItem("--select prefix--", "0"));

            ddlPosition.DataSource = BLL.GetSystemParams("Position");
            ddlPosition.DataBind();
            ddlPosition.Items.Insert(0, new ListItem("--select position--", "0"));

            //ddlResearchArea.DataSource = BLL.GetSystemParams("Research area");
            //ddlResearchArea.DataBind();
            //ddlResearchArea.Items.Insert(0, new ListItem("--select research area--", "0"));

            DataTable dtCountry = BLL.GetCountry();
            dtCountry.DefaultView.RowFilter = "CountryCode<>'TW'";
            ddlCountry.DataSource = dtCountry.DefaultView.ToTable();
            ddlCountry.DataBind();
            ddlCountry.Items.Insert(0, new ListItem("--select country--", ""));
        }
        
    }

    //驗証帳號是否可用
    protected void btnCheckAccount_Click(object sender, ImageClickEventArgs e)
    {
        //設定變數
        string strAccount = txtAccount.Text.Trim();

        //參數集合
        Hashtable htParams = new Hashtable();
        htParams.Add("Account", strAccount);

        //呼叫邏輯層
        string strMessage;
        BLL.CheckMemberAccount(out strMessage, htParams);

        //設定回傳狀態 & 訊息
        lblCheckAccountResult.Text = strMessage;
    }

    /// <summary>
    /// 驗証資料格式
    /// </summary>
    public bool CheckMemberInfo(ref string strMessage)
    {
        //取得密碼
        string strPwd = txtPassword.Text.Trim();
        string strRePwd = txtReEnterPassword.Text.Trim();

        if (strPwd != strRePwd)
        {
            strMessage = "The ReEntered Password does not match your Password.  Please try again.";
            return false;
        }

        return true;
    }

    /// <summary>
    /// 取得MemberInfo物件
    /// </summary>
    public MemberInfo GetMemberProfile()
    {
        //設定MemberInfo物件
        MemberInfo mi = new MemberInfo();
        mi.Account = txtAccount.Text.Trim();
        mi.Email = txtEmail.Text.Trim();
        mi.Institution = txtInstitution.Text.Trim();
        mi.FirstName = txtFirstName.Text.Trim();
        mi.LastName = txtLastName.Text.Trim();
        mi.MemberID = df.PersonalMemberID.HasValue ? df.PersonalMemberID : null;
        mi.Password = txtPassword.Text.Trim();
        mi.PasswordA = txtPasswordA.Text.Trim();
        mi.PasswordQ = ddlPasswordQ.SelectedValue;
        mi.Position = ddlPosition.SelectedValue;
        //mi.ResearchArea = ddlResearchArea.SelectedValue;
        mi.Title = ddlTitle.SelectedValue;
        mi.Address1 = txtAddress1.Text.Trim();
        mi.Address2 = txtAddress2.Text.Trim();
        mi.City = txtCity.Text.Trim();
        mi.County = txtCounty.Text.Trim();
        mi.State = txtState.Text.ToUpper().Trim();
        mi.Zip = txtZip.Text.Trim();
        mi.Country = ddlCountry.SelectedValue;
        mi.Phone = txtPhone.Text.Trim();
        mi.Ext = txtExt.Text.Trim();
        mi.Fax = txtFax.Text.Trim();

        mi.ResearchGeneID = txtResearchGeneID.Text;
        mi.ResearchArea = txtResearchAreaName.Text;

        return mi;
    }


    /// <summary>
    /// 設定會員資料
    /// </summary>
    public void SetMemberInfo(MemberInfo mi)
    {
        //設定會員資料
        txtAccount.Text = mi.Account;
        txtEmail.Text = mi.Email;
        txtInstitution.Text = mi.Institution;
        txtFirstName.Text = mi.FirstName;
        txtLastName.Text = mi.LastName;
        txtPasswordA.Text = mi.PasswordA;
        ddlPasswordQ.SelectedValue = mi.PasswordQ;
        ddlPosition.SelectedValue = mi.Position;
        //ddlResearchArea.SelectedValue = mi.ResearchArea;
        ddlTitle.SelectedValue = mi.Title;
        txtAddress1.Text = mi.Address1;
        txtAddress2.Text = mi.Address2;
        txtCity.Text = mi.City;
        txtCounty.Text = mi.County;
        txtState.Text = mi.State;
        txtZip.Text = mi.Zip;
        ddlCountry.SelectedValue = mi.Country;
        txtPhone.Text = mi.Phone;
        txtExt.Text = mi.Ext;
        txtFax.Text = mi.Fax;

        txtResearchGeneID.Text = mi.ResearchGeneID;
        txtResearchAreaName.Text = mi.ResearchArea;

    }

    /// <summary>檢查會員的地址正確性</summary>
    public bool CheckMemberAddress(ref string strMessage)
    {
        txtCounty.Text = ""; //清除County記錄
        MemberInfo mi = GetMemberProfile(); //取得輸入的資料

        if (mi.Country == "US") //若國家為US
        {
            if (mi.State.ToUpper() == "CALIFORNIA") { mi.State = "CA"; } //若加州為全名，則改為縮寫
            DataTable dtState = BLL.GetAddressInfo(mi.Country, mi.State, null, null); //取得選擇的國家區域資料

            if (dtState.Rows.Count > 0) //若有State資料
            {
                if (mi.State == "CA") //若State為加州
                {
                    //檢查是否有找到City
                    DataRow[] Citys = dtState.Select("CityName='" + mi.City + "'");
                    if (Citys.Length > 0)
                    {
                        txtCounty.Text = Citys[0]["CountyName"].ToString();
                    }
                    else
                    {
                        strMessage = "City is not found!";
                        return false;
                    }
                }
            }
            else
            {
                strMessage = "State is not found!";
                return false;
            }
        }

        return true;
    }
}