﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Xml;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class Modules_SiteMapPath : System.Web.UI.UserControl
{
    //全域變數
    string M_strPage = "", M_NavigatorHtml = "";
    int iItemIndex = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //變數
            string strPath = Request.Url.PathAndQuery;
            string strRoot = Request.ApplicationPath;
            M_strPage = strPath.Replace(strRoot, ""); //頁面名稱

            //載入導覽列Xml
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(Server.MapPath("~/XmlFile/Navigator.xml"));

            XmlNode CurrentNode = GetCurrentNode(xmlDoc.LastChild); //取得目前節點
            SetCurrentNodeSession(CurrentNode);
            GetNavigatorPath(CurrentNode);
            liNavigator.Text = M_NavigatorHtml;
            NameValueCollection na = new NameValueCollection();
        }
    }

    //取得目前節點
    private XmlNode GetCurrentNode(XmlNode _Node)
    {
        XmlNode returnNode = null;

        if (M_strPage.Contains(_Node.Attributes["Url"].Value))
        {
            returnNode = _Node;
        }
        else
        {
            foreach (XmlNode childNode in _Node.ChildNodes)
            {
                if (childNode.Name == "Node")
                {
                    returnNode = GetCurrentNode(childNode);
                    if (returnNode != null) { break; }
                }
            }
        }

        return returnNode;
    }

    //組成導覽列
    private void GetNavigatorPath(XmlNode _CurrentNode)
    {
        string strUrl = _CurrentNode.Attributes["Url"].Value;
        string strNewUrl = Definition.NavigatorList[strUrl];
        if (!string.IsNullOrEmpty(strNewUrl))
        {
            Definition.NavigatorList.Set(strUrl, strNewUrl);
            strUrl = strNewUrl;
        }
        else
        {
            Definition.NavigatorList.Set(strUrl, ResolveClientUrl("~" + strUrl));
            strUrl = ResolveClientUrl("~" + strUrl);
        }

        //增加巡覽項目
        string strTitle = GetNodeName(_CurrentNode);
        if (iItemIndex == 0) { lblTitle.Text = strTitle; }
        iItemIndex++;

        M_NavigatorHtml = (string.Format("<a href=\"{0}\">{1}</a>", strUrl, strTitle) + M_NavigatorHtml);

        //往上一層節點遞迴
        XmlNode ParentNode = _CurrentNode.ParentNode;
        if (ParentNode.NodeType != XmlNodeType.Document)
        {
            M_NavigatorHtml = " / " + M_NavigatorHtml;
            GetNavigatorPath(ParentNode);
        }
    }

    //轉換Navigator名稱
    private string GetNodeName(XmlNode _Node)
    {
        string strReturn = "";
        foreach (XmlNode childNode in _Node.ChildNodes)
        {
            if (childNode.Name == "Param")
            {
                //節點屬性
                string strParams = childNode.Attributes["Params"].Value;
                string strFormatStr = childNode.Attributes["FormatString"].Value;
                string strName = childNode.Attributes["Name"].Value;
                string strSqlstring = childNode.Attributes["SqlString"].Value;

                //驗証網址參數
                bool bParamCheck = true;
                List<object> listParam = new List<object>();
                foreach (string strParam in strParams.Split(','))
                {
                    string strUrl = Definition.NavigatorList.Get(_Node.Attributes["Url"].Value);
                    string strParamValue = Setting.GetStringUrlParam(strUrl, strParam);
                    listParam.Add(strParamValue);
                    if (string.IsNullOrEmpty(strParamValue)) { bParamCheck = false; };
                }

                //若參數驗証通過
                if (bParamCheck)
                {
                    //組成與取代參數
                    strFormatStr = strFormatStr.Replace("{N}", strName);
                    if (strFormatStr.Contains("{S}"))
                    {
                        string strSQL = string.Format(strSqlstring, listParam.ToArray());
                        string strDbName = BLL.GetNavigatorName(strSQL);
                        strFormatStr = strFormatStr.Replace("{S}", strDbName);
                    }
                    strReturn = string.Format(strFormatStr, listParam.ToArray());
                    break;
                }
            }
        }

        //若空值則以預設值取代
        if (strReturn == "") { strReturn = _Node.Attributes["Name"].Value; }
        return strReturn;
    }

    //設定目前節點
    private void SetCurrentNodeSession(XmlNode _CurrentNode)
    {
        string strKey = _CurrentNode.Attributes["Url"].Value;
        string strUrl = Request.Url.ToString();
        NameValueCollection naviList = Definition.NavigatorList;
        string strVal = naviList.Get(strKey);

        //設定記錄
        if (string.IsNullOrEmpty(strVal))
            naviList.Add(strKey, strUrl);
        else
            naviList.Set(strKey, strUrl);
    }
}