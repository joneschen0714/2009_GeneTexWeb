﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class Modules_SubMenu : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //取得當地國家的SiteMapDataSource
        SiteMapDataSource smds = Definition.SiteMapDataSource;
        smds.ShowStartingNode = true;

        SiteMapNode smn = GetParentNodeUrl(smds.Provider.CurrentNode);

        #region 第一層主選單
        string strTmpTable = "<table id='modulesCommon'><tr><td class='tdHead'>" + smn.Title + "</td></tr>";
        string strTmp = "";
        foreach (SiteMapNode node in smn.ChildNodes) //循序讀取第一層主選單
        {
            //判斷是否顯示
            string strVisible = node["Visible"];
            if (strVisible != "false")
            {
                strTmp += "<tr><td class='tdMenu'><a href='{Url}'>{Text}</a></td></tr>"
                       .Replace("{Url}", ResolveUrl(node.Url))
                       .Replace("{Text}", node.Title);
            }
        }

        if (strTmp != "") { liSubMenu.Text = strTmpTable + strTmp + "</table>"; }
        else { this.Visible = false; }

        #endregion
    }


    //遞迴 - 取第二層連結
    private SiteMapNode GetParentNodeUrl(SiteMapNode node)
    {
        SiteMapNode smn = null;
        if (node.ParentNode.Title != "Home")
            smn = GetParentNodeUrl(node.ParentNode);
        else
            smn = node;

        return smn;
    }
}