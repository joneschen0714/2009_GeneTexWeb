﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using df = Icon.Definition;

public partial class Modules_PromotionSlides : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //資料參數
        Hashtable htParams = new Hashtable();
        htParams.Add("IsSlide", 1);

        //呼叫邏輯層
        DataTable dtNews = BLL.GetAllNews(htParams);


        for (int i = 0; i < 5; i++)
        {
            int iIndex = i + 1;
            if (i < dtNews.Rows.Count)
            {
                DataRow rowItem = dtNews.Rows[i];

                liItemsNum.Text += " <img jTag=\"PromotionSlideNumber\" title=\"{Title}\" src=\"{NumberItem}\" NewsID='{NewsID}' TimeSpan='{TimeSpan}' style='cursor:pointer;' /> "
                                .Replace("{NumberItem}", ResolveClientUrl("~/Images/Images/Slide/" + iIndex + ".jpg"))
                                .Replace("{Title}", rowItem["Name"].ToString())
                                .Replace("{NewsID}", rowItem["Id"].ToString())
                                .Replace("{TimeSpan}", rowItem["SlideTimeSpan"].ToString());
            }
            else
            {
                liItemsNum.Text += " <img src=\"{NumberItem}\" /> "
                                .Replace("{NumberItem}", ResolveClientUrl("~/Images/Images/Slide/" + iIndex + "_unvisible.jpg"));
            }
        }
    }
}