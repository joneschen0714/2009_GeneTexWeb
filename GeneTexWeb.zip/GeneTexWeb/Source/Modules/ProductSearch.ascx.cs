﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Modules_ProductSearch : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css & Script
        //Page.Header.Controls.Add(new LiteralControl("<link type='text/css' rel='stylesheet' href='" + ResolveClientUrl("~/Css/jquery.contextMenu.css") + "' />"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ProductSearchKeyWord"] != null)
        {
            txtFreeText.Text = Session["ProductSearchKeyWord"].ToString();　//回填檢索文字
            Session.Remove("ProductSearchKeyWord"); //清除紀錄
        }

        //預設Enter按鈕 & 預設焦點
        txtFreeText.Attributes.Add("onkeydown", "changeFocusControl('" + btnProductSearch.ClientID + "', event)");
    }


    //產品檢索
    /*
    protected void btnProductSearch_Click(object sender, EventArgs e)
    {
        string strSearch = txtFreeText.Text;

        Session.Add("ProductSearchKeyWord", strSearch); //紀錄查詢至Session
        Response.Redirect("~/WebPage/Product/Catalog.aspx?Type=ProductSearch&Value=" + strSearch);
    }
    */ 
}