﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.Controls;
using Icon.Member;
using df = Icon.Definition;
using Icon;

public partial class Modules_IceBucket : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        #region 引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "jQuery", ResolveClientUrl("~/Js/jQuery/jquery-1.2.6.min.js"));
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
        #endregion

        DataBind();

        //第一次進入則檢查FreeTrial可選擇項目
        //if (!IsPostBack)
        //ShowFreeTrialText();
    }

    //建立購物車清單
    public override void DataBind()
    {
        decimal? dSubTotal = 0; //全項目總價

        //更新Set 的Discount Qty
        foreach (Icon.Member.Discount discount in Icon.Definition.CatalogDiscountList)
        {
            if (discount.Mode == "Set")
                discount.DiscountQty = BLL.SetDiscountQty(discount.Amount, discount.QtyH);
        }

        List<ShoppingCart> listSC = df.ShoppingCartList;
        if (listSC.Count > 0)
        {
            foreach (ShoppingCart sc in listSC)
            {
                ShoppingCart sc1 = sc;
                BLL.CalculateTotalPrice(ref sc1);
                //宣告表格物件
                TableRow row = new TableRow();
                TableCell cellDelete = new TableCell();
                TableCell cellQty = new TableCell();
                TableCell cellProductName = new TableCell();
                TableCell cellCatNo = new TableCell();
                TableCell cellPackage = new TableCell();
                TableCell cellUnitPrice = new TableCell();
                TableCell cellDeductPrice = new TableCell();
                TableCell cellTotalPrice = new TableCell();
                TableCell cellCampaign = new TableCell();
                row.HorizontalAlign = HorizontalAlign.Center;

                //加入表格
                row.Cells.Add(cellDelete);
                row.Cells.Add(cellQty);
                row.Cells.Add(cellProductName);
                row.Cells.Add(cellCatNo);
                row.Cells.Add(cellPackage);
                row.Cells.Add(cellUnitPrice);
                row.Cells.Add(cellDeductPrice);
                row.Cells.Add(cellTotalPrice);
                row.Cells.Add(cellCampaign);
                tbShoppintCart.Rows.AddAt(1, row);

                #region 樣式設定
                cellQty.HorizontalAlign = HorizontalAlign.Center;
                cellProductName.HorizontalAlign = HorizontalAlign.Left;
                cellCatNo.HorizontalAlign = HorizontalAlign.Left;
                cellPackage.HorizontalAlign = HorizontalAlign.Left;
                cellUnitPrice.HorizontalAlign = HorizontalAlign.Right;
                cellDeductPrice.HorizontalAlign = HorizontalAlign.Right;
                cellTotalPrice.HorizontalAlign = HorizontalAlign.Right;
                cellQty.CssClass = "ShoppingRow";
                cellProductName.CssClass = "ShoppingRow";
                cellCatNo.CssClass = "ShoppingRow";
                cellPackage.CssClass = "ShoppingRow";
                cellUnitPrice.CssClass = "ShoppingRow";
                cellDeductPrice.CssClass = "ShoppingRow";
                cellTotalPrice.CssClass = "ShoppingRow";
                cellDelete.CssClass = "ShoppingRow";
                #endregion
                
                #region 建立控制項
                //Qty文字方塊
                TextBox tbQty = new TextBox();
                tbQty.ID = "txtQty" + sc.CatalogItemID;
                tbQty.Text = sc.Quantity.ToString();
                tbQty.CssClass = "txtQty";
                tbQty.Width = 30;

                //刪除圖示按鈕
                Image imgDelete = new Image();
                imgDelete.ImageUrl = ResolveUrl("~/Images/Controls/delete.gif");
                imgDelete.Attributes.Add("onclick", "CallDeleteItem('" + sc.CatalogItemID.ToString() + "');");
                imgDelete.Style.Add("cursor", "pointer");

                //產品名稱超連結
                HyperLink linkProductName = new HyperLink();
                linkProductName.Text = sc.ProductName;
                linkProductName.NavigateUrl = string.Format("~/WebPage/Product/ProductDetail.aspx?CatalogItemID={0}", sc.CatalogItemID);
                if (sc.CampaignID != null) { linkProductName.NavigateUrl += "&CampaignID=" + sc.CampaignID; } //傳入CampaignID
                linkProductName.CssClass = "a2";
                #endregion

                #region 設定值
                cellDelete.Controls.Add(imgDelete);
                cellQty.Controls.Add(tbQty);
                cellProductName.Controls.Add(linkProductName);
                cellCatNo.Text = sc.CatNo;
                cellPackage.Text = sc.Package;
                cellUnitPrice.Text = Setting.GetCurrencyFormat("$", sc.UnitPrice, 2);
                cellDeductPrice.Text = Setting.GetCurrencyFormat("$", sc.Deduct, 2);
                cellTotalPrice.Text = Setting.GetCurrencyFormat("$", sc.TotalPrice, 2);
                dSubTotal += sc.TotalPrice; //累加單項目總價

                Icon.BLL.LimitShoppingCartQuantity(tbQty, sc.UnitPrice.Value); //允不允許使用者改數量
                #endregion

                //設定Campaign狀態
                if (sc.CampaignID != null)
                {
                    Label lblCampaignCode = new Label();
                    lblCampaignCode.Text = sc.CampaignCode;
                    cellCampaign.Controls.Add(lblCampaignCode);
                }
            }

            //顯示CheckOut區域
            palButtons.Visible = true;
        }
        else
        {
            //建立無資料列訊息
            TableRow row = new TableRow();
            TableCell cellNull = new TableCell();
            row.Cells.Add(cellNull);
            tbShoppintCart.Rows.AddAt(1, row);

            cellNull.ColumnSpan = tbShoppintCart.Rows[0].Cells.Count;
            cellNull.Text = "No Items";
            cellNull.ForeColor = System.Drawing.Color.Orange;
            cellNull.HorizontalAlign = HorizontalAlign.Center;

            //隱藏CheckOut區域
            palButtons.Visible = false;
        }

        lblSubTotal.Text = Setting.GetCurrencyFormat("$", dSubTotal, 2);
    }

    //更新數量
    protected void btnUpdateQty_Click(object sender, EventArgs e)
    {
        List<ShoppingCart> listSC = df.ShoppingCartList; //購物車清單

        //若有購物資料
        if (listSC.Count > 0)
        {
            //循序讀取購物車資料列
            foreach (TableRow row in tbShoppintCart.Rows)
            {
                TableCell cellQty = row.Cells[1]; //Qty欄

                //若有子控制項
                if (cellQty.HasControls())
                {
                    //若控制項為文字方塊
                    if (cellQty.Controls[0] is TextBox)
                    {
                        TextBox txtQty = (TextBox)cellQty.Controls[0]; //Qty文字方塊
                        int iCatalogItemID = int.Parse(txtQty.ID.Replace("txtQty", "")); //取得CatalogItemID

                        //若Qty為0或非數字格式，則刪除項目
                        int iReturn;
                        int.TryParse(txtQty.Text.Trim(), out iReturn);
                        if (iReturn == 0) { RemoveShoppingCartItem(iCatalogItemID); }

                        //循序讀取購物車物件
                        foreach (ShoppingCart sc in listSC)
                        {
                            //若CatalogItemID符合，則更新數量與項目總價
                            if (sc.CatalogItemID == iCatalogItemID)
                            {
                                ShoppingCart sc1 = sc;
                                string strMessage = "";
                                bool bResult = true;
                                int iQty = int.Parse(txtQty.Text.Trim()) - (int)sc.Quantity;
                                if(iQty != 0)
                                    BLL.GetCatalogDiscount(iCatalogItemID.ToString(), ref iQty, ref bResult, ref strMessage);

                                if (bResult && strMessage.Contains("The quantity is limited"))//輸入數量超過可購買
                                {
                                    sc1.Quantity += iQty;
                                    sc1.TotalPrice = (sc1.UnitPrice * sc1.Quantity);
                                    txtQty.Text = iQty.ToString();
                                    Page.RegisterClientScriptBlock("New", "<script>alert('" + strMessage + "')</script>");
                                }
                                else if (bResult && strMessage == "")
                                {
                                    sc1.Quantity = int.Parse(txtQty.Text.Trim());
                                    sc1.TotalPrice = (sc1.UnitPrice * sc1.Quantity);
                                }
                                else if (!bResult)
                                {
                                    Page.RegisterClientScriptBlock("New", "<script>alert('" + strMessage + "')</script>");
                                }
                            }
                        }
                    }
                }
            }
        }

        //ShowFreeTrialText();
        RemoveShoppingTableRow();
        DataBind();
    }

    //移除購物車資料列
    public void RemoveShoppingTableRow()
    {
        int iRowCount = tbShoppintCart.Rows.Count;
        if (iRowCount > 2) //大於2代表有購物資料
        {
            for (int i = iRowCount - 2; i >= 1; i--) //資料列迴圈
            {
                tbShoppintCart.Rows.RemoveAt(i); //移除資料列
            }
        }
    }

    //刪除按鈕事件
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        RemoveShoppingCartItem(int.Parse(hiddenCatalogItemID.Value));
        //ShowFreeTrialText();

        RemoveShoppingTableRow();
        DataBind();
    }

    //刪除購物車項目
    private void RemoveShoppingCartItem(int catalogitemid)
    {
        List<ShoppingCart> listSC = df.ShoppingCartList;
        foreach (ShoppingCart sc in listSC) //循序讀取購物車物件
        {
            if (sc.CatalogItemID.Value == catalogitemid) //若CatalogItemID符合
            {
                int iQty = (int)sc.Quantity * -1;
                string strMessage = "";
                bool bResult = true;
                BLL.GetCatalogDiscount(catalogitemid.ToString(), ref iQty, ref bResult, ref strMessage);
                listSC.Remove(sc); //移除購物項目
                break;
            }
        }
    }

    //CheckOut按鈕事件
    protected void btnCheckOut_Click(object sender, EventArgs e)
    {
        //更新數量
        btnUpdateQty_Click(new object(), new EventArgs());

        //if (ShowFreeTrialText()) //檢查FreeTrial項目
        //{
        Response.Redirect("~/WebPage/Member/OrderInfo.aspx");
        //}
    }

    //繼續購物按鈕事件
    protected void btnContinue_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/WebPage/Product/Catalog.aspx?CatalogID=3");
    }

    //顯示Free Trial可選擇的文字
    public bool ShowFreeTrialText()
    {
        /*若只有一筆FreeTrial項目，則不可新增其他項目
          若有金額項目，則允許同樣數量的FreeTrial產品*/

        bool bResult = true;
        //int iFreeChooseCount = 0;
        //int iFreeCount = 0;
        //int iProductCount = 0;

        //List<ShoppingCart> listSC = df.ShoppingCartList; //購物車清單
        //foreach (ShoppingCart sc in listSC) //循序讀取購物車物件
        //{
        //    if (sc.TotalPrice == 0) { iFreeCount += sc.Quantity.Value; } //累加無金額的數量
        //    else { iProductCount += sc.Quantity.Value; } //累加有金額的數量
        //}

        //iFreeChooseCount = (iProductCount - iFreeCount); //FreeTrials可選擇的項目
        //int iFreeChooseCount1 = (iFreeChooseCount <= 0 ? 0 : iFreeChooseCount); //若小於等於0則顯示0
        //lblFreeTrialItems.Text = string.Format("You can choose {0} free trial product(s)", iFreeChooseCount1);

        //#region 驗証Free Trial的規則

        //if (listSC.Count == 1) //如果購物項目只有一個
        //{
        //    ShoppingCart sc = listSC[0];
        //    if (sc.TotalPrice == 0 && sc.Quantity > 1) //如果無金額 & 購物數量大於1
        //    {
        //        bResult = false;
        //        lblMessage.Text = "Free Trial Offer is limited to one item or one trial item per regular item ordered.";
        //    }
        //}
        //else if (iFreeChooseCount < 0) //如果超過試用數量
        //{
        //    bResult = false;
        //    lblMessage.Text = "Free Trial Offer is limited to one item or one trial item per regular item ordered.";
        //}

        //#endregion

        return bResult;
    }
}