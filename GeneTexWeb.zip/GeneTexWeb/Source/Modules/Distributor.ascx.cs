﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using Icon;

public partial class Modules_Distributor : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //多語系設定
        hyMore.Text = Resources.Public.More;

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        DataBind();
    }
    public override void DataBind()
    {
        //取得使用者IP
        string strClientIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (strClientIP == null || strClientIP == "")
        {
            strClientIP = Request.ServerVariables["REMOTE_ADDR"];
        }
        //strClientIP = "84.195.79.145";
        Hashtable htParams = new Hashtable();
        htParams.Add("IP", strClientIP);
        string strCountryCode = BLL.GetCountryCode(htParams);
        DataTable dtDistributor = BLL.GetCompany("distributor", strCountryCode);

        if (dtDistributor.Rows.Count > 0)
        {
            reptDistributor.DataSource = dtDistributor;
            reptDistributor.DataBind();
        }
        else
        {
            palEmpty.Visible = true;
        }
    }

    protected void reptDistributor_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        DataRowView rowView = (DataRowView)e.Item.DataItem;

        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) //資料列
        {
            HyperLink hyDistributor = (HyperLink)e.Item.FindControl("hyDistributor");
            Label lblTel = (Label)e.Item.FindControl("lblTel");
            //Label lblEmail = (Label)e.Item.FindControl("lblEmail");
            //取出與設定變數
            string strName = rowView["Name"].ToString();
            lblTel.Text = rowView["Tel"].ToString();
            //lblEmail.Text = rowView["Email"].ToString();

            //設定值
            hyDistributor.Text = strName;
            hyDistributor.NavigateUrl = "~/WebPage/Public/Distributors.aspx?page=Distributors#" + rowView["ID"].ToString(); //連結經銷商內文
        }
    }
}
