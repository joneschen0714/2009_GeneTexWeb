﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using Icon;

public partial class Modules_PromotionProductShow : System.Web.UI.UserControl
{
    DataBase db = new DataBase(Icon.Definition.WebConnStr);


    protected void Page_Init(object sender, EventArgs e)
    {
        //多語系設定
        hyMore.Text = Resources.Public.More;
		imgTitle.ImageUrl = Resources.Public.Home_Img_PromotionProduct;
		//imgOffer.ImageUrl = "~/Images/Images/sale.png";
    }
}
