﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class Modules_WindowDialog_GetCity : System.Web.UI.Page
{
    private string m_CountryCode, m_StateCode;

    protected void Page_Init(object sender, EventArgs e)
    {
        gvCity.GridView.RowDataBound += new GridViewRowEventHandler(gvCity_RowDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        m_CountryCode = Request.QueryString["countrycode"];
        m_StateCode = Request.QueryString["statecode"];

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //資料參數
        Hashtable htParams = new Hashtable();
        htParams.Add("CountryCode", m_CountryCode);
        htParams.Add("StateCode", m_StateCode);
        htParams.Add("CityKeyWord", "%" + txtCity.Text.Trim() + "%");

        //呼叫邏輯層 (取得City資料)
        DataTable dtCity = BLL.GetCity(htParams);

        gvCity.Fields.Clear();
        Icon.Controls.myGridView.FieldCollection fc = gvCity.Fields;
        fc.Add("City", "CityName", true, Unit.Empty, "");
        fc.Add("County", "CountyName", true, Unit.Empty, "");

        gvCity.GridView.Width = Unit.Parse("100%");
        gvCity.Property.DataKey = "CityID";
        gvCity.DataTable = dtCity;
        gvCity.DataBind();
        gvCity.Visible = true;

        dtCity.Dispose();
        gvCity.Dispose();
    }

    protected void gvCity_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            TableCell cellCity = Icon.Controls.Tool.GetTableCell(e.Row, "City", false);

            LinkButton linkBtn = new LinkButton();
            linkBtn.Text = cellCity.Text;
            linkBtn.CssClass = "a2";
            linkBtn.Attributes.Add("onclick", string.Format("ReturnCityValue('{0}','{1}')", rowView["CountyName"], rowView["CityName"]));
            cellCity.Controls.Add(linkBtn);
        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        DataBind();
    }
}
