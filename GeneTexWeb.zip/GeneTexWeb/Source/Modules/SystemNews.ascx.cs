﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class Modules_SystemNews : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataBind();
    }

    public override void DataBind()
    {
        //控制項相關設定
        ImgView.ImageUrl = Resources.Public.Home_Img_SystemNews;

        //資料參數
        Hashtable htParams = new Hashtable();
        htParams.Add("Type", "System");
        htParams.Add("Enabled", 1);

        //呼叫邏輯層
        DataRow rowNews = BLL.GetSystemTop1News(htParams);

        if (rowNews != null)
        {
            //設定值
            lblTitle.Text = rowNews["Name"].ToString();

            string strDate = DateTime.Parse(rowNews["StartDate"].ToString()).ToString("yyyy/MM/dd");
            lblSystemNews.Text = string.Format("{0} ({1})", rowNews["Content"], strDate);
        }
        else
        {
            //無資料
            //lblSystemNews.Text = "";
        }
    }
}
