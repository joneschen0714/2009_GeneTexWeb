﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using Icon;

public partial class Modules_NewProduct_Center : System.Web.UI.UserControl
{
    DataBase db = new DataBase(Icon.Definition.WebConnStr);


    protected void Page_Init(object sender, EventArgs e)
    {
        //多語系設定
        hyMore.Text = Resources.Public.More;
        imgTitle.ImageUrl = Resources.Public.Home_Img_NewProduct;
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        DataBind();
    }


    public override void DataBind()
    {
        SqlParams param = new SqlParams();
        param.Add("CountryCode", Definition.CountryCode);
        db.SqlParams = param;
        db.StrSQL = "SELECT TOP 5 p.CatNo, " +
                        "vci.CatalogItemID, " +
                        "p.GeneID, " +
                        "p.ProductName + ' - ' + p.CatNo AS Name, " +
                        "vci.Price, " +
                        "vci.CurrencyName, " +
                        "vci.DecimalNum," +
                        "PromotionPrice " +
                    "FROM view_CatalogItem vci " +
                    "INNER JOIN Product p ON p.CatNo = vci.CatNo " +
                    "WHERE Type='B' AND vci.CountryCode=@CountryCode";
        DataTable dt = db.ExecuteDataTable();

        reptPromotion.DataSource = dt;
        reptPromotion.DataBind();
    }


    protected void reptPromotion_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        DataRowView rowView = (DataRowView)e.Item.DataItem;

        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) //資料列
        {
            //取得控制項
            HyperLink hyPromotion = (HyperLink)e.Item.FindControl("hyPromotion");
            Label lblPrice = (Label)e.Item.FindControl("lblPrice");
            lblPrice.CssClass = "text-align:right";

            string CurrencyName = rowView["CurrencyName"].ToString();
            int pdn = int.Parse(rowView["DecimalNum"].ToString());

            //設定值
            hyPromotion.Text = rowView["Name"].ToString();
            hyPromotion.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + rowView["CatalogItemID"].ToString(); //連結促銷產品內文
            //string strText = "Was {pPrice}, Now {ppPrice}!";
            string strText = "Now {pPrice}";
            lblPrice.Text = strText.Replace("{pPrice}", SetMoneyFormat(CurrencyName, rowView["Price"].ToString(), pdn))
                                   .Replace("{ppPrice}", SetMoneyFormat(CurrencyName, rowView["PromotionPrice"].ToString(), pdn));
        }
    }


    //轉換金錢格式
    private string SetMoneyFormat(string strCurrency, string strValue, int iDecimal)
    {
        if (decimal.Parse(strValue) > 0)
        {
            strValue = string.Format(strCurrency + " {0:N" + iDecimal + "}", decimal.Parse(strValue));
        }
        else
        {
            strValue = strCurrency + " - ";
        }
        return strValue;
    }
}
