﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using Icon;
using System.Globalization;

public partial class Modules_NewProduct_Center : System.Web.UI.UserControl
{
    DataBase db = new DataBase(Icon.Definition.WebConnStr);


    protected void Page_Init(object sender, EventArgs e)
    {
        //多語系設定
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        DataBind();
    }


    public override void DataBind()
    {
        DataTable dt = BLL.GetTopNewProducts();
        if (dt != null && dt.Rows.Count > 0)
        {
            reptNewProduct.DataSource = BLL.SelectTop(6, dt);
            reptNewProduct.DataBind();

            Label lblCount = (Label)reptNewProduct.Controls[0].FindControl("lblCount");
            lblCount.Text = string.Format("{0} New Products in {1}", dt.Rows.Count, DateTime.Today.ToString("MMM", CultureInfo.CreateSpecificCulture("en-US")));

            HyperLink hlMore = (HyperLink)reptNewProduct.Controls[reptNewProduct.Controls.Count - 1].FindControl("hlMore");
            hlMore.Text = "See all products";
            hlMore.NavigateUrl = "~/WebPage/Product/Catalog.aspx?CatalogID=" + dt.Rows[0]["CatalogID"].ToString();
        }
    }


    protected void reptNewProduct_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        DataRowView rowView = (DataRowView)e.Item.DataItem;

        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) //資料列
        {
            //取得控制項
            HyperLink hlProduct = (HyperLink)e.Item.FindControl("hlProduct");
            hlProduct.Text = rowView["CatNo"].ToString();
            hlProduct.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + rowView["CatalogItemID"].ToString();

            Label lblProductName = (Label)e.Item.FindControl("lblProductName");
            lblProductName.Text = rowView["ProductName"].ToString();
        }
    }
}
