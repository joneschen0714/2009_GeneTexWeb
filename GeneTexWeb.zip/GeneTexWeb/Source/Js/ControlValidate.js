﻿//驗証必填或自訂控制項
function checkRequired(obj, DefaultValue, IsRequired, Expression, DataType)
{
    var val = $.trim($(obj).val()); //前後去空取值
    
    if (IsRequired == "True" && val == "") //若驗証必填 && 為空值
    {
        alert("不可空值!");
        $(obj).val(DefaultValue); //回填預設值
        return false;
    }
    
    if(DataType != "String" && val != "") //若類型不為String && 不為空值
    {
        switch (DataType) //判斷資料類型
        {
            case "Int":
                re = /^[0-9]*$/;
                break;
            case "Float":
                re = /^[0-9]+(.[0-9]{1,5})?$/;
                break;
            case "Decimal":
                re = /^[0-9]+(.[0-9]{1,10})?$/;
                break;
            case "Date":
                re = /^[\d]{4,4}[/]([0][0-9]|[1][0-2])[/]([0-2][\d]|[3][0-1])$/;
                break;
        }
        
        if (!re.test(val)) //驗証正則運算式
        {
            alert("驗証格式錯誤!");
            $(obj).val(DefaultValue);
            return false;
        }
    }
    
    if (Expression != "") //若有自訂正則運算式
    {
        var re = new RegExp(Expression);
        if (!re.test(val))
        {
            alert("自訂驗証格式錯誤!");
            $(obj).val(DefaultValue);
            return false;
        }
    }
}

//只能輸入數字格式
function IntLimit()
{
    var key = event.keyCode; 
    if ((key > 95 && key < 106) || (key > 47 && key < 60)) {}
    else if(key != 8 && key != 9) { event.returnValue = false; }
}

//鎖滑鼠右鍵
function MouseRightLimit()
{
    if (event.button==2) { alert('No Function!'); }
}

//驗証密碼格式
function CheckPasswordFormat(source, arguments)
{
    var re = /^[A-Za-z0-9]{6,}$/;
    if(re.test(arguments.Value)) {
        arguments.IsValid = true;
    }
    else {
        arguments.IsValid = false;
    }
}