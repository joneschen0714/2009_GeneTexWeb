var xm;
var ym;

/* ==== onmousemove event ==== */
document.onmousemove = function(e){
	if(window.event) e=window.event;
	xm = (e.x || e.clientX);
	ym = (e.y || e.clientY);
}

/* ==== window resize ==== */
function resize() {
	if(diapo)diapo.resize();
}
onresize = resize;

/* ==== opacity ==== */
setOpacity = function(o, alpha){
	if(o.filters)o.filters.alpha.opacity = alpha * 100; else o.style.opacity = alpha;
}


////////////////////////////////////////////////////////////////////////////////////////////
/* ===== encapsulate script ==== */
diapo = {
    O: [],
    DC: 0,
    img: 0,
    txt: 0,
    N: 0,
    xm: 0,
    ym: 0,
    nx: 0,
    ny: 0,
    nw: 0,
    nh: 0,
    rs: 0,
    rsB: 0,
    zo: 0,
    tx_pos: 0,
    tx_var: 0,
    tx_target: 0,
    auto: 0,
    running: false,
    /////// script parameters ////////
    attraction: 2,
    acceleration: .5,
    dampening: .1,
    zoomOver: 2,
    zoomClick: 6,
    transparency: .8,
    font_size: 18,
    //////////////////////////////////

    /* ==== diapo resize ==== */
    resize: function() {
        with (this) {
            if (DC == null) return;
            nx = DC.offsetLeft;
            ny = DC.offsetTop;
            nw = DC.offsetWidth;
            nh = DC.offsetHeight;
            if (txt != null) txt.style.fontSize = Math.round(nh / font_size) + "px";
            if (Math.abs(rs - rsB) < 100 && O != null) for (var i = 0; i < O.length; i++) O[i].resize();
            rsB = rs;
        }
    },

    /* ==== create diapo ==== */
    CDiapo: function(o) {
        /* ==== init variables ==== */
        this.o = o;
        this.x_pos = this.y_pos = 0;
        this.x_origin = this.y_origin = 0;
        this.x_var = this.y_var = 0;
        this.x_target = this.y_target = 0;
        this.w_pos = this.h_pos = 0;
        this.w_origin = this.h_origin = 0;
        this.w_var = this.h_var = 0;
        this.w_target = this.h_target = 0;
        this.over = false;
        this.click = false;

        /* ==== create shadow ==== */
        this.spa = document.createElement("span");
        this.spa.className = "spaDC";
        diapo.DC.appendChild(this.spa);

        /* ==== create thumbnail image ==== */
        this.img = document.createElement("img");
        this.img.className = "imgDC";
        this.img.src = o.src;
        this.img.O = this;
        diapo.DC.appendChild(this.img);
        setOpacity(this.img, diapo.transparency);

        /* ==== mouse events ==== */
        this.img.onselectstart = new Function("return false;");
        this.img.ondrag = new Function("return false;");
        this.img.onmouseover = function() {
            onMouseOverHandler();
            diapo.tx_target = 0;
            if (diapo.txt != null) diapo.txt.innerHTML = this.O.o.alt;
            this.O.over = true;
            setOpacity(this, this.O.click ? diapo.transparency : 1);
        }
        this.img.onmouseout = function() {
            onMouseOutHandler();
            diapo.tx_target = -diapo.nw;
            this.O.over = false;
            setOpacity(this, diapo.transparency);
        }
        this.img.onclick = function() {
            if (!this.O.click) {
                if (diapo.zo && diapo.zo != this) diapo.zo.onclick();
                this.O.click = true;
                this.O.x_origin = (diapo.nw - (this.O.w_origin * diapo.zoomClick)) / 2;
                this.O.y_origin = (diapo.nh - (this.O.h_origin * diapo.zoomClick)) / 2 - 20;
                diapo.zo = this;
                setOpacity(this, diapo.transparency);
            } else {
                this.O.click = false;
                this.O.over = false;
                this.O.resize();
                diapo.zo = 0;
            }
        }

        /* ==== rearrange thumbnails based on "imgsrc" images position ==== */
        this.resize = function() {
            with (this) {
                x_origin = o.offsetLeft;
                y_origin = o.offsetTop;
                w_origin = o.offsetWidth;
                h_origin = o.offsetHeight;
                x_pos = x_origin + w_origin / 2;
                y_pos = y_origin + h_origin / 2;
            }
        }

        /* ==== animation function ==== */
        this.position = function() {
            with (this) {
                /* ==== set target position ==== */
                w_target = w_origin;
                h_target = h_origin;
                if (over) {
                    /* ==== mouse over ==== */
                    w_target = w_origin * diapo.zoomOver;
                    h_target = h_origin * diapo.zoomOver;
                    x_target = x_origin - 40;
                    //                    x_target = diapo.xm - w_pos  - (diapo.xm - (x_origin + w_pos)) / (diapo.attraction * (click ? 10 : 1)) ;
                    y_target = y_origin - 20;
                    //                    y_target = diapo.ym - h_pos / 2 - (diapo.ym - (y_origin + h_pos / 2)) / (diapo.attraction * (click ? 10 : 1));
                } else {
                    /* ==== mouse out ==== */
                    x_target = x_origin;
                    y_target = y_origin;
                }
                if (click) {
                    /* ==== clicked ==== */
                    w_target = w_origin * diapo.zoomClick;
                    h_target = h_origin * diapo.zoomClick;
                }

                /* ==== magic spring equations ==== */
                x_pos += x_var = x_var * diapo.acceleration + (x_target - x_pos) * diapo.dampening * 2;
                y_pos += y_var = y_var * diapo.acceleration + (y_target - y_pos) * diapo.dampening * 2;
                w_pos += w_var = w_var * (diapo.acceleration) + (w_target - w_pos) * (diapo.dampening * 2);
                h_pos += h_var = h_var * (diapo.acceleration) + (h_target - h_pos) * (diapo.dampening * 2);
                diapo.rs += (Math.abs(x_var) + Math.abs(y_var));

                /* ==== html animation ==== */
                with (img.style) {
                    left = Math.round(x_pos) + "px";
                    top = Math.round(y_pos) + "px";
                    width = Math.round(Math.max(0, w_pos)) + "px";
                    height = Math.round(Math.max(0, h_pos)) + "px";
                    zIndex = Math.round(w_pos);
                }
                with (spa.style) {
                    left = Math.round(x_pos + w_pos * .1) + "px";
                    top = Math.round(y_pos + h_pos * .1) + "px";
                    width = Math.round(Math.max(0, w_pos)) + "px";
                    height = Math.round(Math.max(0, h_pos)) + "px";
                    zIndex = Math.round(w_pos);
                }
                if (img.style.visibility != "visible") {
                    if (Math.round(Math.max(0, w_pos)) > 0) {
                        img.style.visibility = "visible";
                        img.style.visibility = "visible";
                        spa.style.visibility = "visible";
                        spa.style.visibility = "visible";
                    }
                }
            }
        }
    },

    /* ==== main loop ==== */
    run: function() {
    
        if (diapo.O.length == 0) return;
        diapo.xm = xm - diapo.nx;
        diapo.ym = ym - diapo.ny;
        /* ==== caption anim ==== */
        diapo.tx_pos += diapo.tx_var = diapo.tx_var * .9 + (diapo.tx_target - diapo.tx_pos) * .02;
        if (diapo.txt != null) diapo.txt.style.left = Math.round(diapo.tx_pos) + "px";
        /* ==== images anim ==== */
        for (var i in diapo.O) diapo.O[i].position();
        /* ==== loop ==== */
        diapo.running = true;
        setTimeout("diapo.run();", 32);
    },

    /* ==== load images ==== */
    images_load: function() {
        // ===== loop until all images are loaded =====
        var M = 0;
        for (var i = 0; i < diapo.N; i++) {
            if (diapo.img[i].complete) {
                diapo.img[i].style.position = "relative";
                //                diapo.O[i].img.style.visibility = "visible";
                //                diapo.O[i].spa.style.visibility = "visible";
                M++;
            }
            resize();
        }
        if (M < diapo.N) setTimeout("diapo.images_load();", 128);
    },

    /* ==== init script ==== */
    init: function() {
        diapo.img = 0;
        diapo.DC = 0;
        diapo.txt = 0;
        diapo.nh = 0;
        diapo.nw = 0;
        diapo.nx = 0;
        diapo.ny = 0;
        diapo.xm = 0;
        diapo.ym = 0;
        diapo.rs = 0;
        diapo.rsB = 0;
        diapo.O.length = 0;
        diapo.img.length = 0;
        diapo.txt.length = 0;
        diapo.N = 0;
        diapo.DC = document.getElementById("diapoContainer");
        //diapo.DC.innerHTML = '<img class="imgsrc" src="/Images/Images/image01.jpg">	<img class="imgsrc" src="/Images/Images/image01.jpg" alt="Something Needs to be Discovered"><img class="imgsrc" src="/Images/Images/image01.jpg" alt="They Said Very Little">';
        if (diapo.DC != null) diapo.img = diapo.DC.getElementsByTagName("img");
        diapo.txt = document.getElementById("caption");
        diapo.N = diapo.img.length;
        for (i = 0; i < diapo.N; i++) diapo.O.push(new diapo.CDiapo(diapo.img[i]));
        diapo.resize();
        diapo.tx_pos = -diapo.nw;
        diapo.tx_target = -diapo.nw;
        diapo.images_load();
        //        alert(diapo.img.length);
        // WebService.GetControl(onWebMethodComplete, onWebMethodTimeout, onWebMethodError);

    }
}

function onMouseOverHandler() {
    clearInterval(diapo.auto);
}

function onMouseOutHandler() {
    diapo.auto = setInterval('ProductChange()', 5000);
}

function onWebMethodError(result, response, context) {
    alert("Error occured:\n" + result.get_message());
}

function onWebMethodTimeout(result, response, context) {
    alert("Timeout occured");
}

function onWebMethodComplete(result, response, context) {
    //We need to refresh the image

}

