﻿//按鈕樣式
function SetButtonStyle(button,cssName)
{
    var vClassName = "Button " + cssName; //組合Class
    $(button).attr("class", vClassName) //設定Css
             .css("cursor", "pointer"); //增加滑鼠指標
    
    //滑鼠移入與移出動作
    $(button).hover(
        function() //移入
        {
            var ImgSrc = $(this).css("background-image"); //背景圖路徑
            $(this).css("background-image", ImgSrc.replace("0.gif", "1.gif")) //換圖
                   .css("color", "Yellow"); //字為黃色
        },
        function() //移出
        {
            var ImgSrc = $(this).css("background-image"); //背景圖路徑
            $(this).css("background-image", ImgSrc.replace("1.gif", "0.gif")) //換圖
                   .css("color", "Black"); //字為黑色
        }
    );
}

//指定按Enter要焦點哪個控制項
function changeFocusControl(nextControlUniqueID, evn)
{
    var e = (evn ? evn : window.event);
    
    if(e.keyCode == 13)
    {
        $("#" + nextControlUniqueID).focus();
        return false;
    }
    else
    {
        return true;
    }
}

//判斷按Enter是否觸發任何動作
function DoEnterAction(evn, isAction)
{
    var e = (evn ? evn : window.event);
    
    if(e.keyCode == 13)
    {
        e.returnValue = isAction;
    }
}

//限制所有文字不允許輸入
function LimitAnyKey(evn)
{
    var e = (evn ? evn : window.event);

    if(e.keyCode > 0)
    {
        e.returnValue = false;
    }
}

//剖析網址參數
function getParameter(queryString, parameterName)
{
    // Add "=" to the parameter name (i.e. parameterName=value)
    var parameterName = parameterName + "=";

    if ( queryString.length > 0 )
    {
        // Find the beginning of the string
        begin = queryString.indexOf ( parameterName );
        // If the parameter name is not found, skip it, otherwise return the value
        if ( begin != -1 ) {
        // Add the length (integer) to the beginning
            begin += parameterName.length;
            // Multiple parameters are separated by the "&" sign
            end = queryString.indexOf ( "&" , begin );
            if ( end == -1 ) {
                end = queryString.length
            }
            // Return the string
            return unescape ( queryString.substring ( begin, end ) );
        }
        // Return "null" if no parameter has been found
        return "null";
    }
}