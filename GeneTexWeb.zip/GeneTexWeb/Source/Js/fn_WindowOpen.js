function fn_WindowOpen(url, name, width, height)
{
    var args = (height != 0 ? ",height="+ height : "");
	    args += (width != 0 ? ",width="+ width : "");

    window.open(url, name, 'modal=yes,resizable=yes,scrollbars=yes,location=no,directories=no,status=no,menubar=no'+ args);
}

//Dialog��w�}��
function fn_openThisWindowDialog(path , width , height)
{
	var args = (height != 0 ? "dialogHeight:"+ height +"px;" : "");
	args += (width != 0 ? "dialogWidth:"+ width +"px;" : "");
	
	window.showModalDialog(path, self, 'status:no;resizable:yes;center:yes;'+ args);
}

//Dialog��w�}��
function fn_openWindowDialog(rootPath, s_url, title, width, height)
{
	var obj = new Object();
	obj.title = title;
	obj.url = rootPath + s_url;
	obj.window = window;
	obj.width = width;
	obj.height = height;
	
	var tmpPath = rootPath + "/Controls/WindowDialog.aspx";
	
	window.showModalDialog(tmpPath, obj, 'status:no;resizable:yes;');
}

//�վ����Size
function WindowReSize(obj)
{
	parent.document.getElementById("s_frame").width = obj.scrollWidth;
	parent.document.getElementById("s_frame").height = obj.scrollHeight;

	var width = parent.document.getElementById("s_frame").width;
	var height = parent.document.getElementById("s_frame").height;

	//�P�_Browser����
	var BroswerName = navigator.appName;
	if(BroswerName == "Microsoft Internet Explorer") //For IE
	{
    	parent.dialogWidth = width + "px";
        parent.dialogHeight = height + "px";
	}
	else if (BroswerName == "Netscape") //For Mac Safari
	{
    	if (parent.document.getElementById("s_frame").scrolling == 'no')
    	    
    		parent.resizeTo(width, height + 55);
    	else
        	parent.resizeTo(width + 20, height + 55);
    
	    parent.document.getElementById("s_frame").scrolling = 'no';
   	}
}