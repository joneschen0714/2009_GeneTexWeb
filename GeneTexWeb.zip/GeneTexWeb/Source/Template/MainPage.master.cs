﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using Icon.DataBase;
using Icon.Member;
using df = Icon.Definition;

public partial class MainPage : System.Web.UI.MasterPage
{
    DataBase db;
    string strCulture;


    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css & Script
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "jQuery", ResolveClientUrl("~/Js/jQuery/jquery-1.2.6.min.js"));
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "impromptu", ResolveClientUrl("~/Js/jQuery/jquery-impromptu.2.7.min.js"));
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "IconJs", ResolveClientUrl("~/Js/Icon.js"));
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "json2", ResolveClientUrl("~/Js/jQuery/json2.js"));
        Page.Header.Controls.Add(new LiteralControl("<link type='text/css' rel='stylesheet' href='" + ResolveClientUrl("~/Css/css.css") + "' />"));
        Page.Header.Controls.Add(new LiteralControl("<link type='text/css' rel='stylesheet' href='" + ResolveClientUrl("~/Css/jquery.impromptu.css") + "' />"));

        //Meta Data (給搜尋引擎使用)
        string strMeta = "<meta name=RESOURCE-TYPE content=DOCUMENT>" +
                         "<meta name=DISTRIBUTION content=GLOBAL>" +
                         "<meta name=\"revisit-after\" content=\"7 days\" />" +
                         "<meta name=\"robots\" content=\"all\">";
        Page.Header.Controls.Add(new LiteralControl(strMeta));
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        linkLogo.NavigateUrl = "~/Default.aspx";
        db = new DataBase(Icon.Definition.WebConnStr);
        strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系

        if (!IsPostBack)
        {
            #region 國家站台資料

            //設定國家站台選單資料
            foreach (List<string> sc in CountrySiteList)
                liSiteCode.Text += string.Format("　<img src={0} /><a href='{1}'>{2}</a>", ResolveUrl(sc[3]), sc[2], sc[1]);
            #endregion

            //驗証會員是否登入
            if (MemberInfo.CheckMemberLogin())
            {
                MemberInfo mi = df.OnlineMemberInfoList[df.PersonalMemberID];
                hyLoginStatus.Text = string.Format("{0} {1} , {2}", mi.FirstName, mi.LastName, Resources.Public.Logout);
                hyLoginStatus.NavigateUrl = "~/WebPage/Member/Login.aspx?type=logout";
            }
            else
            {
                hyLoginStatus.Text = Resources.Public.Login;
                hyLoginStatus.NavigateUrl = "~/WebPage/Member/Login.aspx";
            }
        }
    }


    //切換語系
    protected void btnCulture_Click(object sender, EventArgs e)
    {
        //設定語系值
        string _Culture = "";
        if (strCulture == "zh-TW")
        {
            _Culture = "en-US";
        }
        else if (strCulture == "en-US")
        {
            _Culture = "zh-TW";
        }

        //設定Cookie
        HttpCookie cookie = new HttpCookie("IconbioWeb.Culture", _Culture);
        cookie.Expires = DateTime.Now.AddMonths(1); //為期一個月
        Response.Cookies.Add(cookie);

        Response.Redirect("~/Default.aspx"); //導回首頁
    }


    //站台國家集合資料
    private List<string>[] CountrySiteList
    {
        get
        {
            List<string>[] listCountry = new List<string>[2];
            listCountry[0] = GetListData("US", "United States", "http://www.genetex.com", "~/Images/Flag/small/us.png");
            listCountry[1] = GetListData("TW", "Taiwan", "http://www.iconbio.com.tw", "~/Images/Flag/small/tw.png");
            //listCountry[0] = GetListData("US", "United States", "http://test/GeneTexWeb", "~/Images/Flag/small/us.png");
            //listCountry[1] = GetListData("TW", "Taiwan", "http://test/IconbioWeb", "~/Images/Flag/small/tw.png");
            return listCountry;
        }
    }
    private List<string> GetListData(params string[] DataArray)
    {
        //泛型集合物件
        List<string> strArray = new List<string>();

        //循序加入至泛型集合
        foreach (string strValue in DataArray)
            strArray.Add(strValue);

        return strArray; //回傳
    }
}