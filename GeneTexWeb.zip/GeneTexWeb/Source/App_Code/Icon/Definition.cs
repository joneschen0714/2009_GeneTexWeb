﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using Icon.Member;

namespace Icon
{
    public class Definition
    {
        /// <summary>網站資料庫的連線字串</summary>
        public static string WebConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["WebConnString"].ConnectionString; }
        }

		/// <summary>Campaign資料庫的連線字串</summary>
		public static string CamConnStr
		{
			get { return ConfigurationManager.ConnectionStrings["CamConnString"].ConnectionString; }
		}

        /// <summary>BioInfo資料庫的前置名稱</summary>
        public static string DBNameBioInfo
        {
            get { return ConfigurationSettings.AppSettings["DBStr_BioInfo"]; }
        }


        /// <summary>取得購物車清單</summary>
        public static List<ShoppingCart> ShoppingCartList
        {
            get
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                if (hss["ShoppingCartList"] == null) //若Session無記錄
                {
                    ShoppingCartList = new List<ShoppingCart>();
                }

                return (List<ShoppingCart>)hss["ShoppingCartList"];
            }
            set
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                hss.Add("ShoppingCartList", value);
            }
        }

        /// <summary>取得Catalog Discount List</summary>
        public static List<Discount> CatalogDiscountList
        {
            get
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                if (hss["CatalogDiscount"] == null) //若Session無記錄
                {
                    CatalogDiscountList = new List<Discount>();
                }

                return (List<Discount>)hss["CatalogDiscount"];
            }
            set
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                hss.Add("CatalogDiscount", value);
            }
        }

        /// <summary>取得線上會員資料集合</summary>
        public static MemberInfoCollection OnlineMemberInfoList
        {
            get
            {
                System.Web.Caching.Cache myCache = HttpContext.Current.Cache;
                if (myCache["OnlineMemberInfoList"] == null) //若Session無記錄
                {
                    OnlineMemberInfoList = new MemberInfoCollection();
                }

                return (MemberInfoCollection)myCache["OnlineMemberInfoList"];
            }
            set
            {
                System.Web.Caching.Cache myCache = HttpContext.Current.Cache;
                myCache.Insert("OnlineMemberInfoList", value);
            }
        }


        /// <summary>記錄個人會員ID</summary>
        public static int? PersonalMemberID
        {
            get
            {
                if (HttpContext.Current.Session["PersonalMemberID"] != null)
                {
                    return int.Parse(HttpContext.Current.Session["PersonalMemberID"].ToString());
                }
                return null;
            }
            set { HttpContext.Current.Session["PersonalMemberID"] = value; }
        }


        /// <summary>導向頁面路徑</summary>
        public static string RedirectPageUrl
        {
            get
            {
                if (HttpContext.Current.Session["RedirectPage"] != null)
                {
                    return HttpContext.Current.Session["RedirectPage"].ToString();
                }
                return null;
            }
            set { HttpContext.Current.Session["RedirectPage"] = value; }
        }


        /// <summary>上一頁頁面路徑</summary>
        public static string BackPageUrl
        {
            get
            {
                if (HttpContext.Current.Session["BackPageUrl"] != null)
                {
                    return HttpContext.Current.Session["BackPageUrl"].ToString();
                }
                return null;
            }
            set { HttpContext.Current.Session["BackPageUrl"] = value; }
        }


        /// <summary>付款相關物件</summary>
        public static Payment MyPayment
        {
            get
            {
                if (HttpContext.Current.Session["MyPayment"] == null)
                    MyPayment = new Payment();

                return (Payment)HttpContext.Current.Session["MyPayment"];
            }
            set { HttpContext.Current.Session["MyPayment"] = value; }
        }


        /// <summary>設定與取得國家代碼</summary>
        public static string CountryCode
        {
            get
            {
                if (HttpContext.Current.Session["CountryCode"] == null)
                {
                    CountryCode = ConfigurationSettings.AppSettings["CountryCode"];
                }
                return HttpContext.Current.Session["CountryCode"].ToString();
            }
            set { HttpContext.Current.Session.Add("CountryCode", value); }
        }


        /// <summary>取得當地國家的SiteMapDataSource</summary>
        public static SiteMapDataSource SiteMapDataSource
        {
            get
            {
                SiteMapDataSource smds = new SiteMapDataSource();
                if (CountryCode == "US") { smds.SiteMapProvider = "MenuProvider"; }

                return smds;
            }
        }


        /// <summary>取得當地國家的SiteMapDataSource</summary>
        public static List<int> lstCatalogItemID
        {
            get
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                if (hss["lstCatalogItemID"] == null) //若Session無記錄
                {
                    lstCatalogItemID = new List<int>();
                }
                return (List<int>)hss["lstCatalogItemID"];
            }
            set
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                hss.Add("lstCatalogItemID", value);
            }
        }


        /// <summary>取得CampaignCodeList字串陣列</summary>
        public static string GetCampaignCodeString()
        {
            HttpCookieCollection hcc = HttpContext.Current.Request.Cookies;
            string strValue = "";
            for (int i = 0; i < hcc.Count; i++)
            {
                HttpCookie hc = hcc[i];
                if (hc.Name.Contains("CampaignCode_"))
                    strValue += string.Format(",'{0}'", hc.Value);
            }
            return strValue.TrimStart(',');
        }

        /// <summary>取得NavigatorList記錄清單</summary>
        public static NameValueCollection NavigatorList
        {
            get 
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                if (hss["NavigatorList"] == null) //若Session無記錄
                {
                    NameValueCollection navList = new NameValueCollection();
                    hss.Add("NavigatorList", navList);
                }
                return (NameValueCollection)hss["NavigatorList"];
            }
        }
    }
}