﻿using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using System.Xml;
using Icon;
using ws_Forum;

namespace Icon
{
    /// <summary>
    /// 商業邏輯層
    /// </summary>
    public class BLL
    {
        public BLL()
        {

        }

        #region 會員相關
        /// <summary>
        /// 會員登入
        /// </summary>
        public static void Member_Login(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //宣告變數
            string strAccount = htParams["Account"].ToString();
            string strPassword = htParams["Password"].ToString();

            //若帳號密碼都不為空白
            if ((strAccount != string.Empty) && (strPassword != string.Empty))
            {
                //呼叫DAL
                DAL.Member_Login(out bResult, out strMessage, htParams);
            }
            else
            {
                bResult = false;
                strMessage = "Account AND Password Not NULL!";
            }
        }

        /// <summary>
        /// 驗証帳號是否可用
        /// </summary>
        public static void CheckMemberAccount(out string strMessage, Hashtable htParams)
        {
            //宣告變數
            string strAccount = htParams["Account"].ToString();

            //判斷帳號是否為空
            if (strAccount != string.Empty)
            {
                DAL.CheckMemberAccount(out strMessage, htParams);
            }
            else
            {
                strMessage = "User name is required!";
            }
        }

        /// <summary>
        /// 註冊新會員
        /// </summary>
        public static void RegisterNewMember(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //呼叫DAL
            DAL.RegisterNewMember(out bResult, out strMessage, htParams);
        }

        /// <summary>
        /// 取得會員資料
        /// </summary>
        public static DataTable GetMemberInfo(string account)
        {
            DataTable dtMemberInfo = DAL.GetMemberInfo(account);
            return dtMemberInfo;
        }

        /// <summary>
        /// 取得會員的問題與答案
        /// </summary>
        public static DataTable GetPasswordQuestions(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //呼叫DAL
            DataTable dt = DAL.GetPasswordQuestions(out bResult, out strMessage, htParams);
            return dt;
        }

        /// <summary>
        /// 判斷是否有會員的地址資訊
        /// </summary>
        public static bool CheckMemberAddress(int MemberID)
        {
            DataTable dtAddress = GetMemberAddress(MemberID);

            return (dtAddress.Rows.Count >= 1);
        }

        /// <summary>
        /// 取得會員的地址資訊
        /// </summary>
        public static DataTable GetMemberAddress(int MemberID)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("ActiveType", "getInfo");
            htParams.Add("MemberID", MemberID);
            htParams.Add("Type", "Member");

            DataTable dt = DAL.GetMemberAddress(htParams);
            return dt;
        }

        /// <summary>
        /// 增加會員地址資訊
        /// </summary>
        public static void InsertMemberAddress(out bool bResult, out string strMessage, Hashtable htParams)
        {
            DAL.InsertMemberAddress(out bResult, out strMessage, htParams);
        }

        /// <summary>
        /// 取得會員的指定地址資訊
        /// </summary>
        public static DataRow GetMemberSingleAddress(int MemberID, int AddressID)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("ActiveType", "getInfo");
            htParams.Add("MemberID", MemberID);
            htParams.Add("Type", "Member");

            DataTable dt = DAL.GetMemberAddress(htParams);
            DataRow row = dt.Select("AddressID=" + AddressID.ToString())[0];
            return row;
        }

        /// <summary>
        /// 變更會員密碼
        /// </summary>
        public static void ChangePassword(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //宣告變數
            bResult = true;
            strMessage = "";
            string strCurrentPwd = htParams["CurrentPwd"].ToString();
            string strOldPwd = htParams["OldPassword"].ToString();
            string strNewPwd = htParams["NewPassword"].ToString();
            string strConfirmPwd = htParams["ConfirmPassword"].ToString();

            //驗証舊密碼是否相符
            if (strOldPwd != strCurrentPwd) { strMessage = "Password is validate,please try again!"; bResult = false; }

            //驗証密碼確認是否一樣
            if (strNewPwd != strConfirmPwd) { strMessage = "new password and confirm password isn't same!"; bResult = false; }

            //舊密碼與新密碼是否一樣
            if (strOldPwd == strNewPwd) { strMessage = "old password and new password can't same!"; bResult = false; }

            if (bResult)
            {
                //資料參數
                Hashtable htNewParams = new Hashtable();
                htNewParams.Add("ActionType", "ChangePassword");
                htNewParams.Add("MemberID", htParams["MemberID"]);
                htNewParams.Add("Password", strNewPwd);

                //呼叫DAL
                DAL.RegisterNewMember(out bResult, out strMessage, htNewParams);
            }
        }

        /// <summary>
        /// 忘記密碼頁面-變更密碼
        /// </summary>
        public static void ForgotChangePassword(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //變數
            string strNewPwd = htParams["NewPassword"].ToString();
            string strConfirmPwd = htParams["ConfirmPassword"].ToString();

            //驗証密碼確認是否一樣
            if (strNewPwd == strConfirmPwd)
            {
                //資料參數
                Hashtable htNewParams = new Hashtable();
                htNewParams.Add("ActionType", "ChangePassword");
                htNewParams.Add("MemberID", htParams["MemberID"]);
                htNewParams.Add("Password", strNewPwd);

                //呼叫DAL
                DAL.RegisterNewMember(out bResult, out strMessage, htNewParams);
            }
            else
            {
                bResult = false;
                strMessage = "new password and confirm password isn't same!";
            }
        }

        /// <summary>找尋Address條件資料</summary>
        public static DataTable GetAddressInfo(string Country, string State, string County, string City)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("Country", Country);
            htParams.Add("State", State);
            htParams.Add("County", County);
            htParams.Add("City", City);

            return DAL.GetAddressInfo(htParams);
        }

        /// <summary>檢查MemberType條件、發密碼信給會員</summary>
        public static bool CheckLoginMemberType(object Account)
        {
            //取得Type不等於Web的Member資訊
            Hashtable htParams = new Hashtable();
            htParams.Add("Account", Account);
            DataRow row = DAL.CheckLoginMemberType(htParams);

            if (row != null)
            {
                //發密碼信給會員
                htParams.Clear();
                htParams.Add("Account", row["Account"]);
                htParams.Add("Password", row["Password"]);
                htParams.Add("ToEmailAddress", row["Email"]);
                bool bResult = SendPasswordEmail(htParams);

                return bResult;
            }
            else
            {
                return false;
            }
        }

        //檢查GeneID，並回傳錯誤的GeneID
        public static string CheckGeneID(ref string strGeneID)
        {
            string strGeneErrList = "";
            string[] aryGeneID = strGeneID.Split(',');
            //判斷是否為數字
            int n;
            strGeneID = "";
            for (int i = 0; i < aryGeneID.Length; i++)
            {
                if (int.TryParse(aryGeneID[i], out n)) //只找是數字
                    strGeneID += (strGeneID == "" ? "" : ",") + aryGeneID[i];
            }
            //找出不存在的GeneID
            DataTable dtGene = DAL.CheckGeneID(strGeneID);

            strGeneID = "";
            int iCount = 0;
            for (int i = 0; i < aryGeneID.Length; i++)
            {
                iCount = 0;
                if (dtGene != null && dtGene.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtGene.Rows) //存在的GeneID
                    {
                        if (aryGeneID[i] == dr["GeneID"].ToString())
                        {
                            iCount++;
                            break;
                        }
                    }
                }
                if (iCount == 0)
                    strGeneErrList += (strGeneErrList == "" ? "" : ",") + aryGeneID[i];
                else
                    strGeneID += (strGeneID == "" ? "" : "\r\n") + aryGeneID[i];
            }

            if (strGeneErrList != "")
                strGeneErrList = "Error:\r\n" + strGeneErrList;
            return strGeneErrList;
        }

        public static string GetResearchArea(string strGeneID)
        {
            return DAL.GetResearchArea(strGeneID);
        }

        //取得Member相關的ResearchAreaGeneID
        public static string GetMembersResearchAreaGeneID(int iMemberID)
        {
            string strResearchGeneID = "";
            DataTable dtGeneID = DAL.GetMembersResearchAreaGeneID(iMemberID);
            if (dtGeneID != null && dtGeneID.Rows.Count > 0)
            {
                foreach (DataRow dr in dtGeneID.Rows)
                    strResearchGeneID += (strResearchGeneID == "" ? "" : "\r\n") + dr["GeneID"].ToString();
            }
            return strResearchGeneID;
        }

        //新增或修改Member和GeneId的關連
        public static void AddMemberGeneIdRel(object oMemberID, string sResearchGeneID)
        {
            DAL.AddMemberGeneIdRel(oMemberID, sResearchGeneID);
        }

        #endregion

        #region 購物相關
        /// <summary>
        /// 取得產品頁面的購物車資料
        /// </summary>
        public static DataTable GetCartForProductData(string CatalogItemID)
        {
            DataTable dtResult = DAL.GetCartForProductData(CatalogItemID);
            return dtResult;
        }

        /// <summary>
        /// 新增會員的Wish List
        /// </summary>
        public static void InsertMemberWishList(out bool bResult, out string strMessage, Hashtable htParams)
        {
            DAL.InsertMemberWishList(out bResult, out strMessage, htParams);
        }

        /// <summary>
        /// 取得會員的Wish List
        /// </summary>
        public static DataTable GetMemberWishList(int memberID)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("MemberID", memberID);

            DataTable dtResult = DAL.GetMemberWishList(htParams);
            return dtResult;
        }

        /// <summary>
        /// 刪除會員的Wish List
        /// </summary>
        public static void DeleteMemberWishList(out bool bResult, out string strMessage, string strWishListIDArray)
        {
            DAL.DeleteMemberWishList(out bResult, out strMessage, strWishListIDArray);
        }

        /// <summary>
        /// 取得Quick Order資料
        /// </summary>
        public static DataTable GetQuickOrderData(out bool bResult, out string strMessage, string strCatNo)
        {
            //參數集合
            Hashtable htParams = new Hashtable();
            htParams.Add("CatNo", strCatNo);

            DataTable dt = DAL.GetQuickOrderData(htParams);
            //判斷有無資料
            if (dt.Rows.Count == 0)
            {
                bResult = false;
                strMessage = "Product " + strCatNo + " not found!";
            }
            else
            {
                bResult = true;
                strMessage = "";
            }
            return dt;
        }

        /// <summary>
        /// 取得所有國家資料
        /// </summary>
        public static DataTable GetCountry()
        {
            return DAL.GetCountry();
        }
        public static DataTable GetCountry(int StateID)
        {
            return DAL.GetCountry(StateID);
        }

        /// <summary>
        /// 取得對應的State資料
        /// </summary>
        public static DataTable GetState(string CountryCode)
        {
            DataTable dtState = DAL.GetState(CountryCode);

            //循序串接顯示的State名稱
            foreach (DataRow rowState in dtState.Rows)
                rowState["StateName"] = string.Format("{0} - ({1})", rowState["Code"], rowState["StateName"]);

            return dtState;
        }
        public static DataTable GetState(int CountyID)
        {
            DataTable dtState = DAL.GetState(CountyID);
            return dtState;
        }

        /// <summary>
        /// 取得對應的City資料
        /// </summary>
        public static DataTable GetCity(Hashtable htParams)
        {
            return DAL.GetCity(htParams);
        }

        /// <summary>
        /// 取得對應的County資料
        /// </summary>
        public static DataTable GetCounty(string city)
        {
            return DAL.GetCounty(city);
        }

        /// <summary>
        /// 判斷是否有City資料
        /// </summary>
        public static bool ExistsCity(Hashtable htParams)
        {
            return DAL.ExistsCity(htParams);
        }

        /// <summary>
        /// 變更AddressType
        /// </summary>
        public static void UpdateAddressType(int memberid, int? billingid, int? shippingid)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("MemberID", memberid);
            htParams.Add("BillingAddressID", billingid);
            htParams.Add("ShippingAddressID", shippingid);
            htParams.Add("ActiveType", "editType");

            bool bResult;
            string strMessage;
            DAL.InsertMemberAddress(out bResult, out strMessage, htParams);
        }

        /// <summary>
        /// 取得計算金額相關所需資料
        /// </summary>
        public static Hashtable GetPaymentInfo(int BillingID, int ShippingID, string ProductIDArray)
        {
            return DAL.GetPaymentInfo(BillingID, ShippingID, ProductIDArray);
        }

        /// <summary>
        /// 新增會員訂單項目
        /// </summary>
        public static void InsertOrderInfo(out bool bResult, out string strMessage, out string strOrderID, Hashtable htParams, List<Member.ShoppingCart> ShoppingCartList)
        {
            //組成寫入暫存表指令
            string strOrderItemSQL = "";
            foreach (Member.ShoppingCart sc in ShoppingCartList)
            {
                //CampaignID參數
                string strCampaignID = "Null";
                if (sc.CampaignID != null) { strCampaignID = sc.CampaignID.ToString(); }

                strOrderItemSQL += string.Format("INSERT #OrderItem VALUES({0},{1},'{2}','{3}',{4},{5},{6});",
                                                sc.CatalogItemID,
                                                strCampaignID,
                                                sc.CatNo,
                                                sc.ProductName,
                                                sc.UnitPrice,
                                                sc.Quantity,
                                                sc.TotalPrice);
            }

            htParams.Add("ActionType", "Insert");
            htParams.Add("OrderItemSQL", strOrderItemSQL);
            DAL.InsertOrderInfo(out bResult, out strMessage, out strOrderID, htParams);
        }

        /// <summary>
        /// 取得會員的歷史訂單記錄
        /// </summary>
        public static DataTable GetOrderHistoryList(int MemberID)
        {
            //轉換為資料參數
            Hashtable htParam = new Hashtable();
            htParam.Add("ActionType", "GetHistoryOrderList");
            htParam.Add("MemberID", MemberID);

            return DAL.GetOrderHistoryList(htParam);
        }

        /// <summary>
        /// 取得訂單的項目資料
        /// </summary>
        public static DataTable GetHistoryOrderListItem(int OrderID)
        {
            //轉換為資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("ActionType", "GetOrderItems");
            htParams.Add("ThisOrderID", OrderID);

            return DAL.GetHistoryOrderListItem(htParams);
        }

        /// <summary>
        /// 取得型錄的產品資料
        /// </summary>
        public static int GetMaxInvoiceID()
        {
            return DAL.GetMaxInvoiceID();
        }

        /// <summary>限制加入Shopping Cart的數量</summary>
        public static void LimitShoppingCartQuantity(TextBox txtQty, decimal price)
        {
            if (price == 0) //若Price為0，代表是FreeTrial，則不允許使用者改數量
            {
                txtQty.Text = "1";
                txtQty.Enabled = false;
            }
        }

        /// <summary>檢查產品是否有在購物車裡</summary>
        public static bool CheckProductExistsShoppingCart(int catalogitemid, string catno, ref string strMessage)
        {
            bool isOK = true;
            isOK = Icon.Member.ShoppingCart.CheckCatNoInCart(catno); //檢查CatNo是否已在購物車裡

            //判斷狀態
            if (isOK)
            {
                return true;
            }
            else
            {
                strMessage = catno + " is already in your shopping cart!";
                return false;
            }
        }

        /// <summary>新增產品至購物車裡</summary>
        public static void AddProductToShoppingCart(ref bool bResult, ref string strMessage, Hashtable htParams)
        {
            //轉回參數型別
            int iCatalogItemID = int.Parse(htParams["CatalogItemID"].ToString());
            string strCampaignID = (htParams["CampaignID"] == null ? null : htParams["CampaignID"].ToString());
            string strCatNo = htParams["CatNo"].ToString();
            string strQty = htParams["Qty"].ToString();

            int iQty;
            int.TryParse(strQty, out iQty);

            //資料參數 (取得產品資訊)
            Hashtable htDBParams = new Hashtable();
            htDBParams.Add("CatalogItemID", iCatalogItemID);
            htDBParams.Add("CampaignID", strCampaignID);
            DataRow rowProductInfo = DAL.GetProductOrderInfo(htDBParams).Rows[0];

            //取得Price 與 Special Price
            decimal dThisPrice = new decimal();
            decimal dPrice = decimal.Parse(rowProductInfo["Price"].ToString());
            decimal dSpecialPrice = decimal.Parse(rowProductInfo["PromotionPrice"].ToString());

            //取得最小金額
            if (dSpecialPrice > 0 && dPrice > dSpecialPrice) { dThisPrice = dSpecialPrice; }
            else { dThisPrice = dPrice; }


            //設定ShoppingCart物件
            Icon.Member.ShoppingCart sc = new Icon.Member.ShoppingCart();

            sc.GeneID = int.Parse(rowProductInfo["GeneID"].ToString());
            sc.CatalogItemID = int.Parse(rowProductInfo["CatalogItemID"].ToString());
            if (rowProductInfo["CampaignID"].ToString() != "") { sc.CampaignID = int.Parse(rowProductInfo["CampaignID"].ToString()); } //傳入CampaignID
            if (rowProductInfo["CampaignCode"].ToString() != "") { sc.CampaignCode = rowProductInfo["CampaignCode"].ToString(); } //傳入CampaignCode
            sc.CatNo = string.Format("{0}", rowProductInfo["CatNo"]);
            sc.Package = string.Format("{0}", rowProductInfo["Package"]);
            sc.ProductName = string.Format("{0}", rowProductInfo["ProductName"]);
            sc.Quantity = iQty;
            sc.UnitPrice = dThisPrice;
            sc.TotalPrice = (sc.UnitPrice * sc.Quantity);
            sc.CatalogID = int.Parse(rowProductInfo["CatalogID"].ToString());

            //計算產品Total價錢及折扣數
            //CalculateTotalPrice(ref sc);

            //加入至個人購物車清單
            Icon.Definition.ShoppingCartList.Add(sc);

            bResult = true;
        }

        /// <summary>
        /// 計算產品價錢及折扣數
        /// </summary>
        public static void CalculateTotalPrice(ref Icon.Member.ShoppingCart sc)
        {
            foreach (Icon.Member.Discount discount in Icon.Definition.CatalogDiscountList)
            {
                if (discount.CatalogID == sc.CatalogID)
                {
                    sc.TotalPrice = (sc.UnitPrice * sc.Quantity);
                    decimal? dDeduct = discount.Deduct;
                    if (discount != null && discount.Deduct > -1)
                    {
                        if (discount.QtyH >= sc.Quantity && discount.Mode == "")
                        {
                            dDeduct = discount.Deduct * sc.Quantity;
                        }
                        else if (discount.Mode == "Set" && discount.Amount >= discount.QtyH && discount.QtyH > 0)
                        {
                            int? iCount = GetSetModeCount(sc, discount);

                            dDeduct = discount.Deduct * (iCount);
                            discount.DiscountQty -= (int)iCount;
                        }
                        else
                            dDeduct = 0;

                        sc.Deduct = dDeduct;
                        sc.TotalPrice -= sc.Deduct;
                    }
                    else if (discount != null && discount.DiscountRate > 0)
                    {
                        if (discount.QtyH >= sc.Quantity && discount.Mode == "")
                        {
                            dDeduct = sc.TotalPrice * (1 - discount.DiscountRate);
                        }
                        else if (discount.Mode == "Set" && discount.Amount >= discount.QtyH && discount.QtyH > 0)
                        {
                            int? iCount = GetSetModeCount(sc, discount);

                            dDeduct = (sc.UnitPrice * iCount) * (1 - discount.DiscountRate);
                            discount.DiscountQty -= (int)iCount;
                        }
                        else
                            dDeduct = 0;

                        sc.Deduct = dDeduct;
                        sc.TotalPrice -= sc.Deduct;
                    }
                    if (sc.TotalPrice <= 0) //防呆
                    {
                        sc.Deduct = 0;
                        sc.TotalPrice = (sc.UnitPrice * sc.Quantity);
                    }
                    break;
                }
            }
        }

        /// <summary>計算Set Mode下，可以折扣數量</summary>
        public static int? GetSetModeCount(Icon.Member.ShoppingCart sc, Icon.Member.Discount discount)
        {
            int? iCount = sc.Quantity;

            if (discount.DiscountQty == 0)
                iCount = 0;
            else if (sc.Quantity > discount.DiscountQty && discount.DiscountQty < discount.QtyH)
            {
                iCount = discount.DiscountQty;
            }
            else if (discount.DiscountQty == discount.QtyH && sc.Quantity >= discount.QtyH) //只取discount.QtyH的倍數
            {
                iCount = sc.Quantity / discount.QtyH;
                iCount *= discount.QtyH;
            }

            if (iCount < 0)
                iCount = 0;
            return iCount;
        }

        /// <summary>刪除訂單</summary>
        public static void DeleteOrder(Hashtable htParams)
        {
            DAL.DeleteOrder(htParams);
        }

        /// <summary>取得產品購物資訊</summary>
        public static DataTable GetProductOrderInfo(object CatalogItemID, object CampaignID)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("CatalogItemID", CatalogItemID);
            htParams.Add("CampaignID", CampaignID);

            return DAL.GetProductOrderInfo(htParams);
        }

        /// <summary>取得Discount Qty</summary>
        public static int GetOrderDiscountQty(int iQty, bool bWithTotal, int iCatalogID)
        {
            int iTotalQty = iQty;
            if (Icon.Definition.ShoppingCartList != null)
            {
                foreach (Icon.Member.ShoppingCart sc in Icon.Definition.ShoppingCartList)
                {
                    if (bWithTotal)
                    {
                        iTotalQty += (int)sc.Quantity;
                    }
                    else if (!bWithTotal && iCatalogID == sc.CatalogID) //不算其他的Catalog
                    {
                        iTotalQty += (int)sc.Quantity;
                    }
                }
            }
            return iTotalQty;
        }

        /// <summary>取得Catalog Discount Information，並判斷是否符合Catalog購買數量限制</summary>
        public static void GetCatalogDiscount(string strCatalogItemID, ref int iQty, ref bool bReault, ref string strMessage)
        {
            bool bWithTotal = false;
            string strDiscountMode = "";
            int iCatalogID = DAL.GetCatalogID(strCatalogItemID, ref strDiscountMode, ref bWithTotal);
            bool bExist = false;

            if (Icon.Definition.CatalogDiscountList != null)
            {
                foreach (Icon.Member.Discount discount in Icon.Definition.CatalogDiscountList)
                {
                    if (discount.CatalogID == iCatalogID) //Catalog已存在，取得Qty
                    {
                        bExist = true;
                        if (discount.LimitQty > 0 && discount.Remaining >= iQty)
                        {
                            discount.Remaining -= iQty;
                        }
                        else if (discount.LimitQty > 0 && discount.Remaining < iQty && discount.Remaining > 0) //購買數量大於限制
                        {
                            iQty = discount.Remaining;
                            discount.Remaining = 0;
                            strMessage = "The quantity is limited " + discount.LimitQty.ToString() + " in this Catalog.";

                        }
                        else if (discount.LimitQty > 0 && discount.Remaining < iQty && discount.Remaining <= 0) //已經不能再買了
                        {
                            bReault = false;
                            strMessage = "The quantity is limited " + discount.LimitQty.ToString() + " in this Catalog.";
                            return;
                        }
                        UpdateDiscountSession(discount, discount.CatalogID, iQty, discount.WithTotal, discount.Mode, bExist);
                    }
                    else if (discount.CatalogID != iCatalogID && discount.WithTotal)
                    {
                        //因為有算到其他Catalog，購買數量變動就要更新
                        UpdateDiscountSession(discount, discount.CatalogID, iQty, discount.WithTotal, discount.Mode, true);
                    }

                    if (Icon.Definition.CatalogDiscountList.Count == 0)//更新後，Discount可能被清除
                        break;
                }
            }
            if (!bExist)
            {
                UpdateDiscountSession(null, iCatalogID, iQty, bWithTotal, strDiscountMode, bExist);
            }
        }

        /// <summary>更新或新增discount Session</summary>
        private static void UpdateDiscountSession(Icon.Member.Discount discountNew, int iCatalogID, int iQty, bool bWithTotal, string strDiscountMode, bool bExist)
        {
            //重算Discount數量
            int iTotalQty = GetOrderDiscountQty(iQty, bWithTotal, iCatalogID);
            Hashtable htParams = new Hashtable();
            htParams.Add("CatalogID", iCatalogID);
            htParams.Add("Qty", iTotalQty);

            DataTable dt = DAL.GetCatalogDiscount(htParams, strDiscountMode);

            //更新或新增discount Session
            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                if (discountNew == null) //不存在，新建一個
                {
                    discountNew = new Icon.Member.Discount();
                    discountNew.Mode = strDiscountMode;
                    discountNew.WithTotal = bWithTotal;
                    if (Convert.ToString(dr["LimitQty"]).Trim() != "")
                    {
                        discountNew.LimitQty = Convert.ToInt32(dr["LimitQty"]);
                        if (discountNew.Remaining == 0)
                        {
                            discountNew.Remaining = discountNew.LimitQty;
                            discountNew.Remaining -= iQty;
                        }
                    }
                }
                if (discountNew != null)
                {
                    discountNew.CatalogID = Convert.ToInt32(dr["CatalogID"]);
                    discountNew.QtyH = Convert.ToInt32(dr["QtyH"]);
                    discountNew.QtyL = Convert.ToInt32(dr["QtyL"]);
                    discountNew.Amount = iTotalQty;

                    discountNew.DiscountQty = SetDiscountQty(discountNew.Amount, discountNew.QtyH);

                    if (Convert.ToString(dr["Discount"]).Trim() == "")
                        discountNew.DiscountRate = -1;
                    else
                        discountNew.DiscountRate = Convert.ToDecimal(dr["Discount"]);

                    if (Convert.ToString(dr["Deduct"]).Trim() == "")
                        discountNew.Deduct = -1;
                    else
                        discountNew.Deduct = Convert.ToDecimal(dr["Deduct"]);

                    if (!bExist)
                        Icon.Definition.CatalogDiscountList.Add(discountNew);
                }
            }
            else
            {
                if (bExist && discountNew != null) //原本有折扣，更改後沒有要刪掉
                {
                    Icon.Definition.CatalogDiscountList.Remove(discountNew);
                }
            }
        }

        /// <summary>Set Mode下用，設定最多折扣數，為QtyH的倍數</summary>
        public static int SetDiscountQty(int iTotalQty, int iQtyH)
        {
            int iQuo = 0;
            int iDiscountQty = iQtyH;//預設為折扣上限，計算過在扣掉
            if (iQtyH > 0)
            {
                iQuo = iTotalQty / iQtyH;
                if (iQuo > 0)
                    iDiscountQty = iQuo * iQtyH; //倍數
            }
            return iDiscountQty;
        }
        #endregion

        #region 系統參數相關
        /// <summary>
        /// 取得系統參數
        /// </summary>
        public static DataTable GetSystemParams(string paramType)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("ParamType", paramType);

            return DAL.GetSystemParams(htParams);
        }
        #endregion

        #region 產品相關
        /// <summary>
        /// 取得相關產品資料
        /// </summary>
        public static DataTable GetProductRelated(string catno, string type)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("CatNo", catno);
            htParams.Add("Type", type);
            return DAL.GetProductRelated(htParams);
        }

        /// <summary>
        /// 取得產品相關的文獻資料
        /// </summary>
        public static DataTable GetProductReference(string catno)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("CatNo", catno);

            return DAL.GetProductReference(htParams);
        }

        /// <summary>
        ///　取得第一層節點ResearchArea資料
        /// </summary>
        public static DataTable GetFirstNodeResearchArea()
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("Type", "ResearchArea");

            DataTable dtView = DAL.GetFirstNodeResearchArea(htParams);
            return dtView;
        }

        /// <summary>
        /// 取得指定分類的所有樹狀資料
        /// </summary>
        public static DataTable GetAllNodeProductMap(string val)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("Type", "ProductMapClass");
            htParams.Add("Value", val);

            DataTable dtView = DAL.GetProductMapInfo(htParams);
            return dtView;
        }

        /// <summary>
        /// 只取得第一層的樹狀節點資料
        /// </summary>
        public static DataRow[] GetAllNodeProductMap(string val, int iS_id)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("Type", "ProductMapClass");
            htParams.Add("Value", val);

            DataTable dtView = DAL.GetProductMapInfo(htParams);
            DataRow[] rowArray = dtView.Select("s_Id=" + iS_id, "Id");
            return rowArray;
        }

        /// <summary>取得前20筆最新產品</summary>
        public static DataTable GetTopNewProducts()
        {
            Hashtable htParams = new Hashtable();
            return DAL.GetTopNewProducts(htParams);
        }

        /// <summary>取得前20筆Best Buy Product</summary>
        public static DataTable GetBestBuy()
        {
            Hashtable htParams = new Hashtable();
            return DAL.GetBestBuy(htParams);
        }

        /// <summary>取得某Campaign的資料</summary>
        public static DataTable GetCampaignData(object CampaignCode)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("CampaignCode", CampaignCode);

            return DAL.GetCampaignData(htParams);
        }

        /// <summary>取得所有上架型錄資料</summary>
        public static DataTable GetAllCatalog()
        {
            DataTable dt = DAL.GetCatalogInfo();
            string strCampaignCodeArray = Definition.GetCampaignCodeString();
            strCampaignCodeArray = strCampaignCodeArray == "" ? "''" : strCampaignCodeArray;

            dt.DefaultView.RowFilter = string.Format("(ShowInList=1) AND ((CampaignCode IS NULL) OR (CampaignCode IN ({0})))", strCampaignCodeArray);
            return dt.DefaultView.ToTable();
        }

        /// <summary>取得固定型錄資料</summary>
        public static DataTable GetStaticCatalog()
        {
            DataTable dt = DAL.GetCatalogInfo();

            //找出固定型錄資料
            dt.DefaultView.RowFilter = string.Format("ShowInList=1 AND CampaignID IS NULL");
            return dt.DefaultView.ToTable();
        }

        /// <summary>取得變動型錄資料</summary>
        public static DataTable GetDynamicCatalog()
        {
            DataTable dt = DAL.GetCatalogInfo();

            //取得CampaignCodeArray
            string strCampaignCodeArray = Definition.GetCampaignCodeString();
            strCampaignCodeArray = (strCampaignCodeArray == "" ? "Null" : strCampaignCodeArray);
            strCampaignCodeArray = "'AAAA'"; //測試資料

            //找出變動型錄資料
            dt.DefaultView.RowFilter = string.Format("ShowInList=1 AND CampaignCode IN ({0})", strCampaignCodeArray);
            dt.DefaultView.Sort = "CatalogID, Discount";
            DataTable dtCatalog = dt.DefaultView.ToTable();

            //複製結構
            DataTable dtNew = dtCatalog.Copy();
            dtNew.Rows.Clear();

            //循序建立相異的Row，若有重複Catalog，則取最大Discount
            foreach (DataRow row in dtCatalog.DefaultView.ToTable(true, new string[] { "CatalogID" }).Rows)
            {
                object[] ItemArray = dtCatalog.Select("CatalogID=" + row["CatalogID"].ToString())[0].ItemArray;
                dtNew.Rows.Add(ItemArray);
            }
            return dtNew;
        }

        /// <summary>取得型錄的產品資料</summary>
        public static DataTable GetCatalogProduct(Hashtable htParams)
        {
            return DAL.GetCatalogProduct(htParams);
        }

        /// <summary>取得前5筆試用產品</summary>
        public static DataTable GetTop5FreeTrialProduct()
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("ActionType", "Top5FreeTrial");

            return DAL.GetCatalogProduct(htParams);
        }

        /// <summary>取得CatalogItemID</summary>
        public static int GetCatalogItemID(object catno, object catalogitemid)
        {
            //若沒傳CatalogItemID，則進資料庫取出All Product的ItemID
            if (catalogitemid == null || catalogitemid.ToString() == "")
            {
                Hashtable htParams = new Hashtable();
                htParams.Add("CatNo", catno);

                return DAL.GetCatalogItemID(htParams);
            }
            else
            {
                return int.Parse(catalogitemid.ToString());
            }
        }

        /// <summary>取得CatNo</summary>
        public static string GetCatNo(object catno, object catalogitemid)
        {
            if (catno == null || catno.ToString() == "")
            {
                Hashtable htParams = new Hashtable();
                htParams.Add("CatalogItemID", catalogitemid);

                return DAL.GetCatNo(htParams);
            }
            else
            {
                return catno.ToString();
            }
        }

        /// <summary>轉換產品內容資料及格式</summary>
        public static void ChangeProductDetailData(DataRow rowDetail)
        {
            string SupplierName = rowDetail["SupplierName"].ToString();
            string SupplierCatNo = rowDetail["SupplierCatNo"].ToString();

            //若供應商為Abnova
            if (SupplierName.Trim().ToLower() == "abnova")
            {
                //增加Manufacturer_MfgPart欄位
                rowDetail.Table.Columns.Add("Manufacturer_MfgPart", Type.GetType("System.String"));

                rowDetail["Manufacturer_MfgPart"] = string.Format("{0} {1}<br />{2}",
                                                        SupplierName,
                                                        SupplierCatNo,
                                                        "Only available to US end-users. Not available outside of the US or for resale inside of the US.");
            }

            //若此產品狀態為Update，則還原成Update前的資料
            string CatNo = rowDetail["CatNo"].ToString();
            string Status = rowDetail["Status"].ToString();
            if (Status.ToLower() == "update")
            {
                //讀取UpdateLog
                string strUpdateLog = DAL.GetProductUpdateLog(CatNo);
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(strUpdateLog);

                //循序讀取異動的欄位
                foreach (XmlNode node in xmlDoc.SelectNodes("Fields/Field"))
                {
                    string strFieldName = node.Attributes["Name"].Value;
                    string strOldValue = node.SelectSingleNode("OldValue").InnerText;

                    if (rowDetail.Table.Columns.Contains(strFieldName)) { rowDetail[strFieldName] = strOldValue; } //還原值
                }
            }
        }

        /// <summary>取得首頁的Special Offer資料</summary>
        public static DataTable GetHomePagePromotionProducts()
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("Type", "C");

            return DAL.GetHomePagePromotionProducts(htParams);
        }

        /// <summary>取得變動型錄的產品資料</summary>
        public static DataTable GetCampaignCatalogProduct(object CampaignID)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("CampaignID", CampaignID);

            //取回變動型錄的產品
            DataTable dt = DAL.GetCampaignCatalogProduct(htParams);
            return dt;
        }

        /// <summary>取得產品內容</summary>
        public static DataTable GetProductDetail(object CatalogItemID)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("CatalogItemID", CatalogItemID);

            return DAL.GetProductDetail(htParams);
        }

        /// <summary>取得型錄的前幾筆圖片</summary>
        public static DataTable GetTopNCampaignImages(object CampaignID, object TopN)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("CampaignID", CampaignID);

            return DAL.GetTopNCampaignImages(htParams, TopN);
        }

        /// <summary>取得產品的圖片</summary>
        public static DataTable GetProductImages(object catno)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("CatNo", catno);

            return DAL.GetProductImages(htParams);
        }

        /// <summary>
        /// 根據當前登陸用戶的IP,顯示其IP對應的國家的經銷商的資訊
        /// </summary>
        /// <param name="htParams"></param>
        /// <returns></returns>
        public static DataTable GetLocalDealers(Hashtable htParams)
        {
            return DAL.GetLocalDealers(htParams);
        }

        /// <summary>取得Catalog的產品List</summary>
        public static DataTable GetListByCatalog(Hashtable htParams, ref DataTable ProductClassRelTable, ref DataTable ResearchAreaRelTable)
        {
            return DAL.GetListByCatalog(htParams, ref ProductClassRelTable, ref ResearchAreaRelTable);
        }

        /// <summary>取得Campaign的產品List</summary>
        public static DataTable GetListByCampaign(Hashtable htParams, ref DataTable ProductClassRelTable, ref DataTable ResearchAreaRelTable)
        {
            return DAL.GetListByCampaign(htParams, ref ProductClassRelTable, ref ResearchAreaRelTable);
        }

        /// <summary>取得相關GeneID的產品List</summary>
        public static DataTable GetListByRelatedProduct(Hashtable htParams, ref DataTable ProductClassRelTable, ref DataTable ResearchAreaRelTable)
        {
            return DAL.GetListByRelatedProduct(htParams, ref ProductClassRelTable, ref ResearchAreaRelTable);
        }

        /// <summary>取得Keyword Search的產品List</summary>
        public static DataTable GetListByKeywordSearch(Hashtable htParams, ref DataTable ProductClassRelTable, ref DataTable ResearchAreaRelTable)
        {
            return DAL.GetListByKeywordSearch(htParams, ref ProductClassRelTable, ref ResearchAreaRelTable);
        }

        /// <summary>取得Catalog的訊息</summary>
        public static string GetCatalogMessage(object CatalogID)
        {
            return DAL.GetCatalogMessage(CatalogID);
        }

        /// <summary>取得Campaign的訊息</summary>
        public static string GetCampaignMessage(object CampaignCode)
        {
            return DAL.GetCampaignMessage(CampaignCode);
        }

        /// <summary>針對CatNo取得對應的分類內容值</summary>
        public static string GetProductClassValue(object CatNo, object Type, bool isFullName)
        {
            return DAL.GetProductClassValue(CatNo, Type, isFullName);
        }

        /// <summary>指定取得某產品項目分類</summary>
        public static DataRow GetProductClassItem(Hashtable htParams)
        {
            DataRow row = DAL.GetProductClassItem(htParams);
            return row;
        }

        /// <summary>取得CatalogID或CampaignCode指定的資料</summary>
        public static DataRow GetCatalogData(Hashtable htParams)
        {
            DataRow row = null;
            DataTable dtCatalog = DAL.GetCatalogInfo();

            string strCatalogID = Convert.ToString(htParams["CatalogID"]);
            string strCampaignCode = Convert.ToString(htParams["CampaignCode"]);

            if (!string.IsNullOrEmpty(strCatalogID))
            {
                row = dtCatalog.Select("CatalogID=" + strCatalogID)[0];
            }
            else if (!string.IsNullOrEmpty(strCampaignCode))
            {
                row = dtCatalog.Select("CampaignCode='" + strCampaignCode + "'")[0];
            }

            return row;
        }

        /// <summary>取得CatNo對應的BioInformation資料</summary>
        public static DataTable GetBioInformationList(string CatNo, string SupplierName)
        {
            DataTable dtResult = null;
            if (SupplierName.ToLower() == "iconbio")
            {
                CatNo = CatNo.Replace("GTX1", "");
                int iPJ = Convert.ToInt32(CatNo);

                dtResult = DAL.GetBioInformationList(iPJ);
            }

            return dtResult;
        }

        /// <summary>取得產品對應的Kits資料</summary>
        public static DataTable GetProductKitData(object CatNo)
        {
            return DAL.GetProductKitData(CatNo);
        }

        /// <summary>取得ResearchArea對應AllProduct分類資料</summary>
        public static DataTable GetResearchAreaData()
        {
            return DAL.GetResearchAreaData();
        }

        public static string GetCatalogID(Hashtable htParams)
        {
            return DAL.GetCatalogID(htParams);
        }

        #endregion

        #region 寄信相關 yunyu

        // <summary>
        /// ContactUs的內容加入資料庫並寄信
        /// </summary>
        public static void InsertContactUs(ref bool bResult, ref string strMessage, Hashtable htParams)
        {
            TemplateEmail email = new TemplateEmail("CONTACTUS");
            email.TemplateParams["{link}"] = strMessage;

            bool bSendOK = email.SendEmail(new MailAddress(htParams["Email"].ToString()), new MailAddress(htParams["Receiver"].ToString()),
                                "GeneTex WebSite General Question");

            //寄信成功,再寫入資料庫
            if (bSendOK)
            {
                GetMessageID(htParams, strMessage);
                DAL.InsertContactUs(out bResult, out strMessage, htParams);
            }
            else if (!bSendOK)
                bResult = false;
        }

        /// <summary>
        /// 連絡業務的內容加入資料庫並寄信
        /// </summary>
        public static void InsertContactSales(out bool bResult, out string strMessage, Hashtable htParams)
        {
            bResult = false;
            strMessage = "Error!";
            TemplateEmail email = new TemplateEmail("CONTACTSALES");
            email.TemplateParams["{email}"] = htParams["SenderEmail"].ToString();
            email.TemplateParams["{username}"] = htParams["UserName"].ToString();
            email.TemplateParams["{company}"] = htParams["Company"].ToString();
            email.TemplateParams["{country}"] = htParams["Country"].ToString();
            email.TemplateParams["{state}"] = htParams["State"].ToString();
            email.TemplateParams["{phone}"] = htParams["Phone"].ToString();
            email.TemplateParams["{context}"] = htParams["Content"].ToString();
            email.TemplateParams["{subject}"] = htParams["Subject"].ToString();

            bool bSendOK = email.SendEmail(new MailAddress(htParams["SenderEmail"].ToString()), new MailAddress("support@genetex.com"),
                                "ContactSales");

            //寄信成功,再寫入資料庫
            if (bSendOK)
                DAL.InsertContactSales(out bResult, out strMessage, htParams);
            else if (!bSendOK)
                bResult = false;
        }

        /// <summary>
        /// Support的內容加入資料庫並寄信
        /// </summary>
        public static void InsertSupport(ref bool bResult, ref string strMessage, Hashtable htParams)
        {
            TemplateEmail email = new TemplateEmail("SUPPORT");
            email.TemplateParams["{link}"] = strMessage;

            bool bSendOK = email.SendEmail(new MailAddress(htParams["SenderEmail"].ToString()), new MailAddress(htParams["Receiver"].ToString()),
                                "GeneTex WebSite Technical Support ");
            //寄信成功,再寫入資料庫
            if (bSendOK)
            {
                GetMessageID(htParams, strMessage);
                DAL.InsertSupport(out bResult, out strMessage, htParams);
            }
            else if (!bSendOK)
                bResult = false;
        }

        private static void GetMessageID(Hashtable htParams, string strMessage)
        {
            Security security = new Security();
            string strPat = "&m=";
            int iStart = strMessage.LastIndexOf(strPat) + strPat.Length;
            string strMessageID = strMessage.Substring(iStart);

            int iMessageID = Convert.ToInt32(security.DecryptQueryString(strMessageID));
            htParams.Add("MessageID", iMessageID);

        }

        /// <summary>
        /// 做完問卷後，將訂單資訊加入資料庫並寄信
        /// </summary>
        public static void InsertSurveyLog(ref bool bResult, ref string strMessage, Hashtable htParams)
        {
            TemplateEmail email = new TemplateEmail("SURVEY");

            email.TemplateParams["{name}"] = htParams["Name"].ToString();
            email.TemplateParams["{email}"] = htParams["SenderEmail"].ToString();
            email.TemplateParams["{ordernum}"] = htParams["OrderID"].ToString();
            email.TemplateParams["{date}"] = htParams["OrderDate"].ToString();

            bool bSendOK = email.SendEmail(new MailAddress(htParams["SenderEmail"].ToString()), new MailAddress(htParams["Receiver"].ToString()),
                                "GeneTex WebSite Survey ");
            //寄信成功,再寫入資料庫
            htParams.Remove("Name");
            htParams.Remove("SenderEmail");
            htParams.Remove("Receiver");
            htParams.Remove("OrderDate");

            if (bSendOK)
            {
                //GetIPInfo(htParams);
                DAL.InsertSurveyLog(out bResult, out strMessage, htParams);
            }
            else if (!bSendOK)
                bResult = false;
        }

        /// <summary>
        /// 新會員通知信
        /// </summary>
        public static bool SendNewMemberMail(Hashtable htParams)
        {
            //Mail內容參數
            TemplateEmail email = new TemplateEmail("NEWACCOUNTEMAIL");
            email.TemplateParams["{firstname}"] = htParams["FirstName"].ToString();
            email.TemplateParams["{lastname}"] = htParams["LastName"].ToString();

            //發Mail函式參數
            MailAddress fromAddress = new MailAddress("support@genetex.com");
            MailAddress toAddress = new MailAddress(htParams["ToEmailAddress"].ToString());
            string strSubject = "Welcome to Genetex";

            //發Mail & 傳回發送狀態
            return email.SendEmail(fromAddress, toAddress, strSubject);
        }

        /// <summary>
        /// 訂單完成後寄信
        /// </summary>
        public static void SendOrderMail(Hashtable htParams, string strMailTo, ref string strMessage, ref bool bResult, bool bIsAdmin)
        {
            TemplateEmail email = new TemplateEmail();
            string strPath = HttpContext.Current.Request.PhysicalApplicationPath;
            if (bIsAdmin)
                email.TemplateFile = strPath + "/Modules/OrderTemplate/OrderMailForManager.htm";
            else
                email.TemplateFile = strPath + "/Modules/OrderTemplate/OrderMailTemplate.htm";
            email.ReadHtmlFile(htParams, strMailTo, "Order Confirmation", ref strMessage, ref bResult);
        }

        //訂單裡的Product Information用table表示
        public static void GetProductTable(Hashtable htParams, List<Member.ShoppingCart> ShoppingCartList)
        {
            int iCount = 0;
            string strOrder = "<table style=\"width: 450px\">";//Order Detail
            foreach (Member.ShoppingCart sc in ShoppingCartList)
            {
                iCount++;
                SetProductRow(iCount.ToString() + ".", sc.CatNo, sc.ProductName, sc.Quantity, ref strOrder);

                strOrder += "<tr>" + AddXmlNode("td", " ");
                strOrder += AddXmlNode("td", "Price:" + sc.UnitPrice) + "</tr>";
                strOrder += "<tr>" + AddXmlNode("td", " ");
                strOrder += AddXmlNode("td", "Item Total:" + sc.TotalPrice) + "</tr>";

                if (sc.CampaignCode != null)	//不是null才show
                {
                    strOrder += "<tr>" + AddXmlNode("td", " ");
                    strOrder += AddXmlNode("td", "CampaignCode:" + sc.CampaignCode) + "</tr>";
                }
                if (sc.IsKit)
                {
                    DataTable dtKit = BLL.GetProductKitData(sc.CatNo);
                    if (dtKit != null && dtKit.Rows.Count > 0)
                    {
                        int iKitCount = 0;
                        foreach (DataRow dr in dtKit.Rows)
                        {
                            iKitCount++;
                            SetProductRow(iCount + "-" + iKitCount, dr["CatNo"].ToString(), dr["ProductName"].ToString(), sc.Quantity, ref strOrder);
                        }
                    }
                }
                strOrder += "<tr style=\"height: 20px\"><td colspan='2'><hr/></td></tr>";//空一行
            }

            strOrder += "<tr>" + AddXmlNode("td", " ");
            strOrder += AddXmlNode("td", "Subtotal:" + htParams["GoodsPrice"]) + "</tr>";
            strOrder += "<tr>" + AddXmlNode("td", " ");
            strOrder += AddXmlNode("td", "Shipping Charge:" + htParams["ShippingPrice"]) + "</tr>";
            strOrder += "<tr>" + AddXmlNode("td", " ");
            strOrder += AddXmlNode("td", "Packaging/Handling Charge:" + htParams["HandlingPrice"]) + "</tr>";
            strOrder += "<tr>" + AddXmlNode("td", " ");
            strOrder += AddXmlNode("td", "Sales Tax:" + htParams["TaxRate"]) + "</tr>";
            strOrder += "<tr>" + AddXmlNode("td", " ");
            strOrder += AddXmlNode("td", "Dry Ice Price:" + htParams["DryIcePrice"]) + "</tr>";
            strOrder += "<tr>" + AddXmlNode("td", " ");
            strOrder += AddXmlNode("td", "Estimated Total:" + htParams["TotalPrice"]);
            strOrder += "</tr>";
            strOrder += "</table>";
            htParams.Add("{orderdetails}", strOrder);
        }

        //設定Kit相關資訊
        public static void SetProductRow(string strNo, string strCatNo, string ProductName, int? iQty, ref string strOrder)
        {
            strOrder += AddXmlNode("td", strNo);
            strOrder += AddXmlNode("td", "Cat No:" + strCatNo) + "</tr>";
            strOrder += "<tr>" + AddXmlNode("td", " ");
            strOrder += AddXmlNode("td", "Description:" + ProductName) + "</tr>";
            strOrder += "<tr>" + AddXmlNode("td", " ");
            strOrder += AddXmlNode("td", "Ordered Qty:" + iQty) + "</tr>";
            strOrder += "<tr>" + AddXmlNode("td", " ");
            
        }

        public static bool SendPasswordEmail(Hashtable htParams)
        {
            //Mail內容參數
            TemplateEmail email = new TemplateEmail("PASSWORDEMAIL");
            email.TemplateParams["{account}"] = htParams["Account"].ToString();
            email.TemplateParams["{password}"] = htParams["Password"].ToString();

            //發Mail函式參數
            MailAddress fromAddress = new MailAddress("support@genetex.com");
            MailAddress toAddress = new MailAddress(htParams["ToEmailAddress"].ToString());
            string strSubject = "Send Password from Genetex Web";

            //發Mail & 傳回發送狀態
            return email.SendEmail(fromAddress, toAddress, strSubject);
        }

        #endregion

        #region 產品搜尋相關 yunyu
        /// <summary>
        /// 依參數(字母，數字)找尋產品資訊
        /// </summary>
        public static DataTable GetProductsByParam(Hashtable htParams)
        {
            DataTable dtProducts = DAL.GetProductsByParam(htParams);
            return dtProducts;
        }

        /// <summary>
        /// 用CatNo找相關的PubMed文獻,傳回term的內容
        /// </summary>
        public static string GetPubMed(string strCatNo)
        {
            string strTerm = "";
            DataTable dtPubMed = DAL.GetPubMed(strCatNo);
            if (dtPubMed != null && dtPubMed.Rows.Count > 0)
            {
                foreach (DataRow dr in dtPubMed.Rows)
                {
                    if (dr["PubMed"].ToString().Trim() != "")
                        strTerm += dr["PubMed"].ToString().Trim() + " ";
                }

            }
            return strTerm.TrimEnd(' ');
        }

        /// <summary>
        /// 取得貨幣資料
        /// </summary>
        public static DataTable GetCurrency()
        {
            DataTable dtCurrency = DAL.GetCurrency();
            return dtCurrency;
        }

        /// <summary>
        /// 轉換金錢格式
        /// </summary>
        public static string SetMoneyFormat(string strCurrency, string strValue, int iDecimal)
        {
            if (decimal.Parse(strValue) > 0)
            {
                strValue = string.Format(strCurrency + " ${0:N" + iDecimal + "}", decimal.Parse(strValue));
            }
            else
            {
                strValue = " - ";
            }
            return strValue;
        }

        /// <summary>
        /// 依參數(字母，數字)找尋產品資訊
        /// </summary>
        public static DataTable GetProductsByAdvanced(Hashtable htParams)
        {
            DataTable dtProducts = DAL.GetProductsByAdvanced(htParams);
            return dtProducts;
        }

        /// <summary>
        /// 寫入SearchLog進資料庫
        /// </summary>
        public static void InsertSearchLog(ref bool bResult, ref string strMessage, Hashtable htParams)
        {
            GetIPInfo(htParams);
            DAL.InsertSearchLog(out bResult, out strMessage, htParams);
        }

        //用IP找國家，城市
        private static void GetIPInfo(Hashtable htParams)
        {
            string strIP = htParams["IP"].ToString();
            if (!strIP.Contains("unknown"))
            {
                string strPath = AppDomain.CurrentDomain.RelativeSearchPath + "\\";
                IPInfo.IPInfo ipinfo = new IPInfo.IPInfo(strPath);
                bool bIsOK = ipinfo.GetIPInfo(strIP);
                if (bIsOK)
                {
                    htParams["FromCountry"] = ipinfo.CountryName;
                    htParams["FromCity"] = ipinfo.City;
                    htParams["FromCountryCode"] = ipinfo.CountryCode;
                }
            }
        }

        /// <summary>
        /// 過濾IP，濾掉iconbio,本機和genetex
        /// </summary>
        public static bool FilterIP(string strIP)
        {
            bool bFilter = false;
            if (strIP == "10.71.30.203" || strIP == "127.0.0.1")
                bFilter = true;
            else if (strIP.Contains("192.168.1.")) //內網
                bFilter = true;
            else if (strIP.Contains("64.81.47.")) //來至GeneTex
            {
                int iIndex = strIP.LastIndexOf(".") + 1;
                int iTmpIP = Convert.ToInt32(strIP.Substring(iIndex));
                if (iTmpIP <= 222 && iTmpIP >= 193)
                    bFilter = true;
            }

            return bFilter;
        }

        /// <summary>取得產品搜尋是否有結果</summary>
        public static bool GetProductSearchResult(object KeyWord, string strField)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("KeyWord", "%" + KeyWord + "%");

            return DAL.GetProductSearchResult(htParams, strField);
        }

        /// <summary>取得KeyWordSearch對應的Symbol,Synonyms資料</summary>
        public static DataTable GetKeyWrodSearchSymbol(object KeyWord)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("KeyWord", "%" + KeyWord + "%");

            return DAL.GetKeyWrodSearchSymbol(htParams);
        }

        /// <summary>取得ProductSearch的產品資料</summary>
        public static DataTable GetProductSearchList(object KeyWord)
        {
            Hashtable htParams = new Hashtable();
            htParams.Add("KeyWord", "%" + KeyWord + "%");

            return DAL.GetProductSearchList(htParams);
        }
        #endregion

        #region 靜態頁面搜尋相關 yunyu
        /// <summary>
        /// 搜尋靜態頁面資訊
        /// </summary>
        public static DataTable GetStaticPage(Hashtable htParams)
        {
            DataTable dtStaticPage = DAL.GetStaticPage(htParams);
            return dtStaticPage;
        }

        /// <summary>
        /// 搜尋靜態頁面資訊，回傳型態string
        /// </summary>
        public static string GetStaticPageForString(Hashtable htParams)
        {
            DataTable dtStaticPage = DAL.GetStaticPage(htParams);
            string strContext = "";
            if (dtStaticPage != null && dtStaticPage.Rows.Count == 1)
            {
                strContext = dtStaticPage.Rows[0]["Description"].ToString();
                dtStaticPage.Dispose();
            }
            return strContext;
        }

        //取得Forum名稱
        public static DataTable GetForum(string strCategory)
        {
            DataTable dt = DAL.GetForum(strCategory);
            return dt;
        }

        //取得Forum名稱(只有一個時)
        public static object GetForumByOne(string strCategory)
        {
            DataTable dt = DAL.GetForum(strCategory);
            object oForumID = 0;
            if (dt.Rows.Count == 1)
            {
                oForumID = dt.Rows[0]["ForumID"];
            }
            return oForumID;
        }


        #endregion

        #region Public頁面相關

        /// <summary>
        /// 取得前幾筆PromotionNews資料
        /// </summary>
        public static DataTable GetTopNPromotionNews(int iRowCount)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("Type", "Promotion");
            htParams.Add("Enabled", 1);

            //刪除數目之外的資料
            DataTable dtNews = DAL.GetNews(htParams);
            int iCount = 1;
            foreach (DataRow row in dtNews.Rows)
            {
                if (iCount > iRowCount) { row.Delete(); }
                iCount++;
            }
            return dtNews;
        }

        /// <summary>
        /// 取得第一筆最新消息
        /// </summary>
        public static DataRow GetTop1News()
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("Type", "News");
            htParams.Add("Enabled", 1);

            //取得第一筆消息
            DataTable dtNews = DAL.GetNews(htParams);
            if (dtNews.Rows.Count > 0)
            {
                return dtNews.Rows[0];
            }

            return null;
        }

        /// <summary>
        /// 取得第一筆Welcome消息
        /// </summary>
        public static DataRow GetTop1WelcomeNews()
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("Type", "Welcome");
            htParams.Add("Enabled", 1);

            //取得第一筆消息
            DataTable dtNews = DAL.GetNews(htParams);
            if (dtNews.Rows.Count > 0)
            {
                return dtNews.Rows[0];
            }

            return null;
        }

        /// <summary>
        /// 取得所有消息
        /// </summary>
        public static DataTable GetAllNews(Hashtable htParams)
        {
            return DAL.GetNews(htParams);
        }

        /// <summary>
        /// 取得最新一筆系統公告
        /// </summary>
        public static DataRow GetSystemTop1News(Hashtable htParams)
        {
            DataTable dtNews = DAL.GetNews(htParams);

            //依起始日期反序
            DataRow[] rowArray = dtNews.Select("", "StartDate DESC");

            //回傳第一筆資料
            if (rowArray.Length > 0)
                return rowArray[0];
            else
                return null;
        }

        /// <summary>
        /// 取得指定ID的新聞
        /// </summary>
        public static DataRow GetNewsContent(Hashtable htParams, string NewsID)
        {
            DataTable dtNews = DAL.GetNews(htParams);

            //依起始日期反序
            DataRow[] rowArray = dtNews.Select("Id=" + NewsID);

            //回傳第一筆資料
            if (rowArray.Length > 0)
                return rowArray[0];
            else
                return null;
        }

        /// <summary>
        /// 取得所有公司資料
        /// </summary>
        public static DataTable GetCompany(string strType, string strCode)
        {
            return DAL.GetCompany(strType, strCode);
        }

        public static string GetCountryCode(Hashtable htParams)
        {
            GetIPInfo(htParams);
            if (htParams["FromCountryCode"] == null)
                return "NoCountryCode";
            else
                return htParams["FromCountryCode"].ToString();
        }

        /// <summary>取得巡覽列名稱</summary>
        public static string GetNavigatorName(string strSQL)
        {
            return DAL.GetNavigatorName(strSQL);
        }
        #endregion

        #region 論壇相關 yunyu

        /// <summary>將資訊Send to forum</summary>
        public static void SendInfoToForum(string strXml, string strRoot, string strEmail, ref string strMessage, ref bool bResult)
        {
            //以EMail當Fforum的Account
            strXml += AddXmlNode("CountryCode", Definition.CountryCode);
            strXml += AddXmlNode("UserName", strEmail);

            //自己給Password,用email(開頭到@)
            string strPwd = strEmail.Remove(strEmail.IndexOf('@') + 1);
            string[] ch = { "Z", "Y", "X", "W", "R", "T" };
            if (strPwd.Length < 6)
            {
                for (int i = strPwd.Length; i <= 6; i++)
                {
                    strPwd += ch[i - 1];
                }
            }
            strXml += AddXmlNode("Password", strPwd);
            strXml += string.Format("</{0}>", strRoot);

            wsForum wsforum = new wsForum();
            wsforum.Action("POST", strXml, strRoot, ref strMessage, ref bResult);
        }

        //更新使用者論壇的Email
        public static void ModifyEmailToForum(string strOld, string strNew, ref string strMessage, ref bool bResult)
        {
            string strRoot = "GeneTexForum";
            string strXml = string.Format("<{0}>", strRoot);
            strXml += BLL.AddXmlNode("OldEmail", strOld);
            strXml += BLL.AddXmlNode("NewEmail", strNew);
            strXml += string.Format("</{0}>", strRoot);

            wsForum wsforum = new wsForum();
            wsforum.Action("MODIFYEMAIL", strXml, strRoot, ref strMessage, ref bResult);
        }


        //確認Forum User
        public static void GotoForum(string strEmail, ref string strMessage, ref bool bResult)
        {
            string strRoot = "GeneTexForum";
            string strXml = string.Format("<{0}>", strRoot);
            strXml += BLL.AddXmlNode("Email", strEmail);
            strXml += BLL.AddXmlNode("Page", "longin");
            strXml += string.Format("</{0}>", strRoot);

            wsForum wsforum = new wsForum();
            wsforum.Action("CONFIRMUSER", strXml, strRoot, ref strMessage, ref bResult);
        }

        /// <summary>將Node加入Xml字串</summary>
        public static string AddXmlNode(object oNode, object oValue)
        {
            string strXmlNods = string.Format("<{0}>{1}</{0}>", oNode, oValue);
            return strXmlNods;
        }

        //取Xml值
        public static string GetXmlNodeValue(string strNode, string strRoot, string strXml)
        {
            string strValue = "";
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(strXml);
            string strXPath = string.Format("{0}/{1}", strRoot, strNode);
            strValue = xmlDoc.SelectSingleNode(strXPath).InnerText;
            return strValue;
        }

        #endregion

        #region Campaign相關 yunyu

        /// <summary>取得Campaign的顯示訊息</summary>
        public static string GetCampaignMessageByID(object oCampaignID)
        {
            return DAL.GetCampaignMessageByID(oCampaignID);
        }

        public static string GetCamapignCode(object oCampaignID)
        {
            return DAL.GetCamapignCode(oCampaignID);
        }

        /// <summary>寫入Camapign Click進資料庫</summary>
        public static void InsertCamapignClick(ref bool bResult, ref string strMessage, Hashtable htParams, object oMemberID)
        {
            DAL.InsertCamapignClick(ref bResult, ref strMessage, htParams, oMemberID);
        }

        #endregion

        #region Catalog List相關 yunyu

        public static DataTable GetCatalogList()
        {
            return DAL.GetCatalogList();
        }

        public static DataRow GetCatalogDetail(object oID, object oCampaignCode)
        {
            DataTable dt = DAL.GetCatalogDetail(oID, oCampaignCode);

            if (dt == null || dt.Rows.Count == 0)
                return null;
            else
                return dt.Rows[0];
        }

        #endregion

        //得到TOP N
        public static DataTable SelectTop(int Top, DataTable oDT)
        {
            if (oDT == null) return null;
            if (oDT.Rows.Count < Top) return oDT;

            DataTable NewTable = oDT.Clone();
            DataRow[] rows = oDT.Select("1=1");
            for (int i = 0; i < Top; i++)
            {
                NewTable.ImportRow((DataRow)rows[i]);
            }
            oDT.Dispose();
            return NewTable;
        }
    }
}