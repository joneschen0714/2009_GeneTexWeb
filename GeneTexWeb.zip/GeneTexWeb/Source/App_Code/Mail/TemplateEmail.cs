﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Specialized;
using System.Net.Mail;
using System.Xml;
using System.IO;
using System.Collections;

/// <summary>
/// TemplateEmail 的摘要描述
/// </summary>
public class TemplateEmail
{
    #region Properties

    private string _templateName;

    public string TemplateName
    {
        get { return _templateName; }
        set { _templateName = value; }
    }

    private string _templateFile;
    public string TemplateFile
    {
        get
        {
            return _templateFile;
        }
        set
        {
            _templateFile = value;
        }
    }

    private bool _htmlEnabled;

    public bool HtmlEnabled
    {
        get { return _htmlEnabled; }
        set { _htmlEnabled = value; }
    }

    private StringDictionary _templateParams = new StringDictionary();
    public StringDictionary TemplateParams
    {
        get
        {
            return _templateParams;
        }
        set
        {
            _templateParams = value;
        }
    }

    #endregion

    public TemplateEmail()
        : this(null, true)
    {
        GetTemplateFile();
    }

    public TemplateEmail(string templateName)
        : this(templateName, true)
    {
        GetTemplateFile();
    }

    public TemplateEmail(string templateName, bool htmlEnabled)
    {
        _templateName = templateName;
        _htmlEnabled = htmlEnabled;
        GetTemplateFile();
    }

    /// <summary>
    /// 取得檔案路徑
    /// </summary>
    private void GetTemplateFile()
    {
        string strPath = HttpContext.Current.Request.PhysicalApplicationPath;
        _templateFile = strPath + "/App_Code/Mail/TemplateEmail.xml";
    }

    /// <summary>
    /// Creates an email from a template
    /// </summary>
    /// <returns></returns>
    public string ProcessTemplate(string templateName)
    {
        string email = GetText("TEMPLATES", templateName);

        if (!String.IsNullOrEmpty(email))
        {
            foreach (string key in _templateParams.Keys)
            {
                email = email.Replace(key, _templateParams[key]);
            }
        }

        return email;
    }

    public string GetText(string page, string tag)
    {
        string localizedText = GetTextInternal(page, tag);

        localizedText = localizedText.Replace("[b]", "<b>");
        localizedText = localizedText.Replace("[/b]", "</b>");
        return localizedText;
    }

    public string GetTextInternal(string strPage, string strTag)
    {
        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.Load(_templateFile);

        string select = string.Format("//page[@name='{0}']/Resource[@tag='{1}']", strPage.ToUpper(), strTag.ToUpper());
        XmlNode xmlPageNode = xmlDoc.SelectSingleNode(select);

        return xmlPageNode.InnerText;
    }

    /// <summary>
    /// 寄信
    /// </summary>
    /// <param name="fromAddress"></param>
    /// <param name="toAddress"></param>
    /// <param name="strSubject"></param>
    public bool SendEmail(MailAddress fromAddress, MailAddress toAddress, string strSubject)
    {
        string strTextBody = null, strHtmlBody = null;

        strTextBody = ProcessTemplate(TemplateName + "_TEXT").Trim();
        strHtmlBody = ProcessTemplate(TemplateName + "_HTML").Trim();

        // null out html if it's not desired
        if (!HtmlEnabled || String.IsNullOrEmpty(strHtmlBody)) strHtmlBody = null;

        // just send directly
        return SendMail.Send(fromAddress, toAddress, strSubject, strTextBody, strHtmlBody);
    }

	//read htm檔,並把keyword替換
	public bool ReadHtmlFile(Hashtable htParams, string strMailTo,string strSubject,ref string strMessage, ref bool bResult)
	{
		string strContent = "";
		if (File.Exists(_templateFile))
		{
			using (System.IO.StreamReader sr = System.IO.File.OpenText(_templateFile))
			{
				strContent = sr.ReadToEnd();
				foreach (string key in htParams.Keys)
				{
					object KayValue = htParams[key] ?? "";
					if (strContent.Contains(key))
					{
						strContent = strContent.Replace(key, KayValue.ToString());
					}
				}
				//while ((strTmp = sr.ReadLine()) != null)
				//{
				//    while (strTmp.Contains("{") && strTmp.Contains("}"))
				//    {
				//        foreach (string key in htParams.Keys)
				//        {
				//            object KayValue = htParams[key] ?? "";
				//            if (strTmp.Contains(key))
				//            {
				//                strTmp = strTmp.Replace(key, KayValue.ToString());
				//                break;
				//            }
				//        }
				//    }
				//    strContent += strTmp + "\r\n";
				//}
				sr.Close();
			}
		}
		if (strContent == "")
			bResult = false;
		else
		{
			if (strContent.Contains("{ordernum}"))
				strContent = strContent.Replace("{ordernum}", "");
			bResult = SendMail.Send("weborder@genetex.com", strMailTo, strContent, strSubject);
		}
		return bResult;
	}

    public string ReadHtmlFile(Hashtable htParams)
    {
        string strContent = "";
        if (File.Exists(_templateFile))
        {
            using (System.IO.StreamReader sr = System.IO.File.OpenText(_templateFile))
            {
                strContent = sr.ReadToEnd();
                foreach (string key in htParams.Keys)
                {
                    object KayValue = htParams[key] ?? "";
                    if (strContent.Contains(key))
                    {
                        strContent = strContent.Replace(key, KayValue.ToString());
                    }
                }
                sr.Close();
            }
        }

        return strContent;
    }

	// 把讀取的htm檔,複寫回去
	public bool WriteHtmlFile(string strContent)
	{
		if (strContent == "") return false;
		StreamWriter sw = new System.IO.StreamWriter(_templateFile, false);
		sw.Write(strContent);
		sw.Close();
		return true;
	}
}
