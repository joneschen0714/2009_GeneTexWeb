﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Address 的摘要描述
/// </summary>
public class Address
{
	public enum CountryCode { US = 0, TW = 1 }

	string m_strPage = "";
	CountryCode m_CC = CountryCode.US;

	public Address(string strPage)
	{
		m_strPage = strPage;
		if (ConfigurationManager.AppSettings["CountryCode"].ToString().ToUpper() == "TW")
			m_CC = CountryCode.TW;
	}

	//public string Sender
	//{
 
	//}

	public string Receiver
	{
		get
		{
			string strReceiver = "";
			switch (m_strPage)
			{
				case "ContactUs":
					if (m_CC == CountryCode.US)
						strReceiver = "info@genetex.com";
					else if (m_CC == CountryCode.TW)
						strReceiver = "info@genetex.com";
					break;
				case "Support":
					if (m_CC == CountryCode.US)
						strReceiver = "support@genetex.com";
					else if (m_CC == CountryCode.TW)
						strReceiver = "support@genetex.com";
					break;
				case "Order":
					if (m_CC == CountryCode.US)
						strReceiver = "weborder@genetex.com";
					else if (m_CC == CountryCode.TW)
						strReceiver = "weborder@genetex.com";
					break;
				case "Survey":
					if (m_CC == CountryCode.US)
						strReceiver = "survey@genetex.com";
					else if (m_CC == CountryCode.TW)
						strReceiver = "survey@genetex.com";
					break;
				case "Test":
					strReceiver = "linyy.iconbio@gmail.com";
					break;
			}
			return strReceiver;
		}
	}
}
