﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;

/// <summary>
/// SendMail 的摘要描述
/// </summary>
public class SendMail
{
    private static string m_strHost = "127.0.0.1";

	public SendMail()
	{
        m_strHost = "127.0.0.1";
	}

    public static bool Send(System.Net.Mail.MailAddress fromAddress, System.Net.Mail.MailAddress toAddress, string strSubject, string strBodyText, string strBodyHtml)
    {
        try
        {
            using (System.Net.Mail.MailMessage emailMessage = new System.Net.Mail.MailMessage())
            {
                emailMessage.To.Add(toAddress);
                emailMessage.From = fromAddress;
                emailMessage.Subject = strSubject;
                Encoding textEncoding = Encoding.UTF8;

                if (!Regex.IsMatch(strBodyText, @"^([0-9a-z!@#\$\%\^&\*\(\)\-=_\+])", RegexOptions.IgnoreCase) ||
                        !Regex.IsMatch(strSubject, @"^([0-9a-z!@#\$\%\^&\*\(\)\-=_\+])", RegexOptions.IgnoreCase))
                {
                    textEncoding = Encoding.Unicode;
                }
                // add text view...
                emailMessage.AlternateViews.Add(System.Net.Mail.AlternateView.CreateAlternateViewFromString(strBodyText, textEncoding, "text/plain"));

                if (!String.IsNullOrEmpty(strBodyHtml))
                {
                    emailMessage.AlternateViews.Add(System.Net.Mail.AlternateView.CreateAlternateViewFromString(strBodyHtml, Encoding.UTF8, "text/html"));
                }

                System.Net.Mail.SmtpClient smtpSend = new System.Net.Mail.SmtpClient(m_strHost);
                smtpSend.Send(emailMessage);
                return true;
            }
        }
        catch (Exception ex)
        {
            return false;
        }
    }

	//寄信
	public static bool Send(string strFrom, string strMailTo, string strContext, string strSubject)
	{
		try
		{
			MailMessage mailMsg = new MailMessage();
			mailMsg.From = new MailAddress(strFrom);
			mailMsg.To.Add(new MailAddress(strMailTo));
			mailMsg.IsBodyHtml = true;
			mailMsg.BodyEncoding = Encoding.UTF8;
			mailMsg.Priority = MailPriority.Normal;
			mailMsg.Body = strContext;

			mailMsg.Subject = strSubject;


			System.Net.Mail.SmtpClient smtpSend = new System.Net.Mail.SmtpClient(m_strHost);
			smtpSend.Send(mailMsg);
			return true;
		}
		catch (Exception ex)
		{
			return false;
		}
	}

	//寄信(有附加檔案)
	public static bool SendWithAttachment(string strFrom, string strMailTo, string strContext, string strSubject, string strFileName)
	{
		try
		{
			MailMessage mailMsg = new MailMessage();
			mailMsg.From = new MailAddress(strFrom);
			mailMsg.To.Add(new MailAddress(strMailTo));
			mailMsg.IsBodyHtml = true;
			mailMsg.BodyEncoding = Encoding.UTF8;
			mailMsg.Priority = MailPriority.Normal;

			Attachment data = new Attachment(strFileName, MediaTypeNames.Application.Pdf);
			// Add time stamp information for the file.
			ContentDisposition disposition = data.ContentDisposition;
			disposition.CreationDate = System.IO.File.GetCreationTime(strFileName);
			disposition.ModificationDate = System.IO.File.GetLastWriteTime(strFileName);
			disposition.ReadDate = System.IO.File.GetLastAccessTime(strFileName);

			// Add the file attachment to this e-mail message.
			mailMsg.Attachments.Add(data);
			//Send the message.
			mailMsg.Body = strContext;
			mailMsg.Subject = strSubject;

			System.Net.Mail.SmtpClient smtpSend = new System.Net.Mail.SmtpClient(m_strHost);
			smtpSend.Send(mailMsg);

			mailMsg.Dispose();
			return true;
		}
		catch (Exception ex)
		{
			return false;
		}
	}

    //寄信(有CC)
    public static bool SendWithCC(string strFrom, string strMailTo, string strContext, string strSubject, string strCC)
    {
        try
        {
            MailMessage mailMsg = new MailMessage();
            mailMsg.From = new MailAddress(strFrom);
            mailMsg.To.Add(new MailAddress(strMailTo));
            mailMsg.CC.Add(new MailAddress(strCC));
            mailMsg.IsBodyHtml = true;
            mailMsg.BodyEncoding = Encoding.UTF8;
            mailMsg.Priority = MailPriority.Normal;
            mailMsg.Body = strContext;

            mailMsg.Subject = strSubject;


            System.Net.Mail.SmtpClient smtpSend = new System.Net.Mail.SmtpClient(m_strHost);
            smtpSend.Send(mailMsg);
            return true;
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    //寄信
    public static bool Send(MailAddress fromAddress, MailAddress toAddress, string strSubject, string strContext)
    {
        try
        {
            MailMessage mailMsg = new MailMessage();
            mailMsg.To.Add(toAddress);
            mailMsg.From = fromAddress;
            mailMsg.IsBodyHtml = true;
            mailMsg.BodyEncoding = Encoding.UTF8;
            mailMsg.Priority = MailPriority.Normal;
            mailMsg.Body = strContext;

            mailMsg.Subject = strSubject;

            SmtpClient smtpSend = new SmtpClient(m_strHost);
            smtpSend.Send(mailMsg);
            return true;
        }
        catch (Exception ex)
        {
            return false;
        }
    }
}

