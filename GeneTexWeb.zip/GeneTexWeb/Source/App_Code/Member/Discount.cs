﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Icon.Member
{
    /// <summary>
    /// 存放Discount Infomation
    /// </summary>
    public class Discount
    {
        private int _CatalogID = 0;
        private int _QtyL = 0;
        private int _QtyH = 0;
        private bool _WithTotal = false;
        private decimal _DiscountRate = 0;
        private decimal _Deduct = 0;
        private int _LimitQty = 0;
        private int _Amount = 0;
        private int _Remaining = 0;
        private string _Mode = "";
        private int _DiscountQty = 0;
        public Discount()
        {
            //
            // TODO: 在此加入建構函式的程式碼
            //
        }

        /// <summary>Catalog ID</summary>
        public int CatalogID
        {
            get { return _CatalogID; }
            set { _CatalogID = value; }
        }

        /// <summary>最低購買數量</summary>
        public int QtyL
        {
            get { return _QtyL; }
            set { _QtyL = value; }
        }

        /// <summary>最高購買數量</summary>
        public int QtyH
        {
            get { return _QtyH; }
            set { _QtyH = value; }
        }

        /// <summary>其他Catalog能否一起折價</summary>
        public bool WithTotal
        {
            get { return _WithTotal; }
            set { _WithTotal = value; }
        }

        /// <summary>打幾折</summary>
        public decimal DiscountRate
        {
            get { return _DiscountRate; }
            set { _DiscountRate = value; }
        }

        /// <summary>折多少</summary>
        public decimal Deduct
        {
            get { return _Deduct; }
            set { _Deduct = value; }
        }

        /// <summary>購買數量上限</summary>
        public int LimitQty
        {
            get { return _LimitQty; }
            set { _LimitQty = value; }
        }

        /// <summary>剩餘購買數量</summary>
        public int Remaining
        {
            get { return _Remaining; }
            set { _Remaining = value; }
        }

        /// <summary>產品購買總數</summary>
        public int Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }

        /// <summary>促銷方式</summary>
        public string Mode
        {
            get { return _Mode; }
            set { _Mode = value; }
        }

        /// <summary>目前給"Set" Mode用，能給折扣的數量，QtyH的倍數</summary>
        public int DiscountQty
        {
            get { return _DiscountQty; }
            set { _DiscountQty = value; }
        }
    }
}
