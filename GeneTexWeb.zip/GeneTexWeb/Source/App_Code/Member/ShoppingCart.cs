﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using df = Icon.Definition;

namespace Icon.Member
{
    /// <summary>
    /// 購物車物件
    /// </summary>
    public class ShoppingCart
    {
        #region 全域私用變數
        private int? _GeneID = null;
        private int? _CatalogItemID = null;
        private string _ProductName = null;
        private int? _Quantity = null;
        private string _CatNo = null;
        private string _Package = null;
        private decimal? _UnitPrice = null;
        private decimal? _TotalPrice = null;
        private int? _CampaignID = null;
        private string _CampaignCode = null;
        private int? _CatalogID = null;
        private decimal? _Deduct = 0;
        private bool _IsKit = false;

        #endregion

        public ShoppingCart()
        {

        }

        #region 公用屬性

        /// <summary>基因ID</summary>
        public int? GeneID
        {
            get { return _GeneID; }
            set { _GeneID = value; }
        }

        /// <summary>CatalogItemID</summary>
        public int? CatalogItemID
        {
            get { return _CatalogItemID; }
            set { _CatalogItemID = value; }
        }

        /// <summary>產品名稱</summary>
        public string ProductName
        {
            get { return _ProductName; }
            set { _ProductName = value; }
        }

        /// <summary>數量</summary>
        public int? Quantity
        {
            get { return _Quantity; }
            set { _Quantity = value; }
        }

        /// <summary>CatNo</summary>
        public string CatNo
        {
            get { return _CatNo; }
            set { _CatNo = value; }
        }

        /// <summary>容量</summary>
        public string Package
        {
            get { return _Package; }
            set { _Package = value; }
        }

        /// <summary>單價</summary>
        public decimal? UnitPrice
        {
            get { return _UnitPrice; }
            set { _UnitPrice = value; }
        }

        /// <summary>總價</summary>
        public decimal? TotalPrice
        {
            get { return _TotalPrice; }
            set { _TotalPrice = value; }
        }

        /// <summary>CampaignID</summary>
        public int? CampaignID
        {
            get { return _CampaignID; }
            set { _CampaignID = value; }
        }

        /// <summary>CampaignCode</summary>
        public string CampaignCode
        {
            get { return _CampaignCode; }
            set { _CampaignCode = value; }
        }

        /// <summary>Catalog ID</summary>
        public int? CatalogID
        {
            get { return _CatalogID; }
            set { _CatalogID = value; }
        }

        /// <summary>折扣金額</summary>
        public decimal? Deduct
        {
            get { return _Deduct; }
            set { _Deduct = value; }
        }

        /// <summary>是否為Kit</summary>
        public bool IsKit
        {
            get { return _IsKit; }
            set { _IsKit = value; }
        }

        #endregion

        #region 公用靜態函式

        /// <summary>檢查產品是否已存在購物車</summary>
        public static bool CheckProductInCart(object catalogItemID)
        {
            bool isOk = true;
            int ival = int.Parse(catalogItemID.ToString());
            List<ShoppingCart> listShoppingCart = df.ShoppingCartList;
            foreach (ShoppingCart sc in listShoppingCart) //循序讀取購物清單
            {
                if (sc.CatalogItemID == ival) //判斷此產品是否已在清單內
                {
                    isOk = false;
                    break;
                }
            }
            return isOk;
        }

        /// <summary>檢查CatNo是否已存在購物車</summary>
        public static bool CheckCatNoInCart(object catno)
        {
            bool isOk = true;
            List<ShoppingCart> listShoppingCart = df.ShoppingCartList;
            foreach (ShoppingCart sc in listShoppingCart) //循序讀取購物清單
            {
                if (sc.CatNo == catno.ToString()) //判斷此產品是否已在清單內
                {
                    isOk = false;
                    break;
                }
            }
            return isOk;
        }

        #endregion
    }
}