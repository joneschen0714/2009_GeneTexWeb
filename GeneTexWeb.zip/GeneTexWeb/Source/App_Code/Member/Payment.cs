﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Icon.Member
{
    //列舉
    public enum MyPaymentType { PO = 1, CreditCard = 2 }

    /// <summary>
    /// 付款方式相關
    /// </summary>
    public class Payment
    {
        #region 公用變數
        public MyPaymentType PaymentType = MyPaymentType.CreditCard;
        public DateTime? OrderDate = null;

        public string POPurchaserName = null;
        public string PONumber = null;
        public string POPhone = null;

        public string CardHolderName = null;
        public string CreditCardType = null;
        public string CreditCardNumber = null;
        public int? ExpiryMonth = null;
        public int? ExpiryYear = null;
        public string SecurityID = null;

        public decimal ProductTotal = 0;
        public decimal TaxRate = 0;
        public decimal ShippingPrice = 0;
        public decimal HandlingPrice = 0;
        public decimal DryIceCharge = 0;
        public decimal TotalPrice = 0;

        public int? BillingAddressID = null;
        public int? ShippingAddressID = null;
        #endregion
    }
}