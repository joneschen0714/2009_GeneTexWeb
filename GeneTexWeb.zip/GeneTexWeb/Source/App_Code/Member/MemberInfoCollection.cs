﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Icon.Member
{
    public class MemberInfoCollection : List<MemberInfo>
    {
        public MemberInfoCollection()
        {

        }

        /// <summary>取得MemberInfo物件</summary>
        /// <param name="strAccount">會員帳號</param>
        public MemberInfo this[string strAccount]
        {
            get
            {
                MemberInfo mi = null;
                foreach (MemberInfo _mi in this)
                {
                    if (_mi.Account.ToLower().Trim() == strAccount.ToLower().Trim())
                    {
                        mi = _mi;
                        break;
                    }
                }

                return mi;
            }
        }

        /// <summary>
        /// 取得MemberInfo物件
        /// </summary>
        /// <param name="memberID">會員ID</param>
        public MemberInfo this[int? memberID]
        {
            get
            {
                MemberInfo mi = null;
                foreach (MemberInfo _mi in this)
                {
                    if (_mi.MemberID == memberID)
                    {
                        mi = _mi;
                        break;
                    }
                }

                return mi;
            }
        }
    }
}