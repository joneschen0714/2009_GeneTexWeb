﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using df = Icon.Definition;

namespace Icon.Member
{
    public class MemberInfo
    {
        #region 私用全域變數
        private int? _MemberID = null;
        private string _Account = null;
        private string _Password = null;
        private string _Title = null;
        private string _FirstName = null;
        private string _LastName = null;
        private string _Email = null;
        private string _Institution = null;
        private string _Position = null;
        private string _ResearchArea = null;
        private string _PasswordQ = null;
        private string _PasswordA = null;
        private DateTime? _LoginDate = null;
        private string _Address1 = null;
        private string _Address2 = null;
        private string _City = null;
        private string _County = null;
        private string _State = null;
        private string _Zip = null;
        private string _Country = null;
        private string _Phone = null;
        private string _Ext = null;
        private string _Fax = null;
        private string _ResearchGeneID = null;
        #endregion

        public MemberInfo()
        {

        }

        #region 公用屬性
        public int? MemberID
        {
            get { return _MemberID; }
            set { _MemberID = value; }
        }
        public string Account
        {
            get { return _Account; }
            set { _Account = value; }
        }
        public string Password
        {
            get { return _Password; }
            set { _Password = value; }
        }
        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }
        public string FirstName
        {
            get { return _FirstName; }
            set { _FirstName = value; }
        }
        public string LastName
        {
            get { return _LastName; }
            set { _LastName = value; }
        }
        public string Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        public string Institution
        {
            get { return _Institution; }
            set { _Institution = value; }
        }
        public string Position
        {
            get { return _Position; }
            set { _Position = value; }
        }
        public string ResearchArea
        {
            get { return _ResearchArea; }
            set { _ResearchArea = value; }
        }
        public string ResearchGeneID
        {
            get { return _ResearchGeneID; }
            set { _ResearchGeneID = value; }
        }
        public string PasswordQ
        {
            get { return _PasswordQ; }
            set { _PasswordQ = value; }
        }
        public string PasswordA
        {
            get { return _PasswordA; }
            set { _PasswordA = value; }
        }
        public DateTime? LoginDate
        {
            get { return _LoginDate; }
            set { _LoginDate = value; }
        }
        public string Address1
        {
            get { return _Address1; }
            set { _Address1 = value; }
        }
        public string Address2
        {
            get { return _Address2; }
            set { _Address2 = value; }
        }
        public string City
        {
            get { return _City; }
            set { _City = value; }
        }
        public string County
        {
            get { return _County; }
            set { _County = value; }
        }
        public string State
        {
            get { return _State; }
            set { _State = value; }
        }
        public string Zip
        {
            get { return _Zip; }
            set { _Zip = value; }
        }
        public string Country
        {
            get { return _Country; }
            set { _Country = value; }
        }
        public string Phone
        {
            get { return _Phone; }
            set { _Phone = value; }
        }
        public string Ext
        {
            get { return _Ext; }
            set { _Ext = value; }
        }
        public string Fax
        {
            get { return _Fax; }
            set { _Fax = value; }
        }
        #endregion

        #region 公用靜態函式

        /// <summary>
        /// 驗証會員是否登入
        /// </summary>
        public static bool CheckMemberLogin()
        {
            MemberInfoCollection mic = df.OnlineMemberInfoList; //線上會員清單
            int? iMemberID = df.PersonalMemberID; //會員ID
            if (mic[df.PersonalMemberID] != null) //若有會員資料
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 轉換為會員資料物件
        /// </summary>
        public static MemberInfo GetMemberInfo(DataRow rowMemberInfo)
        {
            //建立會員資料物件
            MemberInfo mi = new MemberInfo();
            mi.MemberID = int.Parse(rowMemberInfo["MemberID"].ToString());
            mi.Account = rowMemberInfo["Account"].ToString();
            mi.Email = rowMemberInfo["Email"].ToString();
            mi.Institution = rowMemberInfo["Institution"].ToString();
            mi.Position = rowMemberInfo["Position"].ToString();
            //mi.ResearchArea = rowMemberInfo["ResearchArea"].ToString();
            mi.FirstName = rowMemberInfo["FirstName"].ToString();
            mi.LastName = rowMemberInfo["LastName"].ToString();

            if (rowMemberInfo["LoginDate"].ToString() != "")
                mi.LoginDate = DateTime.Parse(rowMemberInfo["LoginDate"].ToString());

            mi.Password = rowMemberInfo["Password"].ToString();
            mi.PasswordA = rowMemberInfo["PasswordA"].ToString();
            mi.PasswordQ = rowMemberInfo["PasswordQ"].ToString();
            mi.Title = rowMemberInfo["Title"].ToString();
            mi.Address1 = rowMemberInfo["Address1"].ToString();
            mi.Address2 = rowMemberInfo["Address2"].ToString();
            mi.City = rowMemberInfo["City"].ToString();
            mi.County = rowMemberInfo["County"].ToString();
            mi.State = rowMemberInfo["State"].ToString();
            mi.Zip = rowMemberInfo["Zip"].ToString();
            mi.Country = rowMemberInfo["Country"].ToString();
            mi.Phone = rowMemberInfo["Phone"].ToString();
            mi.Ext = rowMemberInfo["Ext"].ToString();
            mi.Fax = rowMemberInfo["Fax"].ToString();

            //取得ResearchGeneID及ResearchArea
            mi.ResearchGeneID = BLL.GetMembersResearchAreaGeneID(int.Parse(rowMemberInfo["MemberID"].ToString()));
            mi.ResearchArea = BLL.GetResearchArea(mi.ResearchGeneID);

            return mi;
        }

        #endregion
    }
}