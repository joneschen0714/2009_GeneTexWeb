﻿using System;
using System.Data;
using System.IO;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;

public class Setting
{

    public Setting()
    {

    }


    public static void SetMultiViewCulture(MultiView mv, string _id)
    {
        foreach (View _view in mv.Views) //循序讀取View
        {
            if (_view.ID == _id) //判斷View的ID
            {
                mv.SetActiveView(_view); //設定啟用的View
            }
        }
    }


    /// <summary>清除Session的DataTable</summary>
    public static void RemoveSessionDataTable()
    {
        System.Web.SessionState.HttpSessionState hssPageSession = HttpContext.Current.Session;

        for (int i = hssPageSession.Count - 1; i >= 0; i--)
        {
            string strKey = hssPageSession.Keys[i];

            if (strKey.Contains("_DataTable"))
            {
                hssPageSession[strKey] = null;
                hssPageSession.Remove(strKey);
            }
        }
    }

    /// <summary>設定List控制項的文字值</summary>
    public static void SetListItemText(ListItemCollection lic, object valAry)
    {
        string[] strArray = valAry.ToString().Split(',');
        foreach (ListItem li in lic)
        {
            li.Selected = false;
            foreach (string val in strArray)
            {
                if (li.Text == val)
                    li.Selected = true;
            }
        }
    }

    /// <summary>取得指定小數位數值</summary>
    public static string GetCurrencyFormat(string BeforeText, object val, int iDecimal)
    {
        return string.Format(BeforeText + " {0:N" + iDecimal + "}", decimal.Parse(val.ToString()));
    }

    /// <summary>取得CatalogCode字串陣列</summary>
    public static string GetCatalogCodeList(DataTable dtCatalogList)
    {
        HttpContext page = HttpContext.Current;
        string strType = page.Request.QueryString["Type"];
        string strCode = page.Request.QueryString["Code"];
        string strCatalogCodeArray = "";

        //若參數Type為CatalogCode，且有傳入Code
        if (strType == "CatalogCode" && strCode != "")
        {
            //循序讀取Code參數
            foreach (string code in strCode.Split(','))
            {
                //若Code有符合Catalog則進入函式
                DataRow[] row = dtCatalogList.Select("Code='" + code + "'");
                if (row.Length > 0)
                {
                    HttpCookie hc = new HttpCookie("CatalogCode_" + code, code);
                    hc.Expires = DateTime.Parse(row[0]["EndDate"].ToString());
                    page.Response.Cookies.Add(hc);
                }
            }
        }

        //循序讀取Cookies
        for (int i = 0; i < page.Request.Cookies.Count; i++)
        {
            //若CookieName有CatalogCode關鍵字
            HttpCookie hc = page.Request.Cookies[i];
            if (hc.Name.Contains("CatalogCode"))
            {
                strCatalogCodeArray += string.Format(",'{0}'", hc.Value); //組成CatalogCodeArray
            }
        }

        return strCatalogCodeArray.TrimStart(',');
    }

    /// <summary>將DataTable轉成JSON字串</summary>
    public static string CreateJsonParameters(DataTable dt)
    {
        /**/
        /* /****************************************************************************
        * Without goingin to the depth of the functioning of this Method, i will try to give an overview
        * As soon as this method gets a DataTable it starts to convert it into JSON String,
        * it takes each row and in each row it grabs the cell name and its data.
        * This kind of JSON is very usefull when developer have to have Column name of the .
        * Values Can be Access on clien in this way. OBJ.HEAD[0].<ColumnName>
        * NOTE: One negative point. by this method user will not be able to call any cell by its index.
        * *************************************************************************/
        StringBuilder JsonString = new StringBuilder();
        //Exception Handling
        if (dt != null && dt.Rows.Count > 0)
        {
            JsonString.Append("{ ");
            JsonString.Append("\"dataset\":[ ");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                JsonString.Append("{ ");
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    if (j < dt.Columns.Count - 1)
                    {
                        JsonString.Append("\"" + dt.Columns[j].ColumnName.ToString() + "\":" + "\"" + dt.Rows[i][j].ToString() + "\",");
                    }
                    else if (j == dt.Columns.Count - 1)
                    {
                        JsonString.Append("\"" + dt.Columns[j].ColumnName.ToString() + "\":" + "\"" + dt.Rows[i][j].ToString() + "\"");
                    }
                }
                /**/
                /*end Of String*/
                if (i == dt.Rows.Count - 1)
                {
                    JsonString.Append("} ");
                }
                else
                {
                    JsonString.Append("}, ");
                }
            }
            JsonString.Append("]}");
            return JsonString.ToString();
        }
        else
        {
            return null;
        }
    }

    /// <summary>檔案轉Byte[]</summary>
    public static byte[] ConvertFileToByte(string filepath)
    {
        FileStream fs = new FileStream(filepath, FileMode.Open, FileAccess.Read);
        byte[] buf = new byte[fs.Length];
        fs.Read(buf, 0, Convert.ToInt32(fs.Length));
        fs.Close();
        fs.Dispose();

        return buf;
    }

    /// <summary>分割字串，並在各個值前後加上指定字元</summary>
    public static string SetSplitSingleMark(string value, string SingleMark, char splitChar)
    {
        string newValue = "";

        foreach (string str in value.Split(splitChar))
            newValue += SingleMark + str + SingleMark + splitChar;

        return newValue.Trim(splitChar);
    }

    /// <summary>取得HttpContext，並轉NULL為空值</summary>
    public static string CheckQueryString(string strName)
    {
        HttpContext context = HttpContext.Current;
        if (context.Request.QueryString[strName] == null)
            return "";
        else
            return context.Request.QueryString[strName].ToString();
    }

    /// <summary>取得HttpContext，並轉NULL為空值</summary>
    public static string GetStringUrlParam(string strUrl, string strParamName)
    {
        string strValue = "";
        foreach (string strItem in strUrl.Split('?', '&'))
        {
            string[] ItemData = strItem.Split('=');
            if (ItemData[0] == strParamName)
            {
                strValue = ItemData[1];
            }
        }

        return strValue;
    }
}
