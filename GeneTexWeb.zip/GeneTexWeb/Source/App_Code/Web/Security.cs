﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Security.Cryptography;
using System.Text;
using System.IO;

/// <summary>
/// Security 的摘要描述
/// </summary>
public class Security
{
    string _QueryStringKey = "iconbioa"; //URL传输参数加密Key
    string _PassWordKey = "iconbioa"; //PassWord加密Key

	public Security()
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
	}

    //設定URL传输参数加密Key
    public string QueryString
    {
        set { _QueryStringKey = value; }
    }

    //設定URL传输参数加密Key
    public string PassWordKey
    {
        set { _PassWordKey = value; }
    }

    public string EncryptQueryString(string QueryString)
    {
        return Encrypt(QueryString, _QueryStringKey);
    }


    public string DecryptQueryString(string QueryString)
    {
        return Decrypt(QueryString, _QueryStringKey);
    }


    public string EncryptPassWord(string PassWord)
    {
        return Encrypt(PassWord, _PassWordKey);
    }


    public string DecryptPassWord(string PassWord)
    {
        return Decrypt(PassWord, _PassWordKey);
    }


    /// <summary>
    /// 加密
    /// </summary>
    /// <param name="str"></param>
    /// <param name="key"></param>
    /// <returns></returns>
    public string Encrypt(string str, string sKey)
    {
        DESCryptoServiceProvider des = new DESCryptoServiceProvider(); //把字符串放到byte数组中 

        byte[] inputByteArray = Encoding.Default.GetBytes(str);
        des.Key = ASCIIEncoding.ASCII.GetBytes(sKey); //建立加密对象的密钥和偏移量
        des.IV = ASCIIEncoding.ASCII.GetBytes(sKey); //原文使用ASCIIEncoding.ASCII方法的GetBytes方法 
        MemoryStream ms = new MemoryStream(); //使得输入密码必须输入英文文本
        CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);

        cs.Write(inputByteArray, 0, inputByteArray.Length);
        cs.FlushFinalBlock();
   
        StringBuilder ret = new StringBuilder();
        foreach (byte b in ms.ToArray())
        {
            ret.AppendFormat("{0:X2}", b);
        }
        ret.ToString();

        return ret.ToString();
    }


    // DEC 解密过程
    public string Decrypt(string str, string sKey)
    {
        DESCryptoServiceProvider des = new DESCryptoServiceProvider();

        byte[] inputByteArray = new byte[str.Length / 2];
        for (int x = 0; x < str.Length / 2; x++)
        {
            int i = (Convert.ToInt32(str.Substring(x * 2, 2), 16));
            inputByteArray[x] = (byte)i;
        }

        des.Key = ASCIIEncoding.ASCII.GetBytes(sKey); //建立加密对象的密钥和偏移量，此值重要，不能修改 
        des.IV = ASCIIEncoding.ASCII.GetBytes(sKey);
        MemoryStream ms = new MemoryStream();
        CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);

        cs.Write(inputByteArray, 0, inputByteArray.Length);
        cs.FlushFinalBlock();

        StringBuilder ret = new StringBuilder(); //建立StringBuild对象，CreateDecrypt使用的是流对象，必须把解密后的文本变成流对象 

        return System.Text.Encoding.Default.GetString(ms.ToArray());
    }
}
