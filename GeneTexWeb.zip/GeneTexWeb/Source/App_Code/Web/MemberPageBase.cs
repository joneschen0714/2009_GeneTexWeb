﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using df = Icon.Definition;

namespace Icon
{
    /// <summary>
    /// 會員頁面基底類別
    /// </summary>
    public class MemberPageBase : Page
    {
        //初始化
        protected override void OnInit(EventArgs e)
        {
            //取得登入狀態
            bool bLogin = Member.MemberInfo.CheckMemberLogin();

            //若未登入
            if (!bLogin)
            {
                //記錄頁面導向路徑
                df.RedirectPageUrl = Request.Url.AbsolutePath;

                //導向會員登入頁
                Response.Redirect("~/WebPage/Member/Login.aspx");
            }
        }
    }
}