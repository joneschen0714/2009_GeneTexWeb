﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;

namespace Icon
{
    /// <summary>
    /// 資料存取層
    /// </summary>
    public class DAL
    {
        public DAL()
        {

        }

        #region 會員相關
        /// <summary>
        /// 會員登入
        /// </summary>
        public static void Member_Login(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false);

            //組成條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(((SqlParameter)param["Type"]).Value.ToString())) { strWhere += " AND [Type]=@Type"; }
            if (!string.IsNullOrEmpty(((SqlParameter)param["Status"]).Value.ToString())) { strWhere += " AND [Status]=@Status"; }

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "DECLARE @iUserID int; " +

                        //尋找MemberID
                        "SET @iUserID = (SELECT [Id] FROM [tb_Member] WHERE [Account]=@Account AND [Password]=@Password" + strWhere + "); " +

                        //若有使用者
                        "IF (@iUserID IS NOT NULL) BEGIN " +
                            "UPDATE [tb_Member] SET [LoginDate]=GETUTCDATE() WHERE [Id]=@iUserID; " + //更新登入日期
                        "END " +

                        "SELECT @iUserID;"; //回傳MemberID

            string strValue = db.ExecuteScalar();
            db.CloseDatabaseState("N");


            //判斷與回傳DB執行狀態
            if (!string.IsNullOrEmpty(strValue))
            {
                strMessage = "";
                bResult = true;
            }
            else
            {
                strMessage = "Your Account User Name or Password is incorrect. Please try again.";
                bResult = false;
            }
        }

        /// <summary>
        /// 驗証帳號是否可用
        /// </summary>
        public static void CheckMemberAccount(out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);


            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("Account", htParams["Account"]);
            param.Add("Message", ParameterDirection.Output);


            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_CheckMemberAccount";
            db.ExecuteSQL();
            db.CloseDatabaseState("N");


            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
        }

        /// <summary>
        /// 註冊新會員
        /// </summary>
        public static void RegisterNewMember(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_RegisterNewMember";
            db.ExecuteSQL();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        /// <summary>
        /// 取得會員資料
        /// </summary>
        public static DataTable GetMemberInfo(string account)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);


            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("MemberAccount", account);


            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetMemberInfo";
            DataTable dtMemberInfo = db.ExecuteDataTable();
            db.CloseDatabaseState("N");


            return dtMemberInfo;
        }

        /// <summary>
        /// 取得會員的問題與答案
        /// </summary>
        public static DataTable GetPasswordQuestions(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetPasswordQuestions";
            DataTable dtPasswordQuestions = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }

            return dtPasswordQuestions;
        }

        /// <summary>
        /// 取得會員的地址資訊
        /// </summary>
        public static DataTable GetMemberAddress(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertMemberAddress";
            DataTable dtMemberAddress = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtMemberAddress;
        }

        /// <summary>
        /// 增加會員地址資訊
        /// </summary>
        public static void InsertMemberAddress(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);


            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);


            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertMemberAddress";
            db.ExecuteSQL();
            db.CloseDatabaseState("N");


            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        /// <summary>找尋Address條件資料</summary>
        public static DataTable GetAddressInfo(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetAddressInfo";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>檢查MemberType條件</summary>
        public static DataRow CheckLoginMemberType(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT Account, Password, Email FROM tb_Member WHERE Account=@Account AND Type<>'Web' AND Status='Active'";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            DataRow row = null;
            if (dtResult.Rows.Count > 0)
                row = dtResult.Rows[0];

            return row;
        }

        //檢查GeneID是否存在
        public static DataTable CheckGeneID(string strGeneID)
        {
            if (strGeneID != "")
            {
                //物件初始化
                DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

                db.CommandType = CommandType.Text;
                db.StrSQL = "SELECT GeneID FROM db01.[BioInfo].dbo.[Bio-NCBI_Gene] WHERE GeneID in (" + strGeneID + ")";
                DataTable dtResult = db.ExecuteDataTable();
                db.CloseDatabaseState("N");

                return dtResult;
            }
            else
                return null;
        }

        public static string GetResearchArea(string strGeneID)
        {
            string strResearchAreaName = "";
            if (!string.IsNullOrEmpty(strGeneID))
            {
                strGeneID = strGeneID.Replace("\r\n", ",");
                //物件初始化
                DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

                db.CommandType = CommandType.Text;
                db.StrSQL = "SELECT DISTINCT Name FROM tb_ResearchAreaRelGeneID WHERE GeneID in (" + strGeneID + ")";

                DataTable dtResearchArea = db.ExecuteDataTable();
                db.CloseDatabaseState("N");

                if (dtResearchArea != null && dtResearchArea.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtResearchArea.Rows)
                    {
                        strResearchAreaName += (strResearchAreaName == "" ? "" : "\r\n") + dr["Name"].ToString();
                    }
                }
            }
            return strResearchAreaName;
        }

        public static DataTable GetMembersResearchAreaGeneID(int iMemberID)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("MemberID", iMemberID);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT GeneID FROM tb_MemberGeneIdRel WHERE MemberID=@MemberID";

            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dt;
        }

        //新增或修改Member和GeneId的關連
        public static void AddMemberGeneIdRel(object oMemberID, string sResearchGeneID)
        {
            sResearchGeneID = sResearchGeneID.Replace("\r\n", ",");
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("MemberID", oMemberID);
            param.Add("GeneID", "");

            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "DELETE tb_MemberGeneIdRel WHERE MemberID=@MemberID AND GeneID not in (" + sResearchGeneID + ")";
            db.ExecuteSQL();

            string[] aryGeneID = sResearchGeneID.Split(',');
            for (int i = 0; i < aryGeneID.Length; i++)
            {
                ((SqlParameter)param["GeneID"]).Value = aryGeneID[i];
                db.StrSQL = "IF NOT EXISTS(SELECT MemberID, GeneID FROM tb_MemberGeneIdRel WHERE MemberID=@MemberID AND GeneID=@GeneID)" +
                                    " INSERT INTO tb_MemberGeneIdRel(MemberID, GeneID) VALUES (@MemberID, @GeneID)";

                db.ExecuteSQL();
            }
            db.CloseDatabaseState("N");
        }

        #endregion

        #region 購物相關
        /// <summary>
        /// 取得產品頁面的購物車資料
        /// </summary>
        public static DataTable GetCartForProductData(string CatalogItemID)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CatalogItemID", CatalogItemID);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetCartForProductData";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        /// 新增會員的Wish List
        /// </summary>
        public static void InsertMemberWishList(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true);
            //param.Add("MemberID", htParams["MemberID"], SqlDbType.Int);
            //param.Add("CatalogItemID", htParams["CatalogItemID"], SqlDbType.Int);
            //param.Add("CampaignID", htParams["CampaignID"], SqlDbType.Int);
            //param.Add("InsertDate", htParams["InsertDate"], SqlDbType.DateTime);
            //param.Add("Message", ParameterDirection.Output);
            //param.Add("ReturnValue", ParameterDirection.ReturnValue);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertMemberWishList";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        /// <summary>
        /// 取得會員的Wish List
        /// </summary>
        public static DataTable GetMemberWishList(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetMemberWishList";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        /// 刪除會員的Wish List
        /// </summary>
        public static void DeleteMemberWishList(out bool bResult, out string strMessage, string strWishListIDArray)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("WishListIDArray", strWishListIDArray);
            param.Add("Message", ParameterDirection.Output);
            param.Add("ReturnValue", ParameterDirection.ReturnValue);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_DeleteMemberWishList";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        /// <summary>
        /// 取得Quick Order資料
        /// </summary>
        public static DataTable GetQuickOrderData(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetQuickOrderData";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>
        /// 取得所有國家資料
        /// </summary>
        public static DataTable GetCountry()
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("Enabled", 1, SqlDbType.Bit);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT Id CountryID, Code CountryCode, Name CountryName FROM tb_Country WHERE Enabled=@Enabled ORDER BY CountryName";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }
        public static DataTable GetCountry(int StateID)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("StateID", StateID);
            param.Add("Enabled", 1, SqlDbType.Bit);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT c.Id CountryID, c.Name CountryName, c.Code CountryCode " +
                        "FROM tb_Country c " +
                        "INNER JOIN tb_State s ON s.Country_ID=c.Id " +
                        "WHERE s.Id=@StateID AND s.Enabled=@Enabled AND c.Enabled=@Enabled";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>
        /// 取得對應的State資料
        /// </summary>
        public static DataTable GetState(string CountryCode)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CountryCode", CountryCode);
            param.Add("Enabled", 1);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT s.Id StateID, s.Name StateName, s.Code FROM tb_State s " +
                        "INNER JOIN tb_Country c ON s.Country_ID=c.Id " +
                        "WHERE c.Code=@CountryCode AND s.Enabled=@Enabled ORDER BY StateName";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }
        public static DataTable GetState(int CountyID)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CountyID", CountyID);
            param.Add("Enabled", 1);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT s.Id StateID, s.Name StateName, s.Code StateCode, (Convert(varchar(max),s.Id) + ',' + s.Code) StateKey " +
                        "FROM tb_State s " +
                        "INNER JOIN tb_County c ON c.State_ID=s.Id " +
                        "WHERE c.Id=@CountyID AND s.Enabled=@Enabled";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>
        /// 取得對應的City資料
        /// </summary>
        public static DataTable GetCity(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CountryCode", htParams["CountryCode"]);
            param.Add("StateCode", htParams["StateCode"]);
            param.Add("CityKeyWord", htParams["CityKeyWord"]);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT CountyID, CountyName, CityID, CityName FROM view_PositionInfo " +
                        "WHERE CountryCode=@CountryCode AND StateCode=@StateCode AND CityName LIKE @CityKeyWord " +
                        "ORDER BY CityName";

            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>
        /// 取得對應的County資料
        /// </summary>
        public static DataTable GetCounty(string city)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CityName", city);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT co.Id CountyID, co.Name CountyName " +
                        "FROM tb_County co " +
                        "INNER JOIN tb_City ci ON ci.County_ID=co.Id " +
                        "WHERE ci.Name=@CityName AND co.Enabled=1 AND ci.Enabled=1 " +
                        "ORDER BY ci.Tax DESC";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>
        /// 判斷是否有City資料
        /// </summary>
        public static bool ExistsCity(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CountryCode", htParams["CountryCode"]);
            param.Add("StateCode", htParams["StateCode"]);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT COUNT(*) FROM view_PositionInfo " +
                        "WHERE (CountryCode=@CountryCode) AND (StateCode=@StateCode) AND (CityID IS NOT NULL)";

            int iResult = int.Parse(db.ExecuteScalar());
            db.CloseDatabaseState("N");

            //回傳資料
            return (iResult == 0 ? false : true);
        }

        /// <summary>
        /// 取得計算金額相關所需資料
        /// </summary>
        public static Hashtable GetPaymentInfo(int BillingID, int ShippingID, string ProductIDArray)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("BillingID", BillingID);
            param.Add("ShippingID", ShippingID);
            param.Add("ProductIDArray", ProductIDArray);
            param.Add("CountryCode", ParameterDirection.Output);
            param.Add("StateCode", ParameterDirection.Output);
            param.Add("IsLocal", ParameterDirection.Output);
            param.Add("TaxRate", ParameterDirection.Output);
            param.Add("IsDryIce", ParameterDirection.Output);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetPaymentInfo";
            db.ExecuteSQL();
            db.CloseDatabaseState("N");

            //回傳資料
            Hashtable htParams = new Hashtable();
            htParams.Add("CountryCode", param["CountryCode"].Value);
            htParams.Add("StateCode", param["StateCode"].Value);
            htParams.Add("IsLocal", param["IsLocal"].Value);
            htParams.Add("TaxRate", param["TaxRate"].Value);
            htParams.Add("IsDryIce", param["IsDryIce"].Value);

            return htParams;
        }

        /// <summary>
        /// 新增會員訂單項目
        /// </summary>
        public static void InsertOrderInfo(out bool bResult, out string strMessage, out string strOrderID, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);
            param.Add("ThisOrderID", ParameterDirection.Output);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_PersonOrderInfo";
            db.ExecuteSQL();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = param["Message"].Value.ToString();
            strOrderID = param["ThisOrderID"].Value.ToString();
            if (param["ReturnValue"].Value.ToString() == "0") { bResult = true; }
            else { bResult = false; }
        }

        /// <summary>
        /// 刪除訂單
        /// </summary>
        public static void DeleteOrder(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_PersonOrderInfo";
            db.ExecuteSQL();
            db.CloseDatabaseState("N");
        }

        /// <summary>
        /// 取得會員的歷史訂單記錄
        /// </summary>
        public static DataTable GetOrderHistoryList(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_PersonOrderInfo";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>
        /// 取得訂單的項目資料
        /// </summary>
        public static DataTable GetHistoryOrderListItem(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_PersonOrderInfo";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>
        /// 取得最大的訂單ID
        /// </summary>
        /// <returns></returns>
        public static int GetMaxInvoiceID()
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT MAX(Id) FROM tb_Order";
            string strMaxOrderID = db.ExecuteScalar();
            db.CloseDatabaseState("N");

            //若無資料則傳回4000
            int iVal = (strMaxOrderID == "" ? 4000 : int.Parse(strMaxOrderID));

            //回傳資料
            return iVal;
        }

        /// <summary>取得產品購物資訊</summary>
        public static DataTable GetProductOrderInfo(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetProductOrderInfo";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>取得Catalog Discount Information</summary>
        public static DataTable GetCatalogDiscount(Hashtable htParams, string strDiscountMode)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);
            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT c.Id AS CatalogID, c.LimitQty, dc.Qty_L AS QtyL, dc.Gty_H AS QtyH, dc.Discount, dc.Deduct, c.DiscountMode" +
                            " FROM Catalog c" +
                            " INNER JOIN tb_Discount dc ON dc.CatalogID = c.Id" +
                            " INNER JOIN dbo.tb_Country AS co ON co.Code = c.CountryCode" +
                            " WHERE c.Id=@CatalogID AND c.CountryCode= @CountryCode AND dbo.fn_GetLocalDateTime('Minute', co.TimeZone, NULL) BETWEEN c.StartDate AND c.EndDate";
            
            if (strDiscountMode == "Set")
                db.StrSQL += " AND (@Qty >= dc.Gty_H)";
            else
                db.StrSQL += " AND @Qty between dc.Qty_L AND dc.Gty_H";

            db.StrSQL += " Order By dc.Gty_H DESC";

            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        #endregion

        #region 產品相關

        /// <summary>
        /// 取得相關產品資料
        /// </summary>
        public static DataTable GetProductRelated(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetProductRelated";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        /// 取得產品相關的文獻資料
        /// </summary>
        public static DataTable GetProductReference(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT * FROM ProductRef WHERE CatNo=@CatNo";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        ///　取得ProductMap資料
        /// </summary>
        public static DataTable GetProductMapInfo(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT pm.Id, pm.s_Id, pm.Name, pm.Code, pm.Count " +
                        "FROM ProductMap pm " +
                        "INNER JOIN tb_SystemParam sp ON sp.Id=pm.ClassID " +
                        "WHERE sp.CountryCode=@CountryCode AND Lang=@Lang AND Type=@Type AND sp.Value=@Value " +
                        "ORDER BY Name";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        ///　取得ResearchArea資料
        /// </summary>
        public static DataTable GetFirstNodeResearchArea(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT sp.Id AS SystemParamID, sp.Value AS Name " +
                        "FROM tb_SystemParam sp " +
                        "WHERE sp.CountryCode='' AND Lang='' AND Type=@Type " +
                        "ORDER BY Sort";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        /// 取得前20筆最新產品
        /// </summary>
        public static DataTable GetTopNewProducts(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT p.CatNo, p.ProductName, ci.Id AS CatalogItemID, c.Id AS CatalogID" +
                        " FROM CatalogItem ci " +
                        " INNER JOIN Catalog c ON c.Id= ci.Catalog_ID AND c.CountryCode= 'US' AND c.Type='B' " +
                        " INNER JOIN Product p ON p.CatNo = ci.CatNo " +
                        " INNER JOIN dbo.tb_Country AS co ON co.Code = c.CountryCode" +
                        " WHERE ci.Enabled = 'True' AND dbo.fn_GetLocalDateTime('Minute', co.TimeZone, NULL) BETWEEN ci.EffectiveDate AND ci.ExpiryDate";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        /// 取得Catalog Best Buy Product
        /// </summary>
        public static DataTable GetBestBuy(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT TOP 20 p.GeneID, vci.CatalogItemID, p.ProductName, p.CatNo, p.ApplicationAbbrev, vci.PromotionPrice " +
                        "FROM view_CatalogItem vci " +
                        "INNER JOIN Product p ON p.CatNo = vci.CatNo " +
                        "WHERE vci.CountryCode=@CountryCode AND vci.Type='H' " +
                        "ORDER BY CatalogItemID DESC";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        /// 取得站台下的上架Catalog資料
        /// </summary>
        public static DataTable GetCatalogInfo()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            Hashtable htParams = new Hashtable();
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT * FROM view_Catalog WHERE CountryCode=@CountryCode"; //顯示在選單
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>取得某Campaign的資料</summary>
        public static DataTable GetCampaignData(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT cp.*, c.CatalogType, c.CatalogID FROM view_Catalog c " +
                        "INNER JOIN tb_Campaign cp ON cp.Id=c.CampaignID " +
                        "WHERE CountryCode=@CountryCode AND c.CampaignID IS NOT NULL AND c.CampaignCode=@CampaignCode"; //顯示在選單

            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        /// 取得型錄的產品資料
        /// </summary>
        public static DataTable GetCatalogProduct(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_ProductInfo";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>
        /// 取得CatalogItemID
        /// </summary>
        public static int GetCatalogItemID(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT ci.ID FROM CatalogItem ci" +
                            " INNER JOIN Catalog c ON c.ID = ci.Catalog_ID" +
                            " WHERE (ci.CatNo = @CatNo) AND (c.Type = 'A') AND (c.CountryCode = @CountryCode)";
            string strCatalogItemID = db.ExecuteScalar();
            db.CloseDatabaseState("N");

            int iValue;
            int.TryParse(strCatalogItemID, out iValue);
            return iValue;
        }

        /// <summary>取得CatNo</summary>
        public static string GetCatNo(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT CatNo FROM CatalogItem ci WHERE ci.Id=@CatalogItemID";
            string strCatNo = db.ExecuteScalar();
            db.CloseDatabaseState("N");

            return strCatNo;
        }

        /// <summary>取得CatalogItemID對應的CatalogType</summary>
        public static string GetCatalogType(int catalogitemid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("catalogitemid", catalogitemid);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT Type FROM CatalogItem ci " +
                        "INNER JOIN Catalog c ON c.Id=ci.Catalog_ID " +
                        "WHERE ci.ID=@catalogitemid";
            string strType = db.ExecuteScalar();
            db.CloseDatabaseState("N");

            return strType;
        }

        /// <summary>取得首頁的Special Offer資料</summary>
        public static DataTable GetHomePagePromotionProducts(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT TOP 5 p.CatNo, " +
                        "vci.CatalogItemID, " +
                        "p.GeneID, " +
                        "p.ProductName + ' - ' + p.CatNo AS Name, " +
                        "pc.Name AS PriceCurrencyName, " +
                        "pc.DecimalNum AS PriceDecimalNum," +
                        "vci.Price, " +
                        "ppc.Name AS PromotionPriceCurrencyName, " +
                        "ppc.DecimalNum AS PromotionPriceDecimalNum," +
                        "PromotionPrice " +
                    "FROM view_CatalogItem vci " +
                    "INNER JOIN Product p ON p.CatNo = vci.CatNo " +
                    "INNER JOIN Currency pc ON pc.Id = vci.PriceCurrency_ID " +
                    "INNER JOIN Currency ppc ON ppc.Id = vci.PromotionPriceCurrency_ID " +
                    "WHERE vci.Type=@Type AND vci.CountryCode=@CountryCode";
            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dt;
        }

        /// <summary>取得變動型錄的產品資料</summary>
        public static DataTable GetCampaignCatalogProduct(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetCampaignProduct";
            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dt;
        }

        /// <summary>取得產品內容</summary>
        public static DataTable GetProductDetail(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = GetSqlParams(htParams, false, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT p.CatNo, GeneID, p.Status, p.ProductName, p.FullName, p.ProductDescription, p.Synonyms, p.Background, " +
                            "dbo.fn_GetProductClassValue(p.CatNo, 'Clonality', 1) Clonality, p.CloneNo, dbo.fn_GetProductClassValue(p.CatNo, 'Host', 1) Host, p.Isotype, p.LightChain, p.Immunogen, p.ApplicationNote, " +
                            "dbo.fn_GetProductClassValue(p.CatNo, 'Specificity', 1) Specificity, p.PositiveControls, p.Target, p.PredictedTargetSize, p.CellularLocalization, dbo.fn_GetProductClassValue(p.CatNo, 'Conjugation', 1) Conjugation, " +
                            "p.ConjuationNote, p.FormSupplied, (p.Conc + ' ' + p.ConcentrationUnit) AS Conc, p.Purification, p.PurificationNote, p.StorageBuffer, p.StorageInstruction, p.SupplierName, p.SupplierCatNo, p.Notes " +
                        "FROM CatalogItem ci " +
                        "INNER JOIN Product p ON (p.CatNo=ci.CatNo) " +
                        "WHERE (ci.Id = @CatalogItemID)";

            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dt;
        }

        /// <summary>取得型錄的前幾筆圖片</summary>
        public static DataTable GetTopNCampaignImages(Hashtable htParams, object TopN)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT TOP " + TopN.ToString() + " pa.CatNo, pa.Name, pa.Path, pa.Description, " +
                        "CASE WHEN pa.Name LIKE '%IHC%' THEN 0 ELSE 1 END SortNum " +
                        "FROM view_CatalogItem vci " +
                        "INNER JOIN ProductAttachment pa ON (pa.CatNo=vci.CatNo) AND (pa.Type='Image') AND (pa.Enabled='True') " +
                        "WHERE (vci.CountryCode=@CountryCode) AND (vci.CampaignID=@CampaignID) " +
                        "ORDER BY SortNum";
            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dt;
        }

        /// <summary>取得產品的圖片</summary>
        public static DataTable GetProductImages(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = GetSqlParams(htParams, false, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT CatNo, Name, Path, Description FROM ProductAttachment WHERE (CatNo=@CatNo) AND (Type='Image') AND (Enabled='True')";
            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dt;
        }

        /// <summary>
        /// 取得當地的經銷商資料
        /// </summary>
        /// <param name="htParams"></param>
        /// <returns></returns>
        public static DataTable GetLocalDealers(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數

            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT Top 10 Name,Image,Tel,Fax,Email,Country,State,County,City,Address,Zip,Url FROM Dealer WHERE UnderCountryCode=@UnderCountryCode AND Type='sell' AND Enabled = 0";

            DataTable dtDealers = db.ExecuteDataTable();
            db.CloseDatabaseState("N");
            return dtDealers;
        }

        /// <summary>取得產品的最後一筆更新記錄</summary>
        public static string GetProductUpdateLog(object CatNo)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("Type", "Update");
            param.Add("CatNo", CatNo);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT UpdateFields FROM ProductUpdateLog WHERE Type=@Type AND CatNo=@CatNo ORDER BY UpdateTime DESC";

            string strUpdateFields = db.ExecuteScalar();
            db.CloseDatabaseState("N");
            return strUpdateFields;
        }

        /// <summary>取得Catalog的產品List</summary>
        public static DataTable GetListByCatalog(Hashtable htParams, ref DataTable ProductClassRelTable, ref DataTable ResearchAreaRelTable)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CatalogID", htParams["CatalogID"]);
            param.Add("ResearchAreaID", htParams["Research"]);

            string strTmpTableName = DateTime.Now.ToString("hhMMssmm") + "ProductList";

            #region 組成FilterCode條件式
            string strFilter = "";
            if (htParams["FilterCode"].ToString() != "")
            {
                int i = 0;
                string[] strFilterCodeList = htParams["FilterCode"].ToString().Split(',');
                foreach (string strFilterCode in strFilterCodeList)
                {
                    strFilter += " OR (pc.Code LIKE @FilterCode" + i + ")";
                    param.Add("FilterCode" + i, strFilterCode + "%");
                    i++;
                }
                if (strFilter != "")
                {
                    param.Add("FilterCount", i);
                    strFilter = "AND (" + strFilter.Substring(4) + ")";
                }
            }
            #endregion

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            SqlCommand sqlCmd = db.SqlCommand;

            #region 取得Product List資料
            string strTable = "";
            sqlCmd.CommandText = "SELECT DISTINCT ReplacedCatNo INTO #ReplacedCatNo FROM tb_ProductReplaced; " +
                                 "SELECT * INTO #ProductAttachmentCount FROM view_ProductAttachmentCount; " +
                                 "SELECT * INTO #CatalogItem FROM view_CatalogItem WHERE (CatalogID = @CatalogID); ";

            if (strFilter != "")
            {
                sqlCmd.CommandText += "SELECT CatNo INTO #FilterCatNo FROM view_ProductClass pc WHERE (1=1) " + strFilter + " GROUP BY CatNo HAVING (COUNT(CatNo) >= @FilterCount); ";
                strTable += "INNER JOIN #FilterCatNo fc ON (fc.CatNo = p.CatNo) ";
            }

            if (htParams["Research"].ToString() != "")
            {
                strTable += "INNER JOIN tb_ResearchAreaRelGeneID ral ON (ral.GeneID = p.GeneID) " +
                            "INNER JOIN tb_SystemParam sp ON (sp.Value = ral.Name) AND (sp.Id = @ResearchAreaID) ";
            }

            sqlCmd.CommandText += "SELECT vci.CatalogItemID, p.GeneID, p.CatNo, p.ProductName, dbo.fn_SetProductListSortNumber(p.SupplierName) SortNum, p.SupplierName, " +
                                        "(vci.PackageSize + ' ' + p.PackageUnit) Package, " +
                                        "vci.Price, vci.PromotionPrice, vci.CurrencyName, vci.DecimalNum, " +
                                        "pac.ImgCount, " +
                                        "CASE WHEN pr.ReplacedCatNo IS NULL THEN 'False' ELSE 'True' END [BeReplaced] " +
                                  "INTO ##" + strTmpTableName + " " +
                                  "FROM #CatalogItem vci " +
                                  "INNER JOIN Product p ON (p.CatNo = vci.CatNo) " + strTable +
                                  "LEFT OUTER JOIN #ProductAttachmentCount pac ON (pac.CatNo = p.CatNo) AND (pac.Type = 'Image') AND (pac.Enabled = 1) " +
                                  "LEFT OUTER JOIN #ReplacedCatNo pr ON (pr.ReplacedCatNo = p.CatNo); " +

                                  "SELECT * FROM ##" + strTmpTableName + "; ";

            db.CloseDatabaseState("Y");
            SqlDataAdapter adp = new SqlDataAdapter(sqlCmd);
            DataTable dtResult = new DataTable();
            adp.Fill(dtResult);
            #endregion

            #region 取得ProductClassRel資料
            sqlCmd.CommandText = "SELECT pc.Id, pc.p_Id, pc.GroupId, pc.Code, pc.Type, pc.Name, pc.s_Name, COUNT(pl.CatNo) SubCount FROM tb_ProductClass pc " +
                                 "LEFT OUTER JOIN tb_ProductClassProductRel pcr ON (pc.Id = pcr.ClassId) " +
                                 "LEFT OUTER JOIN ##" + strTmpTableName + " pl ON (pcr.CatNo = pl.CatNo) " +
                                 "GROUP BY Id, p_Id, GroupId, Code, Type, Name, s_Name " +
                                 "HAVING COUNT(pl.CatNo) > 0 ";

            adp.Fill(ProductClassRelTable);
            #endregion

            #region 取得ResearchArea資料
            sqlCmd.CommandText = "SELECT sp.Id, sp.Value, COUNT(pl.CatNo) subCount FROM tb_SystemParam sp " +
                                 "INNER JOIN tb_ResearchAreaRelGeneID rar ON (rar.Name = sp.Value) AND (sp.Type = 'ResearchArea') " +
                                 "INNER JOIN ##" + strTmpTableName + " pl ON (pl.GeneID = rar.GeneID) " +
                                 "GROUP BY sp.Id, sp.Value " +
                                 "HAVING COUNT(pl.CatNo) > 0";

            adp.Fill(ResearchAreaRelTable);
            #endregion

            db.CloseDatabaseState("N");
            return dtResult;
        }

        /// <summary>取得Campaign的產品List</summary>
        public static DataTable GetListByCampaign(Hashtable htParams, ref DataTable ProductClassRelTable, ref DataTable ResearchAreaRelTable)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CampaignCode", htParams["CampaignCode"]);
            param.Add("ResearchAreaID", htParams["Research"]);

            string strTmpTableName = DateTime.Now.ToString("hhMMssmm") + "ProductList";

            #region 組成FilterCode條件式
            string strFilter = "";
            if (htParams["FilterCode"].ToString() != "")
            {
                int i = 0;
                string[] strFilterCodeList = htParams["FilterCode"].ToString().Split(',');
                foreach (string strFilterCode in strFilterCodeList)
                {
                    strFilter += " OR (pc.Code LIKE @FilterCode" + i + ")";
                    param.Add("FilterCode" + i, strFilterCode + "%");
                    i++;
                }
                if (strFilter != "")
                {
                    param.Add("FilterCount", i);
                    strFilter = "AND (" + strFilter.Substring(4) + ")";
                }
            }
            #endregion

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            SqlCommand sqlCmd = db.SqlCommand;

            #region 取得Product List資料
            string strTable = "";
            sqlCmd.CommandText = "SELECT DISTINCT ReplacedCatNo INTO #ReplacedCatNo FROM tb_ProductReplaced; " +
                                 "SELECT * INTO #ProductAttachmentCount FROM view_ProductAttachmentCount; ";

            if (strFilter != "")
            {
                sqlCmd.CommandText += "SELECT CatNo INTO #FilterCatNo FROM view_ProductClass pc WHERE (1=1) " + strFilter + " GROUP BY CatNo HAVING (COUNT(CatNo) >= @FilterCount); ";
                strTable += "INNER JOIN #FilterCatNo fc ON (fc.CatNo = p.CatNo) ";
            }

            if (htParams["Research"].ToString() != "")
            {
                strTable += "INNER JOIN tb_ResearchAreaRelGeneID ral ON (ral.GeneID = p.GeneID) " +
                            "INNER JOIN tb_SystemParam sp ON (sp.Value = ral.Name) AND (sp.Id = @ResearchAreaID) ";
            }

            sqlCmd.CommandText += "SELECT vci.CatalogItemID, p.GeneID, p.CatNo, p.ProductName, dbo.fn_SetProductListSortNumber(p.SupplierName) SortNum, p.SupplierName, " +
                                        "(vci.PackageSize + ' ' + p.PackageUnit) Package, " +
                                        "vci.Price, vci.PromotionPrice, vci.CurrencyName, vci.DecimalNum, " +
                                        "pac.ImgCount, " +
                                        "CASE WHEN pr.ReplacedCatNo IS NULL THEN 'False' ELSE 'True' END [BeReplaced] " +
                                  "INTO ##" + strTmpTableName + " " +
                                  "FROM view_Catalog vc " +
                                  "INNER JOIN view_CatalogItem vci ON (vci.CampaignID=vc.CampaignID) AND (vc.CampaignCode=@CampaignCode) " +
                                  "INNER JOIN Product p ON (p.CatNo = vci.CatNo) " + strTable +
                                  "LEFT OUTER JOIN #ProductAttachmentCount pac ON (pac.CatNo = p.CatNo) AND (pac.Type = 'Image') AND (pac.Enabled = 1) " +
                                  "LEFT OUTER JOIN #ReplacedCatNo pr ON (pr.ReplacedCatNo = p.CatNo); " +

                                  "SELECT * FROM ##" + strTmpTableName + "; ";

            db.CloseDatabaseState("Y");
            SqlDataAdapter adp = new SqlDataAdapter(sqlCmd);
            DataTable dtResult = new DataTable();
            adp.Fill(dtResult);
            #endregion

            #region 取得ProductClassRel資料
            sqlCmd.CommandText = "SELECT pc.Id, pc.p_Id, pc.GroupId, pc.Code, pc.Type, pc.Name, pc.s_Name, COUNT(pl.CatNo) SubCount FROM tb_ProductClass pc " +
                                 "LEFT OUTER JOIN tb_ProductClassProductRel pcr ON (pc.Id = pcr.ClassId) " +
                                 "LEFT OUTER JOIN ##" + strTmpTableName + " pl ON (pcr.CatNo = pl.CatNo) " +
                                 "GROUP BY Id, p_Id, GroupId, Code, Type, Name, s_Name " +
                                 "HAVING COUNT(pl.CatNo) > 0 ";

            adp.Fill(ProductClassRelTable);
            #endregion

            #region 取得ResearchArea資料
            sqlCmd.CommandText = "SELECT sp.Id, sp.Value, COUNT(pl.CatNo) subCount FROM tb_SystemParam sp " +
                                 "INNER JOIN tb_ResearchAreaRelGeneID rar ON (rar.Name = sp.Value) AND (sp.Type = 'ResearchArea') " +
                                 "INNER JOIN ##" + strTmpTableName + " pl ON (pl.GeneID = rar.GeneID) " +
                                 "GROUP BY sp.Id, sp.Value " +
                                 "HAVING COUNT(pl.CatNo) > 0";

            adp.Fill(ResearchAreaRelTable);
            #endregion

            db.CloseDatabaseState("N");
            return dtResult;
        }

        /// <summary>取得相關GeneID的產品List</summary>
        public static DataTable GetListByRelatedProduct(Hashtable htParams, ref DataTable ProductClassRelTable, ref DataTable ResearchAreaRelTable)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CatNo", htParams["CatNo"]);
            param.Add("GeneID", htParams["GeneID"]);
            param.Add("ResearchAreaID", htParams["Research"]);
            param.Add("CountryCode", Definition.CountryCode); //取得國家代碼

            string strTmpTableName = DateTime.Now.ToString("hhMMssmm") + "ProductList";

            #region 組成FilterCode條件式
            string strFilter = "";
            if (htParams["FilterCode"].ToString() != "")
            {
                int i = 0;
                string[] strFilterCodeList = htParams["FilterCode"].ToString().Split(',');
                foreach (string strFilterCode in strFilterCodeList)
                {
                    strFilter += " OR (pc.Code LIKE @FilterCode" + i + ")";
                    param.Add("FilterCode" + i, strFilterCode + "%");
                    i++;
                }
                if (strFilter != "")
                {
                    param.Add("FilterCount", i);
                    strFilter = "AND (" + strFilter.Substring(4) + ")";
                }
            }
            #endregion

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            SqlCommand sqlCmd = db.SqlCommand;

            #region 取得Product List資料
            string strTable = "";
            sqlCmd.CommandText = "SELECT DISTINCT ReplacedCatNo INTO #ReplacedCatNo FROM tb_ProductReplaced; " +
                                 "SELECT * INTO #ProductAttachmentCount FROM view_ProductAttachmentCount; " +
                                 "SELECT * INTO #CatalogItem FROM view_CatalogItem WHERE (Type = 'A') AND (CountryCode = @CountryCode); ";

            if (strFilter != "")
            {
                sqlCmd.CommandText += "SELECT CatNo INTO #FilterCatNo FROM view_ProductClass pc WHERE (1=1) " + strFilter + " GROUP BY CatNo HAVING (COUNT(CatNo) >= @FilterCount); ";
                strTable += "INNER JOIN #FilterCatNo fc ON (fc.CatNo = p.CatNo) ";
            }

            if (htParams["Research"].ToString() != "")
            {
                strTable += "INNER JOIN tb_ResearchAreaRelGeneID ral ON (ral.GeneID = p.GeneID) " +
                            "INNER JOIN tb_SystemParam sp ON (sp.Value = ral.Name) AND (sp.Id = @ResearchAreaID) ";
            }

            sqlCmd.CommandText += "SELECT vci.CatalogItemID, p.GeneID, p.CatNo, p.ProductName, dbo.fn_SetProductListSortNumber(p.SupplierName) SortNum, p.SupplierName, " +
                                        "(vci.PackageSize + ' ' + p.PackageUnit) Package, " +
                                        "vci.Price, vci.PromotionPrice, vci.CurrencyName, vci.DecimalNum, " +
                                        "pac.ImgCount, " +
                                        "CASE WHEN pr.ReplacedCatNo IS NULL THEN 'False' ELSE 'True' END [BeReplaced] " +
                                  "INTO ##" + strTmpTableName + " " +
                                  "FROM #CatalogItem vci " +
                                  "INNER JOIN Product p ON (p.CatNo = vci.CatNo) AND (p.GeneID = @GeneID) AND (p.CatNo <> @CatNo) " + strTable +
                                  "LEFT OUTER JOIN #ProductAttachmentCount pac ON (pac.CatNo = p.CatNo) AND (pac.Type = 'Image') AND (pac.Enabled = 1) " +
                                  "LEFT OUTER JOIN #ReplacedCatNo pr ON (pr.ReplacedCatNo = p.CatNo); " +

                                  "SELECT * FROM ##" + strTmpTableName + "; ";

            db.CloseDatabaseState("Y");
            SqlDataAdapter adp = new SqlDataAdapter(sqlCmd);
            DataTable dtResult = new DataTable();
            adp.Fill(dtResult);
            #endregion

            #region 取得ProductClassRel資料
            sqlCmd.CommandText = "SELECT pc.Id, pc.p_Id, pc.GroupId, pc.Code, pc.Type, pc.Name, pc.s_Name, COUNT(pl.CatNo) SubCount FROM tb_ProductClass pc " +
                                 "LEFT OUTER JOIN tb_ProductClassProductRel pcr ON (pc.Id = pcr.ClassId) " +
                                 "LEFT OUTER JOIN ##" + strTmpTableName + " pl ON (pcr.CatNo = pl.CatNo) " +
                                 "GROUP BY Id, p_Id, GroupId, Code, Type, Name, s_Name " +
                                 "HAVING COUNT(pl.CatNo) > 0 ";

            adp.Fill(ProductClassRelTable);
            #endregion

            #region 取得ResearchArea資料
            sqlCmd.CommandText = "SELECT sp.Id, sp.Value, COUNT(pl.CatNo) subCount FROM tb_SystemParam sp " +
                                 "INNER JOIN tb_ResearchAreaRelGeneID rar ON (rar.Name = sp.Value) AND (sp.Type = 'ResearchArea') " +
                                 "INNER JOIN ##" + strTmpTableName + " pl ON (pl.GeneID = rar.GeneID) " +
                                 "GROUP BY sp.Id, sp.Value " +
                                 "HAVING COUNT(pl.CatNo) > 0";

            adp.Fill(ResearchAreaRelTable);
            #endregion

            db.CloseDatabaseState("N");
            return dtResult;
        }

        /// <summary>取得Keyword Search的產品List</summary>
        public static DataTable GetListByKeywordSearch(Hashtable htParams, ref DataTable ProductClassRelTable, ref DataTable ResearchAreaRelTable)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("Keyword", "%" + htParams["Keyword"].ToString() + "%");
            param.Add("ResearchAreaID", htParams["Research"]);
            param.Add("CountryCode", Definition.CountryCode); //取得國家代碼

            string strTmpTableName = DateTime.Now.ToString("hhMMssmm") + "ProductList";

            #region 組成FilterCode條件式
            string strFilter = "";
            if (htParams["FilterCode"].ToString() != "")
            {
                int i = 0;
                string[] strFilterCodeList = htParams["FilterCode"].ToString().Split(',');
                foreach (string strFilterCode in strFilterCodeList)
                {
                    strFilter += " OR (pc.Code LIKE @FilterCode" + i + ")";
                    param.Add("FilterCode" + i, strFilterCode + "%");
                    i++;
                }
                if (strFilter != "")
                {
                    param.Add("FilterCount", i);
                    strFilter = "AND (" + strFilter.Substring(4) + ")";
                }
            }
            #endregion

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            SqlCommand sqlCmd = db.SqlCommand;

            #region 取得Product List資料
            string strTable = "";
            sqlCmd.CommandText = "SELECT DISTINCT ReplacedCatNo INTO #ReplacedCatNo FROM tb_ProductReplaced; " +
                                 "SELECT * INTO #ProductAttachmentCount FROM view_ProductAttachmentCount; " +
                                 "SELECT * INTO #CatalogItem FROM view_CatalogItem WHERE (Type = 'A') AND (CountryCode = @CountryCode); ";

            if (strFilter != "")
            {
                sqlCmd.CommandText += "SELECT CatNo INTO #FilterCatNo FROM view_ProductClass pc WHERE (1=1) " + strFilter + " GROUP BY CatNo HAVING (COUNT(CatNo) >= @FilterCount); ";
                strTable += "INNER JOIN #FilterCatNo fc ON (fc.CatNo = p.CatNo) ";
            }

            if (htParams["Research"].ToString() != "")
            {
                strTable += "INNER JOIN tb_ResearchAreaRelGeneID ral ON (ral.GeneID = p.GeneID) " +
                            "INNER JOIN tb_SystemParam sp ON (sp.Value = ral.Name) AND (sp.Id = @ResearchAreaID) ";
            }

            //判斷檢索欄位
            string strWhere = "";
            if (htParams["Field"].ToString() == "All")
            {
                strWhere += " AND ((ISNULL(p.OfficalName,'') + ' ' + ISNULL(p.CatNo,'') + ' ' + ISNULL(p.ProductName,'') + ' ' + ISNULL(p.Synonyms,'') + ' ' + ISNULL(p.FullName,'')) LIKE @KeyWord); ";
            }
            else
            {
                strWhere += string.Format(" AND (p.{0} LIKE @Keyword); ", htParams["Field"]);
            }

            sqlCmd.CommandText += "SELECT vci.CatalogItemID, p.GeneID, p.CatNo, p.ProductName, dbo.fn_SetProductListSortNumber(p.SupplierName) SortNum, p.SupplierName, " +
                                        "(vci.PackageSize + ' ' + p.PackageUnit) Package, " +
                                        "vci.Price, vci.PromotionPrice, vci.CurrencyName, vci.DecimalNum, " +
                                        "pac.ImgCount, " +
                                        "CASE WHEN pr.ReplacedCatNo IS NULL THEN 'False' ELSE 'True' END [BeReplaced] " +
                                  "INTO ##" + strTmpTableName + " " +
                                  "FROM #CatalogItem vci " +
                                  "INNER JOIN Product p ON (p.CatNo = vci.CatNo) " + strTable +
                                  "LEFT OUTER JOIN #ProductAttachmentCount pac ON (pac.CatNo = p.CatNo) AND (pac.Type = 'Image') AND (pac.Enabled = 1) " +
                                  "LEFT OUTER JOIN #ReplacedCatNo pr ON (pr.ReplacedCatNo = p.CatNo) " +
                                  "WHERE (1=1) " + strWhere +

                                  "SELECT * FROM ##" + strTmpTableName + "; ";

            db.CloseDatabaseState("Y");
            SqlDataAdapter adp = new SqlDataAdapter(sqlCmd);
            DataTable dtResult = new DataTable();
            adp.Fill(dtResult);
            #endregion

            #region 取得ProductClassRel資料
            sqlCmd.CommandText = "SELECT pc.Id, pc.p_Id, pc.GroupId, pc.Code, pc.Type, pc.Name, pc.s_Name, COUNT(pl.CatNo) SubCount FROM tb_ProductClass pc " +
                                 "LEFT OUTER JOIN tb_ProductClassProductRel pcr ON (pc.Id = pcr.ClassId) " +
                                 "LEFT OUTER JOIN ##" + strTmpTableName + " pl ON (pcr.CatNo = pl.CatNo) " +
                                 "GROUP BY Id, p_Id, GroupId, Code, Type, Name, s_Name " +
                                 "HAVING COUNT(pl.CatNo) > 0 ";

            adp.Fill(ProductClassRelTable);
            #endregion

            #region 取得ResearchArea資料
            sqlCmd.CommandText = "SELECT sp.Id, sp.Value, COUNT(pl.CatNo) subCount FROM tb_SystemParam sp " +
                                 "INNER JOIN tb_ResearchAreaRelGeneID rar ON (rar.Name = sp.Value) AND (sp.Type = 'ResearchArea') " +
                                 "INNER JOIN ##" + strTmpTableName + " pl ON (pl.GeneID = rar.GeneID) " +
                                 "GROUP BY sp.Id, sp.Value " +
                                 "HAVING COUNT(pl.CatNo) > 0";

            adp.Fill(ResearchAreaRelTable);
            #endregion

            db.CloseDatabaseState("N");
            return dtResult;
        }

        /// <summary>取得Catalog的訊息</summary>
        public static string GetCatalogMessage(object CatalogID)
        {
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CatalogID", CatalogID);

            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT [Description] FROM [Catalog] WHERE (Id = @CatalogID) AND (NewsType = 'List')";
            string strMessage = db.ExecuteScalar();
            db.CloseDatabaseState("N");
            return strMessage;
        }

        /// <summary>取得Campaign的訊息</summary>
        public static string GetCampaignMessage(object CampaignCode)
        {
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CampaignCode", CampaignCode);

            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT [Description], [Message] FROM [view_Catalog] WHERE (CampaignCode = @CampaignCode)";
            DataTable dtMessage = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            string strMessage = "";
            if (dtMessage.Rows.Count > 0)
            {
                DataRow row = dtMessage.Rows[0];
                strMessage += string.Format("{0}<br/><br/>{1}", row["Description"], row["Message"]);
            }

            return strMessage;
        }

        /// <summary>針對CatNo取得對應的分類內容值</summary>
        public static string GetProductClassValue(object CatNo, object Type, bool isFullName)
        {
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CatNo", CatNo);
            param.Add("Type", Type);
            param.Add("isFullName", isFullName);

            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT dbo.fn_GetProductClassValue(@CatNo, @Type, @isFullName)";
            string strResult = db.ExecuteScalar();
            db.CloseDatabaseState("N");

            return strResult;
        }

        /// <summary>指定取得某產品項目分類</summary>
        public static DataRow GetProductClassItem(Hashtable htParams)
        {
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = GetSqlParams(htParams, false, false);

            string strWhere = "";
            if (htParams.Contains("Id")) { strWhere += " AND Id=@Id"; }
            if (htParams.Contains("Code")) { strWhere += " AND Code=@Code"; }

            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT * FROM tb_ProductClass WHERE 1=1 " + strWhere;
            DataRow row = db.ExecuteDataTable().Rows[0];
            db.CloseDatabaseState("N");

            return row;
        }

        /// <summary>取得CatNo對應的BioInformation資料</summary>
        public static DataTable GetBioInformationList(object PJ)
        {
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("PJ", PJ);

            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            string strSQL = "SELECT bc.CrossSp Species, bc.CrossGene GeneID, ng.Symbol GeneName, bp.AccnNum Isoform, bc.CrossNP ProteinAccession, nl.UniprotID SwissProt, nl.OMIM OMIM " +
                            "FROM {DBName_BioInfo}[Bio-CrossReact] bc " +
                            "LEFT OUTER JOIN {DBName_BioInfo}[Bio-NCBI_Gene] ng ON (ng.GeneID = bc.CrossGene) " +
                            "LEFT OUTER JOIN {DBName_BioInfo}[Bio-PJ] bp ON (bp.ProjectID = bc.PJ) " +
                            "LEFT OUTER JOIN {DBName_BioInfo}[Bio-NCBI_Link] nl ON (nl.GeneID = bc.CrossGene) " +
                            "WHERE (bc.PJ = @PJ)";

            strSQL = strSQL.Replace("{DBName_BioInfo}", Definition.DBNameBioInfo);

            db.StrSQL = strSQL;
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>取得產品對應的Kits資料</summary>
        public static DataTable GetProductKitData(object CatNo)
        {
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CatNo", CatNo);

            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT pkit.CatNo, pkit.ProductName, (pk.PackageSize + ' ' + pkit.PackageUnit) Package FROM Product p " +
                        "INNER JOIN tb_ProductKit pk ON (p.CatNo = pk.KitNo) " +
                        "INNER JOIN Product pkit ON (pk.CatNo = pkit.CatNo) " +
                        "WHERE (p.CatNo = @CatNo) AND (pk.Enabled = 1)";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        /// <summary>取得ResearchArea對應AllProduct分類資料</summary>
        public static DataTable GetResearchAreaData()
        {
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CountryCode", Definition.CountryCode);

            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT vci.CatalogID, sp.Id, sp.Value, sp.Sort, COUNT(*) subCount " +
                        "FROM tb_SystemParam sp " +
                        "INNER JOIN tb_ResearchAreaRelGeneID rar ON (sp.Type = 'ResearchArea') AND (sp.Value = rar.Name) " +
                        "INNER JOIN Product p ON (p.GeneID = rar.GeneID) " +
                        "INNER JOIN view_CatalogItem vci ON (vci.CatNo = p.CatNo) AND (vci.Type = 'A') AND (vci.CountryCode = @CountryCode) " +
                        "GROUP BY vci.CatalogID, sp.Id, sp.Value, sp.Sort " +
                        "ORDER BY Sort";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        //取Catalog ID
        public static string GetCatalogID(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);
            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT c.Id FROM Catalog c WHERE c.Type=@Type AND c.CountryCode=@CountryCode";
            string strCatalogID = db.ExecuteScalar();

            db.CloseDatabaseState("N");
            
            return strCatalogID;
        }

        //取Catalog ID
        public static int GetCatalogID(string strCatalogItemID, ref string strDiscountMode, ref bool bWithTotal)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);
            //資料庫參數
            DataBase.SqlParams param = new Icon.DataBase.SqlParams();
            param.Add("CatalogItemID", strCatalogItemID);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT ci.Catalog_ID AS CatalogID, c.DiscountMode, c.WithTotal FROM CatalogItem ci" +
                            " INNER JOIN Catalog c ON c.Id = ci.Catalog_ID" +
                            " WHERE ci.id=@CatalogItemID AND ci.Enabled = 'True'";
            
            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            string strCatalogID = "";
            if (dt != null && dt.Rows.Count > 0)
            {
                strCatalogID = dt.Rows[0]["CatalogID"].ToString();
                strDiscountMode = dt.Rows[0]["DiscountMode"].ToString();
                if (dt.Rows[0]["WithTotal"].ToString() != "")
                    bWithTotal = Convert.ToBoolean(dt.Rows[0]["WithTotal"]);
            }

            return Convert.ToInt32(strCatalogID);
        }

        #endregion

        #region 系統參數相關
        /// <summary>
        /// 取得系統參數
        /// </summary>
        public static DataTable GetSystemParams(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetSystemParams";
            DataTable dtSystemParams = db.ExecuteDataTable();
            db.CloseDatabaseState("N");


            return dtSystemParams;
        }
        #endregion


        /// <summary>
        /// 轉換SQL參數物件
        /// </summary>
        public static DataBase.SqlParams GetSqlParams(Hashtable htParams)
        {
            return GetSqlParams(htParams, true);
        }
        public static DataBase.SqlParams GetSqlParams(Hashtable htParams, bool isReturn)
        {
            DataBase.SqlParams param = new DataBase.SqlParams();
            foreach (string key in htParams.Keys)
            {
                param.Add(key, htParams[key]);
            }

            if (isReturn)
            {
                param.Add("Message", ParameterDirection.Output);
                param.Add("ReturnValue", ParameterDirection.ReturnValue);
            }

            return param;
        }
        public static DataBase.SqlParams GetSqlParams(Hashtable htParams, bool isReturn, bool isCountryCode)
        {
            DataBase.SqlParams param = GetSqlParams(htParams, isReturn);
            if (isCountryCode)
            {
                param.Add("CountryCode", Definition.CountryCode); //取得國家代碼
                param.Add("Lang", CultureInfo.CurrentCulture.Name); //取得目前語系;
            }
            return param;
        }

        #region 寄信相關 yunyu

        /// <summary>
        /// ContactUs的資料加入資料庫
        /// </summary>
        public static void InsertContactUs(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertContactUs";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        /// <summary>
        /// ContactSales的資料加入資料庫
        /// </summary>
        public static void InsertContactSales(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertContactSales";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        /// <summary>
        /// Support的資料加入資料庫
        /// </summary>
        public static void InsertSupport(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertSupport";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        public static void InsertSurveyLog(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertSurveyLog";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        #endregion

        #region 產品搜尋相關 yunyu

        /// <summary>
        /// 依參數(數字，字母)找尋產品資訊
        /// </summary>
        public static DataTable GetProductsByParam(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetProductsByParam";
            DataTable dtProducts = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtProducts;
        }

        /// <summary>
        /// 用CatNo找相關的PubMed文獻
        /// </summary>
        public static DataTable GetPubMed(string strCatNo)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CatNo", strCatNo);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT PubMed FROM ProductRef WHERE CatNo = @CatNo ORDER BY PubMed";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>
        /// 取得貨幣資料
        /// </summary>
        public static DataTable GetCurrency()
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //執行DB
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetCurrency";
            DataTable dtCurrency = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtCurrency;
        }

        /// <summary>
        /// 進階搜尋結果
        /// </summary>
        public static DataTable GetProductsByAdvanced(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetProductsByAdvanced";
            DataTable dtProducts = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtProducts;
        }

        /// <summary>
        /// 將SearchLog 寫入資料庫
        /// </summary>
        public static void InsertSearchLog(out bool bResult, out string strMessage, Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertSearchLog";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
            }
            else
            {
                bResult = false;
            }
        }

        /// <summary>取得產品搜尋是否有結果，只找All Product</summary>
        public static bool GetProductSearchResult(Hashtable htParams, string strField)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT COUNT(*) FROM view_CatalogItem vci " +
                        "INNER JOIN Product p ON (p.CatNo = vci.CatNo) " +
                        "WHERE (vci.Type = 'A') AND (vci.CountryCode = @CountryCode) ";

            if (strField == "All")
            {
                db.StrSQL += " AND ((ISNULL(p.OfficalName,'') + ' ' + ISNULL(p.CatNo,'') + ' ' + ISNULL(p.ProductName,'') + ' ' + ISNULL(p.Synonyms,'') + ' ' + ISNULL(p.FullName,'')) LIKE @KeyWord) ";
            }
            else if (strField == "OfficalName" || strField == "CatNo" || strField == "ProductName" || strField == "Synonyms" || strField == "FullName")
            {
                db.StrSQL += " AND (p." + strField + " LIKE @KeyWord) ";
            }

            string strResult = db.ExecuteScalar();
            db.CloseDatabaseState("N");

            if (Convert.ToInt32(strResult) > 0)
                return true;
            else
                return false;
        }

        /// <summary>取得KeyWordSearch對應的Symbol,Synonyms資料</summary>
        public static DataTable GetKeyWrodSearchSymbol(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetKeyWrodSearchSymbol";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        public static DataTable GetProductSearchList(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetProductSearchList";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        #endregion

        #region 靜態頁面搜尋相關 yunyu
        /// <summary>
        /// 搜尋靜態頁面資訊
        /// </summary>
        public static DataTable GetStaticPage(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_GetStaticPage";
            DataTable dtStaticPage = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtStaticPage;
        }

        //取得Forum名稱從Forum DB
        public static DataTable GetForum(string strCategory)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("Category", strCategory);
            param.Add("CountryCode", Definition.CountryCode); //取得國家代碼

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT forum.ForumID, forum.Name FROM GeneTexForum.dbo.yaf_Forum forum" +
                            " INNER JOIN GeneTexForum.dbo.yaf_Category cate on cate.CategoryID = forum.CategoryID" +
                            " WHERE cate.Name = @Category AND cate.CountryCode=@CountryCode";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtResult;
        }

        #endregion

        #region Public頁面相關

        /// <summary>
        /// 取得News資料
        /// </summary>
        public static DataTable GetNews(Hashtable htParams)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, false, true);

            string strWhere = "";
            if (htParams["Id"] != null) { strWhere += " AND (n.Id=@Id)"; }
            if (htParams["Type"] != null) { strWhere += " AND (n.Type=@Type)"; }
            if (htParams["IsSlide"] != null) { strWhere += " AND (n.IsSlide=@IsSlide)"; }
            if (htParams["Enabled"] != null) { strWhere += " AND (n.Enabled=@Enabled)"; }

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT n.Id, n.CountryCode, n.Lang, n.Name, n.ImgSrc, n.Description, n.Content, n.IsSlide, n.SlideContent, n.SlideTimeSpan, dbo.fn_GetLocalDateTime('Minute', co.TimeZone, n.StartDate) StartDate, dbo.fn_GetLocalDateTime('Minute', co.TimeZone, n.EndDate) EndDate, n.Type " +
                        "FROM News n " +
                        "INNER JOIN tb_Country co ON co.Code=n.CountryCode " +
                        "WHERE (n.CountryCode=@CountryCode) AND (n.Lang=@Lang) AND (dbo.fn_GetLocalDateTime('Minute', co.TimeZone, null) BETWEEN n.StartDate AND n.EndDate) " + strWhere +
                        "ORDER BY n.StartDate DESC";

            DataTable dtSystemParams = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            return dtSystemParams;
        }

        public static DataTable GetCompany(string strType, string strCode)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("Enabled", 1, SqlDbType.Bit);
            param.Add("Type", strType, SqlDbType.VarChar);
            param.Add("Code", strCode, SqlDbType.VarChar);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT tb_Company.id,tb_Company.Name, tb_Company.Tel,tb_Company.Fax,tb_Company.Email,tb_Country.Name Country,tb_Company.Address1,tb_Company.Address2,tb_Company.Address3,tb_Company.Zip,tb_Company.Url,tb_Country.ImgSrc Image " +
                        "FROM tb_Company " +
                        "INNER JOIN tb_Country ON tb_Company.CountryCode=tb_Country.Code " +
                        "WHERE tb_Company.Enabled=@Enabled and tb_Company.Type=@Type and (GETDATE() BETWEEN tb_Company.EffectiveDate AND tb_Company.ExpiryDate) " +
                        (strCode == "" ? "" : "AND tb_Company.CountryCode=@Code ") +
                        "ORDER BY tb_Country.Name";
            DataTable dtResult = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dtResult;
        }

        /// <summary>取得巡覽列名稱</summary>
        public static string GetNavigatorName(string strSQL)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //執行DB
            db.CommandType = CommandType.Text;
            db.StrSQL = strSQL;
            string strResult = db.ExecuteScalar();
            db.CloseDatabaseState("N");

            //回傳資料
            return strResult;
        }
        #endregion

        #region Campaign相關 yunyu

        /// <summary>Click Campaign Mial的Url,寫進資料庫</summary>
        public static void InsertCamapignClick(ref bool bResult, ref string strMessage, Hashtable htParams, object oMemberID)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.CamConnStr);

            //資料庫參數
            DataBase.SqlParams param = GetSqlParams(htParams, true, false);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.StoredProcedure;
            db.StrSQL = "Pro_InsertCampaignClick";
            db.ExecuteSQL();

            //判斷與回傳DB執行狀態
            strMessage = ((SqlParameter)param["Message"]).Value.ToString();
            string strResultValue = ((SqlParameter)param["ReturnValue"]).Value.ToString();
            if (strResultValue == "0")
            {
                bResult = true;
                db.SqlConnection.ConnectionString = Icon.Definition.WebConnStr;
                db.CommandType = CommandType.Text;
                db.StrSQL = "SELECT CatNo FROM CatalogItem WHERE Id=@CatalogItemID";
                string strCatNo = db.ExecuteScalar();

                if (oMemberID != null && strCatNo != "")
                {
                    param.Add("Member_ID", oMemberID);
                    param.Add("CountryCode", Definition.CountryCode);
                    param.Add("Type", "Campaign");
                    param.Add("Status", 76);

                    db.SqlParams = param;
                    db.CommandType = CommandType.Text;
                    db.StrSQL = "SELECT ID, CatNoList,CreateDate FROM FollowCustomer WHERE Member_ID=@Member_ID AND Type=@Type AND Status=@Status";

                    DataTable dt = db.ExecuteDataTable();
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        //用現有的更新CatNoList
                        string strCatNoList = dt.Rows[0]["CatNoList"].ToString();
                        string strID = dt.Rows[0]["ID"].ToString();

                        strCatNoList += (strCatNoList == "" ? "" : ",") + strCatNo;

                        param.Add("CatNo", strCatNoList);
                        param.Add("ID", strID);
                        db.SqlParams = param;
                        db.StrSQL = "UPDATE FollowCustomer SET CatNoList=@CatNo, CreateDate=GETDATE() WHERE ID=@ID AND Status=@Status";
                    }
                    else
                    {
                        param.Add("CatNo", strCatNo);
                        db.SqlParams = param;
                        db.StrSQL = "INSERT FollowCustomer(CountryCode, Member_ID, CatNoList, Type, CreateDate, Status)" +
                                        " VALUES(@CountryCode, @Member_ID, @CatNo, @Type, GETDATE(), @Status)";
                    }
                    db.ExecuteSQL();

                }
            }
            else
            {
                bResult = false;
            }

            db.CloseDatabaseState("N");
        }

        public static string GetCamapignCode(object oCampaignID)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.CamConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CampaignID", oCampaignID);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT CodePrefix FROM Campaign WHERE ID = @CampaignID";
            string strCodePrefix = db.ExecuteScalar().Trim();
            db.CloseDatabaseState("N");

            //回傳資料
            return strCodePrefix;
        }

        /// <summary>取得Campaign的顯示訊息</summary>
        public static string GetCampaignMessageByID(object oCampaignID)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CampaignID", oCampaignID);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT Message FROM tb_Campaign WHERE Id = @CampaignID";
            string strMessage = db.ExecuteScalar();
            db.CloseDatabaseState("N");

            //回傳資料
            return strMessage;
        }

        #endregion

        #region Catalog List相關 yunyu

        public static DataTable GetCatalogList()
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("CountryCode", Definition.CountryCode);

            //執行DB
            db.SqlParams = param;
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT c.Id, c.Name, c.Type, c.ImgSrc, c.Description, c.NewsType FROM Catalog c" +
                            " INNER JOIN dbo.tb_Country AS ct ON ct.Code = c.CountryCode" +
                            " WHERE c.CountryCode=@CountryCode AND dbo.fn_GetLocalDateTime('Minute', ct.TimeZone, NULL) BETWEEN c.StartDate AND c.EndDate";
            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dt;
        }

        public static DataTable GetCatalogDetail(object oID, object oCampaignCode)
        {
            //物件初始化
            DataBase.DataBase db = new Icon.DataBase.DataBase(Icon.Definition.WebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new DataBase.SqlParams();
            param.Add("ID", oID);

            //執行DB
            db.CommandType = CommandType.Text;
            db.StrSQL = "SELECT c.Id, c.Name, c.ImgSrc, c.Description";
            string strFROM = " FROM Catalog c";
            string strWHERE = " WHERE c.Id=@ID";
            if (oCampaignCode != null)
            {
                db.StrSQL += ", cam.Message AS CamDescription";
                strFROM += " INNER JOIN tb_Campaign cam ON cam.Catalog_ID = c.Id";
                strWHERE += " AND cam.Code=@Code";
                param.Add("Code", oCampaignCode);
            }

            db.StrSQL += strFROM + strWHERE;
            db.SqlParams = param;

            DataTable dt = db.ExecuteDataTable();
            db.CloseDatabaseState("N");

            //回傳資料
            return dt;
        }

        #endregion
    }
}