﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.Member;
using df = Icon.Definition;
using Icon;

public partial class GoToForum : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		string strMessage = "";
		bool bResult = false;

		MemberInfo mi = df.OnlineMemberInfoList[df.PersonalMemberID];
		Security security = new Security();
		string strEnEmail = security.EncryptQueryString(mi.Email);
		BLL.GotoForum(strEnEmail, ref strMessage, ref bResult);
		string strURL = ConfigurationManager.AppSettings["ForumURL"];

		if (bResult)
		{
			strURL = string.Format("{0}?g=login&email={1}", strURL, strEnEmail);
		}
		else if (!bResult)
		{
			strURL = string.Format("{0}?g=login", strURL);
		}
		Response.Redirect(strURL);
    }
}
