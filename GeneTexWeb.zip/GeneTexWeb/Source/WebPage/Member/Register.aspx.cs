﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_Register : System.Web.UI.Page
{
    private string strCulture;

    //初始化
    protected void Page_Init(object sender, EventArgs e)
    {
        //若已登入則導向個人會員頁面
        if (MemberInfo.CheckMemberLogin())
        {
            Response.Redirect("~/WebPage/Member/MyAccount.aspx");
        }
        else
        {
            div_CultureInfo1.InnerHtml = Resources.Public.Register_Info1;
            div_CultureInfo2.InnerHtml = Resources.Public.Register_Info2;

            //預設Enter按鈕
            Page.Form.DefaultButton = btnRegister.UniqueID;
        }

        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
    }

    //註冊
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        //驗証資料格式與地址正確性
        string strMessage1 = "";
        if (MemberProfile1.CheckMemberInfo(ref strMessage1))
        {
            //驗証地址正確性
            if (MemberProfile1.CheckMemberAddress(ref strMessage1))
            {
                MemberInfo mi = MemberProfile1.GetMemberProfile();

                //參數集合
                Hashtable htParams = new Hashtable();
                htParams.Add("ActionType", "RegisterNewMember");
                htParams.Add("Account", mi.Account);
                htParams.Add("Title", mi.Title);
                htParams.Add("FirstName", mi.FirstName);
                htParams.Add("LastName", mi.LastName);
                htParams.Add("Email", mi.Email);
                htParams.Add("Institution", mi.Institution);
                htParams.Add("Position", int.Parse(mi.Position));
                //htParams.Add("ResearchArea", int.Parse(mi.ResearchArea));
                htParams.Add("Password", mi.Password);
                htParams.Add("PasswordQ", int.Parse(mi.PasswordQ));
                htParams.Add("PasswordA", mi.PasswordA);
                htParams.Add("Address1", mi.Address1);
                htParams.Add("Address2", mi.Address2);
                htParams.Add("City", mi.City);
                htParams.Add("County", mi.County);
                htParams.Add("State", mi.State);
                htParams.Add("Zip", mi.Zip);
                htParams.Add("Country", mi.Country);
                htParams.Add("Phone", mi.Phone);
                htParams.Add("Ext", mi.Ext);
                htParams.Add("Fax", mi.Fax);
                htParams.Add("Type", "Web");
                htParams.Add("Status", "Active");

                //呼叫邏輯層
                bool bResult;
                string strMessage;
                BLL.RegisterNewMember(out bResult, out strMessage, htParams);

                //設定回傳狀態 & 訊息
                cvMessage.IsValid = bResult;
                cvMessage.ErrorMessage = strMessage;

                //若執行成功
                if (bResult)
                {
                    //新增Member和ResearchGeneID的關聯,strMessage=MemberID
                    if (!string.IsNullOrEmpty(mi.ResearchGeneID) && Convert.ToInt32(strMessage) > 0)
                        BLL.AddMemberGeneIdRel(strMessage, mi.ResearchGeneID);

                    //設定帳號&密碼的Url參數
                    Security sec = new Security();
                    string strAcct = sec.EncryptQueryString(mi.Account);
                    string strPwd = sec.EncryptPassWord(mi.Password);

                    //邏輯層Mail參數
                    Hashtable mailParams = new Hashtable();
                    mailParams.Add("FirstName", mi.FirstName);
                    mailParams.Add("LastName", mi.LastName);
                    mailParams.Add("ToEmailAddress", mi.Email);

                    //若發送會員通知信成功
                    if (BLL.SendNewMemberMail(mailParams))
                    {
                        //跨頁執行自動登入程序
                        string strUrl = string.Format("Login.aspx?type=register&acct={0}&pwd={1}", strAcct, strPwd);
                        Response.Redirect(strUrl);
                    }
                }
            }
            else
            {
                //錯誤訊息
                cvMessage.IsValid = false;
                cvMessage.ErrorMessage = strMessage1;
            }
        }
        else
        {
            //錯誤訊息
            cvMessage.IsValid = false;
            cvMessage.ErrorMessage = strMessage1;
        }
    }
}