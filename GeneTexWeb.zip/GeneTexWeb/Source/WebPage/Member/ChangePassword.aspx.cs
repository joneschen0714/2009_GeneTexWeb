﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_ChangePassword : System.Web.UI.Page
{
    protected override void OnInit(EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //編輯按鈕動作
    protected void btnModify_Click(object sender, EventArgs e)
    {
        //設定變數
        MemberInfo miThis = df.OnlineMemberInfoList[df.PersonalMemberID];

        //建立資料參數
        Hashtable htParams = new Hashtable();
        htParams.Add("MemberID",df.PersonalMemberID.Value);
        htParams.Add("CurrentPwd", miThis.Password);
        htParams.Add("OldPassword", txtOldPwd.Text.Trim());
        htParams.Add("NewPassword", txtNewPwd.Text.Trim());
        htParams.Add("ConfirmPassword", txtConfirmPwd.Text.Trim());

        //呼叫邏輯層
        bool bResult = true;
        string strMessage = "";
        BLL.ChangePassword(out bResult, out strMessage, htParams);

        //若執行成功
        if (bResult)
        {
            miThis.Password = txtNewPwd.Text.Trim(); //更新密碼
            //清Cookie
            if (Request.Cookies["autologin"] != null)
            {
                HttpCookie Cookie = new HttpCookie("autologin");
                Cookie.Expires = DateTime.Now.AddDays(-2);
                Response.Cookies.Add(Cookie);
            }

            Response.Redirect("~/WebPage/Member/MyAccount.aspx"); //導回會員個人首頁
        }
        else
        {
            //顯示訊息
            lblMessage.Text = strMessage;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //導回會員個人首頁
        Response.Redirect("~/WebPage/Member/MyAccount.aspx");
    }
}