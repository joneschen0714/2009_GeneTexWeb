﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_MyProfile : MemberPageBase
{
    protected override void OnInit(EventArgs e)
    {
        #region 引用頁面Css檔 & JavaScript檔
        //ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "jQuery", ResolveClientUrl("~/Js/jQuery/jquery-1.2.6.min.js"));
        //ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
        ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "PageScript",
            "$(document).ready(function() {" +
                "$('input[@type=password]').parent('tr').hide();" +
            "});", true);
        #endregion
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //第一次進入
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入會員資料
        MemberInfo mi = df.OnlineMemberInfoList[df.PersonalMemberID];
        MemberProfile1.SetMemberInfo(mi);
        Session.Add("OldEmail", mi.Email);

        //設定控制項相關
        ((TextBox)MemberProfile1.FindControl("txtAccount")).Enabled = false;
        MemberProfile1.FindControl("btnCheckAccount").Visible = false;
        MemberProfile1.FindControl("lblCheckAccountResult").Visible = false;
        MemberProfile1.FindControl("trPassword").Visible = false;
        MemberProfile1.FindControl("trReEnterPassword").Visible = false;
    }

    //編輯按鈕動作
    protected void btnModify_Click(object sender, EventArgs e)
    {
        string strMessage1 = "";
        if (MemberProfile1.CheckMemberAddress(ref strMessage1)) //檢查地址正確性
        {
            //取得編輯後資料
            MemberInfo mi = MemberProfile1.GetMemberProfile();

            //建立資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("ActionType", "ModifyMemberInfo");
            htParams.Add("MemberID", df.PersonalMemberID.Value);
            htParams.Add("Title", mi.Title);
            htParams.Add("FirstName", mi.FirstName);
            htParams.Add("LastName", mi.LastName);
            htParams.Add("Email", mi.Email);
            htParams.Add("Institution", mi.Institution);
            htParams.Add("Position", mi.Position);
            //htParams.Add("ResearchArea", mi.ResearchArea);
            htParams.Add("PasswordQ", mi.PasswordQ);
            htParams.Add("PasswordA", mi.PasswordA);
            htParams.Add("Address1", mi.Address1);
            htParams.Add("Address2", mi.Address2);
            htParams.Add("City", mi.City);
            htParams.Add("County", mi.County);
            htParams.Add("State", mi.State);
            htParams.Add("Zip", mi.Zip);
            htParams.Add("Country", mi.Country);
            htParams.Add("Phone", mi.Phone);
            htParams.Add("Ext", mi.Ext);
            htParams.Add("Fax", mi.Fax);

            Session.Add("NewEmail", mi.Email);
            //呼叫邏輯層
            bool bResult;
            string strMessage;
            BLL.RegisterNewMember(out bResult, out strMessage, htParams);

            //更新Member和ResearchGeneID的關聯
            if (!string.IsNullOrEmpty(mi.ResearchGeneID))
                BLL.AddMemberGeneIdRel(df.PersonalMemberID.Value, mi.ResearchGeneID);

            //若執行成功
            if (bResult)
            {
                BLL.ModifyEmailToForum(Session["OldEmail"].ToString(), Session["NewEmail"].ToString(), ref strMessage, ref bResult);
                Session.Remove("OldEmail");
                Session.Remove("NewEmail");

                //更新目前此會員資料
                MemberInfo miThis = df.OnlineMemberInfoList[df.PersonalMemberID.Value];
                miThis.Title = mi.Title;
                miThis.FirstName = mi.FirstName;
                miThis.LastName = mi.LastName;
                miThis.Email = mi.Email;
                miThis.Institution = mi.Institution;
                miThis.Position = mi.Position;
                miThis.ResearchArea = mi.ResearchArea;
                miThis.PasswordQ = mi.PasswordQ;
                miThis.PasswordA = mi.PasswordA;
                miThis.Address1 = mi.Address1;
                miThis.Address2 = mi.Address2;
                miThis.City = mi.City;
                miThis.County = mi.County;
                miThis.State = mi.State;
                miThis.Zip = mi.Zip;
                miThis.Country = mi.Country;
                miThis.Phone = mi.Phone;
                miThis.Ext = mi.Ext;
                miThis.Fax = mi.Fax;
                miThis.ResearchGeneID = mi.ResearchGeneID;
                miThis.ResearchArea = mi.ResearchArea;

                //導回會員個人首頁
                Response.Redirect("~/WebPage/Member/MyAccount.aspx");
            }
            else
            {
                //顯示訊息
                lblMessage.Text = strMessage;
            }
        }
        else
        {
            //顯示訊息
            lblMessage.Text = strMessage1;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //導回會員個人首頁
        Response.Redirect("~/WebPage/Member/MyAccount.aspx");
    }
}
