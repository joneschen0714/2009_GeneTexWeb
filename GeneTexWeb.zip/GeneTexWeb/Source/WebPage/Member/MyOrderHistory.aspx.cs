﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Controls;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_MyOrderHistory : MemberPageBase
{
    protected override void OnInit(EventArgs e)
    {
        gvHistory.GridView.RowDataBound += new GridViewRowEventHandler(gvHistory_RowDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //呼叫邏輯層
        DataTable dtHistoryList = BLL.GetOrderHistoryList(df.PersonalMemberID.Value);

        //欄位設定
        gvHistory.Fields.Clear();
        Icon.Controls.myGridView.FieldCollection fc = gvHistory.Fields;
        fc.Add("Order Type", "OrderType", true, Unit.Empty, "");
        fc.Add("Order Date", "OrderDate", true, Unit.Empty, "");
        fc.Add("Item Count", "ItemCount", false, Unit.Empty, "");
        fc.Add("Total Price", "TotalPrice", true, Unit.Empty, "");
        fc.Add("Detail", "", false, Unit.Empty, "");

        //繫結訂單歷史清單 & 相關設定
        gvHistory.Property.DataKey = "OrderID";
        gvHistory.DataTable = dtHistoryList;
        gvHistory.DataBind();

        //釋放資源
        dtHistoryList.Dispose();
        gvHistory.Dispose();
    }

    //Row處理事件
    protected void gvHistory_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;

            //取得TableCell物件
            TableCell cellOrderType = Tool.GetTableCell(e.Row, "OrderType", true);
            TableCell cellOrderDate = Tool.GetTableCell(e.Row, "OrderDate", true);
            TableCell cellItemCount = Tool.GetTableCell(e.Row, "ItemCount", true);
            TableCell cellTotalPrice = Tool.GetTableCell(e.Row, "TotalPrice", true);
            TableCell cellDetail = Tool.GetTableCell(e.Row, "Detail", false);

            //檢視詳細資料連結按鈕
            LinkButton hlDetail = new LinkButton();
            hlDetail.Text = "View";
            hlDetail.CssClass = "a2";
            hlDetail.Click += new EventHandler(ViewDetail_Click);
            hlDetail.CommandArgument = rowView["OrderID"].ToString();
            cellDetail.Controls.Add(hlDetail);

            //設定欄位值
            cellTotalPrice.Text = Setting.GetCurrencyFormat("$", decimal.Parse(cellTotalPrice.Text), 2);
            cellOrderDate.Text = DateTime.Parse(cellOrderDate.Text).ToString("MM/dd/yyyy");
        }
    }

    //ViewDetail按鈕動作
    protected void ViewDetail_Click(object sender, EventArgs e)
    {
        string strOrderID = ((LinkButton)sender).CommandArgument; //取得OrderID

        //呼叫邏輯層(OrderItem資料繫結)
        DataTable dtItems = BLL.GetHistoryOrderListItem(int.Parse(strOrderID));
        repOrderItem.DataSource = dtItems;
        repOrderItem.DataBind();
        divDetail.Visible = true;
    }

    //OrderItem處理事件
    protected void repOrderItem_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            //取得控制項
            Label lblCatNo = (Label)e.Item.FindControl("lblCatNo");
            Label lblProduct = (Label)e.Item.FindControl("lblProduct");
            Label lblUnitPrice = (Label)e.Item.FindControl("lblUnitPrice");
            Label lblQuility = (Label)e.Item.FindControl("lblQuility");
            Label lblPrice = (Label)e.Item.FindControl("lblPrice");

            //設定控制項值
            lblCatNo.Text = string.Format("{0}", rowView["CatNo"]);
            lblProduct.Text = string.Format("{0}", rowView["ProductName"]);
            lblUnitPrice.Text = Setting.GetCurrencyFormat("$",decimal.Parse(rowView["Price"].ToString()),2);
            lblQuility.Text = string.Format("{0}",rowView["Quility"]);
            lblPrice.Text = Setting.GetCurrencyFormat("$",decimal.Parse(rowView["TotalPrice"].ToString()),2);
        }
    }
}