﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Member;
using df = Icon.Definition;
using ws_Forum;

public partial class WebPage_Member_MyAccount : MemberPageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
		string strURL = "~/GoToForum.aspx";
		btnForum.Attributes.Add("onclick", "javascript:window.open('" + ResolveUrl(strURL) + "');return false;");
    }

    protected void MemberButton_Click(object sender, EventArgs e)
    {
        LinkButton linkBtn = (LinkButton)sender;

        if (linkBtn.ID == "btnModifyAccount")
        {
            Response.Redirect("~/WebPage/Member/MyProfile.aspx");
        }
        else if (linkBtn.ID == "btnViewMyOrder")
        {
            Response.Redirect("~/WebPage/Member/MyOrderHistory.aspx");
        }
        else if (linkBtn.ID == "btnChangePassowrd")
        {
            Response.Redirect("~/WebPage/Member/ChangePassword.aspx");
        }
        else if (linkBtn.ID == "btnAddress")
        {
            Response.Redirect("~/WebPage/Member/OrderInfo.aspx?type=addresslist");
        }
    }
}
