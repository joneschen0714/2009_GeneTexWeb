﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_QuickOrder : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));

        //控制項顯示文字設定 & 相關設定
        Label1.Text = "Quick Order:";
        Label2.Text = "Enter Catalog# to quickly add it to your Shopping Cart.";
        lblMemo.Text = "(ex:GTX10006)";
        imgAdd.ImageUrl = "~/Images/Images/icons/icon_cart_continue.gif";
        imgAdd.ToolTip = "Add to Shopping Cart";
        txtCatNo.Attributes.Add("onmousedown", "MouseRightLimit();");

        //預設Enter按鈕
        Page.Form.DefaultButton = imgAdd.UniqueID;
    }

    ////新增圖示按鈕事件
    protected void btnReloadShoppingCart_Click(object sender, EventArgs e)
    {
        //重整購物車清單
        IceBucket1.RemoveShoppingTableRow();
        IceBucket1.DataBind();
    }
}
