﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_WishList : MemberPageBase
{
    //全域變數
    private int? iMemberID = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));

        iMemberID = df.PersonalMemberID; //設定會員ID

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        DataTable dtWishList = BLL.GetMemberWishList(iMemberID.Value);
        repWishList.DataSource = dtWishList;
        repWishList.DataBind();
    }

    protected void repWishList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        //HeadTemplate
        if (e.Item.ItemType == ListItemType.Header)
        {
            //若無資料列則顯示訊息
            if (((DataTable)repWishList.DataSource).Rows.Count == 0)
            {
                Control ctrlTR = e.Item.FindControl("TrNoData");
                ctrlTR.Visible = true;
            }
        }

        //ItemTemplate
        else if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            //取得控制項
            HiddenField hiddenWisthListID = (HiddenField)e.Item.FindControl("hiddenWisthListID");
            HyperLink linkProductName = (HyperLink)e.Item.FindControl("linkProductName");
            Label lblCatNo = (Label)e.Item.FindControl("lblCatNo");
            Label lblPackage = (Label)e.Item.FindControl("lblPackage");
            TextBox txtQty = (TextBox)e.Item.FindControl("txtQty");

            //設定值
            hiddenWisthListID.Value = rowView["WisthList_ID"].ToString();
            linkProductName.Text = rowView["ProductName"].ToString();
            linkProductName.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + rowView["CatalogItem_ID"].ToString();
            if (rowView["CampaignID"].ToString() != "") { linkProductName.NavigateUrl += "&CampaignID=" + rowView["CampaignID"].ToString(); }
            lblCatNo.Text = rowView["CatNo"].ToString();
            lblPackage.Text = rowView["Package"].ToString();
        }
    }

    //刪除按鈕
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string strIDArray = "";
        foreach (RepeaterItem ri in repWishList.Items) //循序讀取WishList項目
        {
            //取得控制項
            CheckBox chkSelect = (CheckBox)ri.FindControl("chkSelect");
            HiddenField hiddenWisthListID = (HiddenField)ri.FindControl("hiddenWisthListID");

            //若有選擇則累加WishListID
            if (chkSelect.Checked)
                strIDArray += "," + hiddenWisthListID.Value;
        }

        //若有選擇項目
        if (strIDArray != "")
        {
            //呼叫邏輯層
            bool bResult;
            string strMessage;
            BLL.DeleteMemberWishList(out bResult, out strMessage, strIDArray.TrimStart(','));

            if (bResult) //若為成功狀態
            {
                DataBind();
            }
            else
            {
                //顯示錯誤訊息
                lblMessage.Text = strMessage;
                lblMessage.Visible = true;
            }
        }
    }

    //新增至購物車
    protected void btnAddIceBucket_Click(object sender, EventArgs e)
    {
        //建立暫存資料表
        DataTable dtQty = new DataTable("dtQty");
        dtQty.Columns.Add("WishListID", typeof(int));
        dtQty.Columns.Add("Qty", typeof(int));
        dtQty.PrimaryKey = new DataColumn[] { dtQty.Columns["WishListID"] };

        //循序讀取WishList項目
        foreach (RepeaterItem ri in repWishList.Items)
        {
            //取得控制項
            CheckBox chkSelect = (CheckBox)ri.FindControl("chkSelect");
            HiddenField hiddenWisthListID = (HiddenField)ri.FindControl("hiddenWisthListID");
            TextBox txtQty = (TextBox)ri.FindControl("txtQty");

            //若為非數字格式，則為1
            int iReturn;
            int.TryParse(txtQty.Text.Trim(), out iReturn);
            iReturn = (iReturn <= 0 ? 1 : iReturn);

            //若有選擇則新增資料列
            if (chkSelect.Checked)
                dtQty.Rows.Add(hiddenWisthListID.Value, iReturn);
        }

        //若有選取資料列
        if (dtQty.Rows.Count > 0)
        {
            //取得會員的Wish List
            DataTable dtWishList = BLL.GetMemberWishList(iMemberID.Value);
            dtWishList.TableName = "dtWishList";

            //加入Table至DataSet
            DataSet ds = new DataSet();
            ds.Tables.AddRange(new DataTable[] { dtQty, dtWishList });

            //建立關連
            DataRelation dr = new DataRelation("relWishListQty", ds.Tables["dtWishList"].Columns["WisthList_ID"], ds.Tables["dtQty"].Columns["WishListID"], false);
            ds.Relations.Add(dr);

            bool bResult = false;
            string strMessage = "";

            //循序讀取選取的資料列
            foreach (DataRow row in dtQty.Rows)
            {
                //關連父資料列
                DataRow rowParent = row.GetParentRow("relWishListQty");

                //資料參數 (傳至商業邏輯層處理)
                Hashtable htParams = new Hashtable();
                htParams.Add("CatalogItemID", rowParent["CatalogItem_ID"]);
                htParams.Add("CampaignID", rowParent["CampaignID"]);
                htParams.Add("CatNo", rowParent["CatNo"]);
                htParams.Add("Qty", row["Qty"]);

                //判斷產品是否在購物車重覆
                bResult = BLL.CheckProductExistsShoppingCart(Convert.ToInt32(rowParent["CatalogItem_ID"]), rowParent["CatNo"].ToString(), ref strMessage);

                //判斷產品是否有折扣，及是否有購買上線
                int iQty = Convert.ToInt32(row["Qty"]);
                BLL.GetCatalogDiscount(rowParent["CatalogItem_ID"].ToString(), ref iQty, ref bResult, ref strMessage);
                if (iQty > 0 && bResult)
                {
                    //呼叫邏輯層 (新增產品至購物車)
                    BLL.AddProductToShoppingCart(ref bResult, ref strMessage, htParams);
                }
                if (!bResult)
                    break;
            }
            if (bResult)
                Response.Redirect("~/WebPage/Member/IceBucket.aspx"); //導向購物車頁面
            else if (!bResult && strMessage != "")
            {
                //顯示錯誤訊息
                lblMessage.Text = strMessage;
                lblMessage.Visible = true;
            }
        }
    }
}