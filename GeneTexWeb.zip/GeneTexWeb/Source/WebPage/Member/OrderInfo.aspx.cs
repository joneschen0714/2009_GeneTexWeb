﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_OrderInfo : MemberPageBase
{
    private string strType = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        #region 引用頁面Css檔 & JavaScript檔
        string strStyle = "<style>" +
                                "#tbAddress th { width:70px; } " +
                                "#tbPO th { width:130px; } " +
                                "#tbCard th { width:130px; } " +
                          "</style>";
        LiteralControl lic = new LiteralControl(strStyle);
        Page.Header.Controls.Add(lic);
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
        #endregion

        //全域網址參數
        strType = Request.QueryString["type"];

        //第一次進入
        if (!IsPostBack)
        {
            if (strType == "addresslist")
            {
                //檢查是否有會員地址資訊
                if (BLL.CheckMemberAddress(df.PersonalMemberID.Value))
                {
                    SetAddressInfo();
                    palPayment.Visible = false; //隱藏付款區塊
                }
                else
                {
                    df.RedirectPageUrl = "~/WebPage/Member/OrderInfo.aspx?type=addresslist";
                    df.BackPageUrl = "~/WebPage/Member/MyAccount.aspx";
                    Response.Redirect("~/WebPage/Member/Address.aspx?type=add");
                }

                //按鈕區相關設定
                hyCancel.NavigateUrl = "~/WebPage/Member/MyAccount.aspx";
                linkSubmit.Visible = false;
            }
            else
            {
                //檢查是否有會員地址資訊
                if (BLL.CheckMemberAddress(df.PersonalMemberID.Value))
                {
                    SetAddressInfo();
                    DataBind();
                    SetPaymentInfo();
                }
                else
                {
                    df.RedirectPageUrl = "~/WebPage/Member/OrderInfo.aspx";
                    df.BackPageUrl = "~/WebPage/Member/IceBucket.aspx";
                    Response.Redirect("~/WebPage/Member/Address.aspx?type=add");
                }

                //預設Enter按鈕 & 預設焦點
                Page.Form.Attributes.Add("onkeydown", "changeFocusControl('" + linkSubmit.ClientID + "', event)");

                //按鈕區相關設定
                linkAddressOK.Visible = false;
            }
        }
    }

    public override void DataBind()
    {
        //填入月份
        ddlPaymentMonth.Items.Add(new ListItem("--select month--", ""));
        for (int iMonth = 1; iMonth <= 12; iMonth++)
            ddlPaymentMonth.Items.Add(new ListItem(iMonth.ToString(), iMonth.ToString()));

        //填入年份
        int iToYear = DateTime.Now.Year;
        ddlPaymentYear.Items.Add(new ListItem("--select year--", ""));
        for (int iyear = iToYear; iyear <= (iToYear + 10); iyear++)
            ddlPaymentYear.Items.Add(new ListItem(iyear.ToString(), iyear.ToString()));

        //設定下拉選單
        ddlCreditCardType.DataSource = BLL.GetSystemParams("Credit Card");
        ddlCreditCardType.DataBind();
        ddlCreditCardType.Items.Insert(0, new ListItem("--select card type--", ""));
    }

    //設定地址資訊
    private void SetAddressInfo()
    {
        //循序讀取地址資訊
        DataTable dtAddressInfo = BLL.GetMemberAddress(df.PersonalMemberID.Value);
        repAddress.DataSource = dtAddressInfo;
        repAddress.DataBind();
    }

    //設定付款資訊
    private void SetPaymentInfo()
    {
        Payment pay = df.MyPayment;
        
        if (pay.PaymentType == MyPaymentType.PO)
        {
            radioPO.Checked = true;
            txtPurchaserName.Text = string.Format("{0}", pay.POPurchaserName);
            txtPONumber.Text = string.Format("{0}", pay.PONumber);
            txtPhone.Text = string.Format("{0}", pay.POPhone);
        }
        else
        {
            radioCard.Checked = true;
            txtCardHolderName.Text = pay.CardHolderName;
            ddlCreditCardType.SelectedValue = pay.CreditCardType;

            //若有卡號才填入
            if (!string.IsNullOrEmpty(pay.CreditCardNumber))
            {
                txtPaymentCard1.Text = pay.CreditCardNumber.Substring(0, 4);
                txtPaymentCard2.Text = pay.CreditCardNumber.Substring(4, 4);
                txtPaymentCard3.Text = pay.CreditCardNumber.Substring(8, 4);
                txtPaymentCard4.Text = pay.CreditCardNumber.Substring(12, 4);
            }

            ddlPaymentMonth.SelectedValue = string.Format("{0}", pay.ExpiryMonth);
            ddlPaymentYear.SelectedValue = string.Format("{0}", pay.ExpiryYear);
            txtPaymentSecurityID.Text = pay.SecurityID;
        }
    }

    //地址資料列繫結
    protected void repAddress_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;


            //取得控制項
            Label lblAttention = (Label)e.Item.FindControl("lblAttention");
            Label lblInstitution = (Label)e.Item.FindControl("lblInstitution");
            Label lblAddress = (Label)e.Item.FindControl("lblAddress");
            Label lblPhone = (Label)e.Item.FindControl("lblPhone");
            Label lblExt = (Label)e.Item.FindControl("lblExt");
            Label lblFax = (Label)e.Item.FindControl("lblFax");
            Label lblEmail = (Label)e.Item.FindControl("lblEmail");
            LinkButton btnModify = (LinkButton)e.Item.FindControl("btnModify");
            LinkButton btnDelete = (LinkButton)e.Item.FindControl("btnDelete");
            CheckBox cbBilling = (CheckBox)e.Item.FindControl("cbBilling");
            CheckBox cbShipping = (CheckBox)e.Item.FindControl("cbShipping");


            //設定控制項值
            lblAttention.Text = rowView["Attention"].ToString();
            lblInstitution.Text = rowView["Institution"].ToString();
            lblAddress.Text = string.Format("{0} {1} {2} {3} {4} {5}", rowView["Address1"], rowView["Address2"], rowView["City"], rowView["State"], rowView["Zip"], rowView["CountryName"]);
            lblPhone.Text = rowView["Phone"].ToString();
            lblExt.Text = rowView["Ext"].ToString();
            lblFax.Text = rowView["Fax"].ToString();
            lblEmail.Text = rowView["Email"].ToString();

            //設定CheckBox (Billing & Shipping)
            if (rowView["IsBilling"].ToString() == "True")
                cbBilling.Checked = true;
            if (rowView["IsShipping"].ToString() == "True")
                cbShipping.Checked = true;

            btnModify.CommandArgument = rowView["AddressID"].ToString();
            btnDelete.CommandArgument = rowView["AddressID"].ToString();
            btnDelete.Attributes.Add("onclick", "return confirm('Delete this address?')");
        }
    }

    //新增地址動作
    protected void btnCreateAddress_Click(object sender, EventArgs e)
    {
        if (strType == "addresslist")
        {
            df.RedirectPageUrl = "~/WebPage/Member/OrderInfo.aspx?type=addresslist";
            df.BackPageUrl = "~/WebPage/Member/OrderInfo.aspx?type=addresslist";
        }
        else
        {
            df.RedirectPageUrl = "~/WebPage/Member/OrderInfo.aspx";
            df.BackPageUrl = "OrderInfo.aspx";
        }

        Response.Redirect("Address.aspx?type=add");
    }

    //修改地址動作
    protected void btnModify_Click(object sender, EventArgs e)
    {
        LinkButton btnModify = (LinkButton)sender;
        string strAddressID = btnModify.CommandArgument;

        if (strType == "addresslist")
        {
            df.RedirectPageUrl = "~/WebPage/Member/OrderInfo.aspx?type=addresslist";
            df.BackPageUrl = "~/WebPage/Member/OrderInfo.aspx?type=addresslist";
        }
        else
        {
            df.RedirectPageUrl = "~/WebPage/Member/OrderInfo.aspx";
            df.BackPageUrl = "OrderInfo.aspx";
        }

        Response.Redirect("Address.aspx?type=edit&id=" + strAddressID);
    }

    //刪除地址動作
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        //取得AddressID
        LinkButton btnModify = (LinkButton)sender;
        int iAddressID = int.Parse(btnModify.CommandArgument);


        //參數集合
        Hashtable htParams = new Hashtable();
        htParams.Add("MemberID", df.PersonalMemberID.Value);
        htParams.Add("AddressID", iAddressID);
        htParams.Add("ActiveType", "del");


        //呼叫邏輯層
        bool bResult = false;
        string strMessage;
        BLL.InsertMemberAddress(out bResult, out strMessage, htParams);

        SetAddressInfo();

    }

    //設定地址資訊
    protected void linkAddressOK_Click(object sender, EventArgs e)
    {
        Payment pay = df.MyPayment;

        //循序讀取地址資訊
        foreach (RepeaterItem ri in repAddress.Items)
        {
            //讀取控制項
            CheckBox cbBilling = (CheckBox)ri.FindControl("cbBilling");
            CheckBox cbShipping = (CheckBox)ri.FindControl("cbShipping");
            HiddenField hiddenAddressID = (HiddenField)ri.FindControl("hiddenAddressID");

            //設定選取的地址資訊
            if (cbBilling.Checked) { pay.BillingAddressID = int.Parse(hiddenAddressID.Value); }
            if (cbShipping.Checked) { pay.ShippingAddressID = int.Parse(hiddenAddressID.Value); }
        }
        BLL.UpdateAddressType(df.PersonalMemberID.Value, pay.BillingAddressID, pay.ShippingAddressID);

        if (sender != null)
        {
            //判斷觸發事件來源是否為linkAddressOK按鈕
            LinkButton linkbtn = (LinkButton)sender;
            if (linkbtn.ID == "linkAddressOK")
            {
                Response.Redirect("~/WebPage/Member/MyAccount.aspx"); //導回MyAccount頁面
            }
        }
    }

    //Next按鈕-確認購物內容-金額
    protected void linkSubmit_Click(object sender, EventArgs e)
    {
        df.MyPayment = null; //清空訂單記錄
        Payment pay = df.MyPayment;

        linkAddressOK_Click(sender, e); //設定地址資訊

        if (radioPO.Checked)
        {
            //錯誤訊息
            if (pay.BillingAddressID == null || pay.ShippingAddressID == null) AddMessage("Billing OR Shipping Address is Required!");
            if (txtPurchaserName.Text == string.Empty) AddMessage("Purchaser Name is required!");
            if (txtPONumber.Text == string.Empty) AddMessage("PO Number is required!");
            if (txtPhone.Text == string.Empty) AddMessage("Phone is required!");

            //若無錯誤訊息
            if (lblMessage.Text == string.Empty)
            {
                //建立付款資訊
                pay.PaymentType = MyPaymentType.PO;
                pay.POPurchaserName = txtPurchaserName.Text.Trim();
                pay.PONumber = txtPONumber.Text.Trim();
                pay.POPhone = txtPhone.Text.Trim();

                SetPaymentTax(pay);
                Response.Redirect("OrderReview.aspx");
            }
        }
        else if (radioCard.Checked)
        {
            //變數宣告
            string strCardNumber = (txtPaymentCard1.Text + txtPaymentCard2.Text + txtPaymentCard3.Text + txtPaymentCard4.Text);

            //錯誤訊息
            if (pay.BillingAddressID == null || pay.ShippingAddressID == null) AddMessage("Billing OR Shipping Address is Required!");
            if (txtCardHolderName.Text.Trim() == "") AddMessage("CardHolder Name is required!");
            if (ddlCreditCardType.SelectedItem.Value == "") AddMessage("Credit Card Type is required!");
            //if (strCardNumber.Length < 16) AddMessage("Credit Card Number is required!");
            if (ddlPaymentMonth.SelectedItem.Value == "" || ddlPaymentYear.SelectedItem.Value == "") AddMessage("Expiration Date is required!");
            if (txtPaymentSecurityID.Text.Trim() == "") AddMessage("Security ID is required!");

            //若無錯誤訊息
            if (lblMessage.Text == string.Empty)
            {
                //建立付款資訊
                pay.PaymentType = MyPaymentType.CreditCard;
                pay.CardHolderName = txtCardHolderName.Text.Trim();
                pay.CreditCardType = ddlCreditCardType.SelectedItem.Value;
                pay.CreditCardNumber = strCardNumber;
                pay.ExpiryMonth = int.Parse(ddlPaymentMonth.SelectedItem.Value);
                pay.ExpiryYear = int.Parse(ddlPaymentYear.SelectedItem.Value);
                pay.SecurityID = txtPaymentSecurityID.Text.Trim();

                SetPaymentTax(pay);
                Response.Redirect("OrderReview.aspx");
            }
        }
    }

    //增加訊息
    private void AddMessage(string strMessage)
    {
        lblMessage.Text += strMessage + "<br/>";
    }

    //暫存金額相關
    private void SetPaymentTax(Payment pay)
    {
        //變數宣告
        string strProductIDArray = "", CountryCode = "", StateCode = "";
        int isLocal = 0, isDryIce = 0;

        pay.OrderDate = DateTime.Now.ToUniversalTime(); //設定訂單日期(UTC)

        //設定產品總價
        foreach (ShoppingCart sc in df.ShoppingCartList)
        {
            strProductIDArray += string.Format(",{0}", sc.CatNo); //串接CatNo陣列
            pay.ProductTotal += sc.TotalPrice.Value;
        }

        //呼叫邏輯層(取得計算金額相關資料)
        Hashtable htParams = BLL.GetPaymentInfo(pay.BillingAddressID.Value, pay.ShippingAddressID.Value, strProductIDArray.Trim(','));

        //設定回傳變數
        pay.TaxRate = decimal.Parse(htParams["TaxRate"].ToString());
        CountryCode = htParams["CountryCode"].ToString();
        StateCode = htParams["StateCode"].ToString().ToUpper();
        isLocal = int.Parse(htParams["IsLocal"].ToString());
        isDryIce = int.Parse(htParams["IsDryIce"].ToString());


        //計算運費及處理費
        if (CountryCode == "US" && StateCode == "CA" && isLocal == 1)
        {
            pay.ShippingPrice = 20;
            pay.HandlingPrice = 17;
        }
        else if (CountryCode == "US" && isLocal == 0)
        {
            pay.ShippingPrice = 28;
            pay.HandlingPrice = 17;
        }
        else if (CountryCode == "CA")
        {
            pay.ShippingPrice = 40;
            pay.HandlingPrice = 25;
        }
        else if (CountryCode != "US" && CountryCode != "CA")
        {
            pay.ShippingPrice = 75;
            pay.HandlingPrice = 25;
        }

        //乾冰費
        if (isDryIce == 1)
            pay.DryIceCharge = 25;

        //稅金
        pay.TaxRate *= pay.ProductTotal;

        //訂單總價
        pay.TotalPrice = pay.ProductTotal + pay.TaxRate + pay.ShippingPrice + pay.HandlingPrice + pay.DryIceCharge;
    }
}