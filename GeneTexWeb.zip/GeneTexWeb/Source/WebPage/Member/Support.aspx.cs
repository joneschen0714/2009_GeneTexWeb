﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Member;
using df = Icon.Definition;
using System.Globalization;

public partial class WebPage_Member_Support : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
        //string strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //設定語系
        div_CultureInfo.InnerHtml = Resources.Public.Support_Info;
        lblUserName.Text = Resources.Public.Support_From;
        lblSenderEmail.Text = Resources.Public.Support_Respond;
        lblCatNo.Text = Resources.Public.Support_CatNo;
        lblExperiment.Text = Resources.Public.Support_Experiment;
        lblDescription.Text = Resources.Public.Support_Description;
        btnSubmit.Text = Resources.Public.Support_Submit;
		rev_txtEmail.ErrorMessage = Resources.ErrMsg.EmailFormatErr;

        DataTable dt = BLL.GetForum(Resources.Web.sitemap.SubMenu_TechnicalSupport_Title);
        foreach (DataRow dr in dt.Rows)
        {
            cblistExperiment.Items.Add(new ListItem(dr["Name"].ToString(), dr["ForumID"].ToString()));
        }

        MemberInfo mi = df.OnlineMemberInfoList[df.PersonalMemberID];
        txtUserName.Text = mi.Account;
        txtSenderEmail.Text = mi.Email;

        txtDescription.TextMode = TextBoxMode.MultiLine;

        //Enter移動焦點
        txtUserName.Attributes.Add("onkeydown", "return changeFocusControl('" + txtSenderEmail.ClientID + "',event)");
        txtSenderEmail.Attributes.Add("onkeydown", "return changeFocusControl('" + txtCatNo.ClientID + "',event)");
        txtCatNo.Attributes.Add("onkeydown", "DoEnterAction(event, false)");

        //預設焦點
        Page.Form.DefaultFocus = txtUserName.ClientID;
    }

    //送出
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
		btnSubmit.Enabled = false;
        //參數集合
        string strForumID = "0";
		string strManager = ConfigurationManager.AppSettings["SupportEmail"].ToString();
        string strExperiment = GetExperiment(ref strForumID);

        Hashtable htParams = new Hashtable();
        htParams.Add("UserName", txtUserName.Text);
        htParams.Add("SenderEmail", txtSenderEmail.Text);
        htParams.Add("CatNo", txtCatNo.Text);
        htParams.Add("Experiment", strExperiment);
        htParams.Add("Content", txtDescription.Text);
		htParams.Add("Receiver", strManager);

        //呼叫邏輯層
        bool bResult = false;
        string strMessage = "";

		if (txtCatNo.Text.Trim() != "")
			strExperiment = txtCatNo.Text + ", " + strExperiment.Replace(';', ',');
		string strEmail = txtSenderEmail.Text.Trim();
		string strRoot = "GeneTexForum";
		string strXml = string.Format("<{0}>", strRoot);
		strXml += BLL.AddXmlNode("Email", strEmail);
		strXml += BLL.AddXmlNode("Subject", strExperiment + " Inquiry");
		strXml += BLL.AddXmlNode("Content", txtDescription.Text);
		strXml += BLL.AddXmlNode("ForumID", strForumID); //增加到論壇主題
		strXml += BLL.AddXmlNode("IP", Request.UserHostAddress);
		strXml += BLL.AddXmlNode("CatNo", txtCatNo.Text);
		strXml += BLL.AddXmlNode("Manager", strManager);

		BLL.SendInfoToForum(strXml, strRoot, strEmail, ref strMessage, ref bResult);

        if (bResult)
        {
			BLL.InsertSupport(ref bResult, ref strMessage, htParams);
        }
        //若執行成功
        if (bResult)
            Page.RegisterClientScriptBlock("New", "<script>alert('" + Resources.ErrMsg.MailSuccess + "');location.href='" + Request.Url + "';</script>");
        else
            Page.RegisterClientScriptBlock("New", "<script>alert('" + Resources.ErrMsg.MailFailure + "');location.href='" + Request.Url + "';</script>");
    }

    private string GetExperiment(ref string strForumID)
    {
        string strExperiment = "";
        foreach (ListItem li in cblistExperiment.Items)
        {
            if (li.Selected == true)
            {
                strExperiment += li.Text;

                if (li.Text == "Other" && txtOther.Text != "")
                    strExperiment += " : " + txtOther.Text;
                else
                    strExperiment += ";";

                if (strForumID == "0")
                    strForumID = li.Value;
            }
            
        }
        strExperiment = strExperiment.TrimEnd(';');
        if (strExperiment == "")
        {
            strExperiment = "Other";
            strForumID = cblistExperiment.Items[5].Value; //Other
        }
        return strExperiment;
    }
}
