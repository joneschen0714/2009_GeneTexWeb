﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using com.paypal.sdk.services;
using com.paypal.sdk.core;
using com.paypal.sdk.core.nvp;
using com.paypal.sdk.profiles;
using com.paypal.sdk.util;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_OrderReview : MemberPageBase
{

    protected void Page_Load(object sender, EventArgs e)
    {
        //註冊頁面Css
        string strStyle = "<style type='text/css'>" +
                            "#tbCartItem th { text-align:left; }" +
                            "#tbAddress th { text-align:left; }" +
                          "</style>";
        Page.Header.Controls.Add(new LiteralControl(strStyle));


        //第一次進入
        if (!IsPostBack)
        {    
            DataBind();
        }
    }

    public override void DataBind()
    {
        btnSubmit.Attributes.Add("onclick", "return confirm('Selecting OK will submit this order')");

        //購物資料繫結
        repPurchaseItems.DataSource = df.ShoppingCartList;
        repPurchaseItems.DataBind();


        //計算與設定金額
        lblSubTotal.Text = Setting.GetCurrencyFormat("$", df.MyPayment.ProductTotal, 2);
        lblTaxRate.Text = Setting.GetCurrencyFormat("$", df.MyPayment.TaxRate, 2);
        lblShipping.Text = Setting.GetCurrencyFormat("$", df.MyPayment.ShippingPrice, 2);
        lblHandling.Text = Setting.GetCurrencyFormat("$", df.MyPayment.HandlingPrice, 2);
        lblDryIce.Text = Setting.GetCurrencyFormat("$", df.MyPayment.DryIceCharge, 2);
        lblTotal.Text = Setting.GetCurrencyFormat("$", df.MyPayment.TotalPrice, 2);

        //設定地址與付款資訊
        DataTable dtAddress = BLL.GetMemberAddress(df.PersonalMemberID.Value);
        DataRow rowBilling = dtAddress.Select("IsBilling=1")[0];
        DataRow rowShipping = dtAddress.Select("IsShipping=1")[0];
        SetAddressInfo(rowBilling, divBillTo);
        SetAddressInfo(rowShipping, divShippTo);

        //設定訂單 & 付款相關資訊
        //DataRow rowPaymentInfo = BLL.GetPaymentInfo(df.PersonalMemberID.Value);
        SetPaymentInfo(df.MyPayment, divPaymentInfo);
    }

    //繫結資料列
    protected void repPurchaseItems_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            //變數宣告
            ShoppingCart sc = (ShoppingCart)e.Item.DataItem;
            string strGeneID = (sc.GeneID.HasValue ? sc.GeneID.Value.ToString() : "");
            string strCatalogItemID = (sc.CatalogItemID.HasValue ? sc.CatalogItemID.Value.ToString() : "");

            //取得控制項
            Label lblNo = (Label)e.Item.FindControl("lblNo");
            Label lblQty = (Label)e.Item.FindControl("lblQty");
            Label lblCatNo = (Label)e.Item.FindControl("lblCatNo");
            Label lblPrice = (Label)e.Item.FindControl("lblPrice");
            Label lblExtPrice = (Label)e.Item.FindControl("lblExtPrice");
            Label lblCampaign = (Label)e.Item.FindControl("lblCampaignCode");
            HyperLink linkProdcut = (HyperLink)e.Item.FindControl("linkProdcut");

            //設定控制項值
            lblNo.Text = Convert.ToString(e.Item.ItemIndex + 1);
            lblQty.Text = sc.Quantity.Value.ToString();
            lblCatNo.Text = sc.CatNo;
            lblPrice.Text = Setting.GetCurrencyFormat("$", sc.UnitPrice.Value, 2);
            lblExtPrice.Text = Setting.GetCurrencyFormat("$", sc.TotalPrice.Value, 2);
            lblCampaign.Text = sc.CampaignCode ?? "";
            linkProdcut.Text = sc.ProductName;
            linkProdcut.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + strCatalogItemID;
            if (sc.CampaignID != null) { 
                linkProdcut.NavigateUrl += "&CampaignID=" + sc.CampaignID; 
            }

            //Kit
            string strKitTB = "";
            DataTable dtKit = BLL.GetProductKitData(sc.CatNo);
            if (dtKit != null && dtKit.Rows.Count > 0)
            {
                strKitTB = "</td>";//結束一行，開新的一行
                sc.IsKit = true;
             
                int iKitCount = 0;
                foreach (DataRow dr in dtKit.Rows)
                {
                    iKitCount++;
                    SetKitInfo(dr, iKitCount, e.Item.ItemIndex + 1, sc.Quantity, ref strKitTB);
                }
            }
            else
                sc.IsKit = false;

            lblCampaign.Text += strKitTB;
            dtKit.Dispose();
        }
    }

    //設定Kit相關資訊
    private void SetKitInfo(DataRow rowKit, int iKitCount, int iParent, int? iQty, ref string strKitTB)
    {
        strKitTB += string.Format("<tr><td>{0}-{1}</td><td>{2}</td><td><a onclick=\"fn_WindowOpen('{3}{2}', 'PrintView', 850, 700); return false;\">{4}</a></td><td>$ {5}</td><td>{6}</td><td>$ {5}</td><td></td></tr>",
                                                    iParent, iKitCount, rowKit["CatNo"], ResolveUrl("~/WebPage/Product/PrintProduct.aspx?CatNo="), rowKit["ProductName"], 0, iQty);
    }

    //設定地址相關資訊
    private void SetAddressInfo(DataRow rowAddress, HtmlGenericControl DivControl)
    {
        //設定地址資訊
        DivControl.InnerHtml = string.Format("attn:{0}<br/>", rowAddress["Attention"]) +
                               string.Format("{0}<br/>", rowAddress["Address1"]) +
                               string.Format("{0}, {1} {2}<br/>", rowAddress["City"], rowAddress["State"], rowAddress["Zip"]) +
                               string.Format("{0}<br/>", rowAddress["CountryName"]);
    }

    //設定付款相關
    private void SetPaymentInfo(Payment pay, HtmlGenericControl DivControl)
    {
        //PO
        if (pay.PaymentType == MyPaymentType.PO)
        {
            //設定地址資訊
            DivControl.InnerHtml = string.Format("{0}<br/>", "PO") +
                                   string.Format("{0}<br/>", pay.POPurchaserName) +
                                   string.Format("{0}<br/>", pay.PONumber) +
                                   string.Format("{0}<br/>", pay.POPhone);
        }

        //CreditCard
        else if (pay.PaymentType == MyPaymentType.CreditCard)
        {
            //設定地址資訊
            DivControl.InnerHtml = string.Format("{0}<br/>", "Credit Card") +
                                   string.Format("{0}", pay.CardHolderName) +
                                   string.Format("{0}<br/>", pay.CreditCardType) +
                                   string.Format("xxxxxxxxxxxx{0}<br/>", pay.CreditCardNumber.Substring(12)) +
                                   string.Format("{0}/{1}<br/>", pay.ExpiryMonth, pay.ExpiryYear) +
                                   string.Format("Security ID: {0}<br/>", pay.SecurityID);
        }
    }

    //送出按鈕動作
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //宣告變數
        bool bResult = true;
        string strMessage = "", strTransID = "", strOrderID;
        Payment pay = df.MyPayment;

        //若有購物資料
        if (df.ShoppingCartList.Count > 0)
        {
            #region 寫入PayPal

            //呼叫邏輯層(取得地址資訊)
            DataTable dtAddress = BLL.GetMemberAddress(df.PersonalMemberID.Value);
            DataRow rowBilling = dtAddress.Select("IsBilling=1")[0];
            DataRow rowShipping = dtAddress.Select("IsShipping=1")[0];

            //若為信用卡付款，則呼叫PayPal副程式
            if (pay.PaymentType == MyPaymentType.CreditCard)
            {
                int iInvoiceNo = BLL.GetMaxInvoiceID() + 1; //最大訂單ID+1
                DoDirectPayment(ref bResult, ref strMessage, ref strTransID, iInvoiceNo, pay, rowBilling, rowShipping); //呼叫PayPal寫入訂單
            }

            #endregion

            //若寫入PayPal成功
            if (bResult)
            {
                #region 寫入訂單至資料庫

                //寫入訂單 - 資料參數
                Hashtable htParams = new Hashtable();
                htParams.Add("MemberID", df.PersonalMemberID.Value);
                htParams.Add("OrderType", pay.PaymentType);
                htParams.Add("OrderDate", pay.OrderDate);
                htParams.Add("PurchaserName", pay.POPurchaserName);
                htParams.Add("PONumber", pay.PONumber);
                htParams.Add("Phone", pay.POPhone);
                htParams.Add("CardType", pay.CreditCardType);
                htParams.Add("CardHolderName", pay.CardHolderName);
                htParams.Add("CardNumber", pay.CreditCardNumber);
                htParams.Add("ExpiryMonth", pay.ExpiryMonth);
                htParams.Add("ExpiryYear", pay.ExpiryYear);
                htParams.Add("SecurityID", pay.SecurityID);
                htParams.Add("GoodsPrice", pay.ProductTotal);
                htParams.Add("TaxRate", pay.TaxRate);
                htParams.Add("HandlingPrice", pay.HandlingPrice);
                htParams.Add("ShippingPrice", pay.ShippingPrice);
                htParams.Add("DryIcePrice", pay.DryIceCharge);
                htParams.Add("TotalPrice", pay.TotalPrice);
                htParams.Add("isConfirm", false);
                htParams.Add("TransactionID", strTransID);
                htParams.Add("Comments", txtComments.Text.Trim());
                htParams.Add("Type", "O");

                //呼叫邏輯層 (寫入訂單)
                BLL.InsertOrderInfo(out bResult, out strMessage, out strOrderID, htParams, df.ShoppingCartList);

                #endregion

                //若訂單寫入資料庫成功
                if (bResult)
                {
                    #region Mail通知 - 回覆使用者

                    htParams.Clear();
                    MemberInfo mi = df.OnlineMemberInfoList[df.PersonalMemberID];
                    htParams.Add("GoodsPrice", Setting.GetCurrencyFormat("$", pay.ProductTotal, 2));
                    htParams.Add("TaxRate", Setting.GetCurrencyFormat("$", pay.TaxRate, 2));
                    htParams.Add("HandlingPrice", Setting.GetCurrencyFormat("$", pay.HandlingPrice, 2));
                    htParams.Add("ShippingPrice", Setting.GetCurrencyFormat("$", pay.ShippingPrice, 2));
                    htParams.Add("TotalPrice", Setting.GetCurrencyFormat("$", pay.TotalPrice, 2));
                    htParams.Add("DryIcePrice", Setting.GetCurrencyFormat("$", pay.DryIceCharge, 2));

                    htParams.Add("{date}", String.Format("{0:MM/dd/yyyy}", pay.OrderDate));

                    //Send Mail to 訂購者yunyu
                    htParams.Add("{sh_attention}", rowShipping["Attention"].ToString());
                    htParams.Add("{sh_address}", rowShipping["Address1"].ToString() + " " + rowShipping["Address2"].ToString());
                    htParams.Add("{sh_city}", rowShipping["City"].ToString() + ", " + rowShipping["State"].ToString());
                    htParams.Add("{sh_country}", rowShipping["Country"].ToString());
                    htParams.Add("{ordernum}", pay.PONumber);
                    htParams.Add("{orderconfirmnum}", strOrderID);
                    htParams.Add("{name}", mi.FirstName + " " + mi.LastName);

                    BLL.GetProductTable(htParams, df.ShoppingCartList);
                    BLL.SendOrderMail(htParams, mi.Email, ref strMessage, ref bResult, false);

                    #endregion

                    #region Mail通知 - 回覆管理者

                    //寄給管理者	
                    htParams.Add("{account}", "weborder");

                    htParams.Add("{email}", mi.Email);
                    htParams.Add("{phone}", "");
                    htParams.Add("{fax}", "");

                    htParams.Add("{bi_attention}", rowBilling["Attention"].ToString());
                    htParams.Add("{bi_company}", rowBilling["Institution"].ToString());
                    htParams.Add("{bi_address}", rowBilling["Address1"].ToString() + " " + rowBilling["Address2"].ToString());
                    htParams.Add("{bi_city}", rowBilling["City"].ToString() + ", " + rowBilling["State"].ToString());
                    htParams.Add("{bi_country}", rowBilling["Country"].ToString());
                    htParams.Add("{bi_zip}", rowBilling["Zip"].ToString());
                    htParams.Add("{bi_phone}", rowBilling["Phone"].ToString());

                    htParams.Add("{sh_zip}", rowShipping["Zip"].ToString());
                    htParams.Add("{sh_phone}", rowShipping["Phone"].ToString());
                    htParams.Add("{sh_company}", rowShipping["Institution"].ToString());

                    htParams.Add("{pay_name}", pay.CardHolderName);
                    htParams.Add("{pay_option}", pay.CreditCardType);
                    htParams.Add("{pay_cardnum}", pay.CreditCardNumber);
                    htParams.Add("{pay_exdate}", pay.ExpiryMonth + "/" + pay.ExpiryYear);
                    htParams.Add("{pay_security}", pay.SecurityID);
                    htParams.Add("{pay_transaction}", strTransID);

                    htParams.Add("{comment}", txtComments.Text.Trim());

                    string strManager = ConfigurationManager.AppSettings["OrderEmail"].ToString();
                    BLL.SendOrderMail(htParams, strManager, ref strMessage, ref bResult, true);

                    Session.Add("OrderConfirmNum", strOrderID); //紀錄訂單編號,做完問卷要寄給管理者
                    Session.Add("OrderDate", String.Format("{0:MM/dd/yyyy}", pay.OrderDate));
                    #endregion

                    //清除購物記錄
                    pay = null;
                    df.ShoppingCartList = null;
                    //清除Discount紀錄
                    df.CatalogDiscountList = null;

                    //導向訂單完成頁面
                    Response.Redirect("~/WebPage/Member/OrderResult.aspx");
                }
                else
                {
                    DeleteOrder(int.Parse(strOrderID)); //刪除訂單
                    lblMessage.Text = strMessage; //顯示訊息
                }
            }
            else
            {
                lblMessage.Text = strMessage; //顯示訊息
            }
        }
        else
        {
            lblMessage.Text = "Shopping Cart is null!"; //無購物資料
        }
    }

    //呼叫PayPal建立訂單函式
    protected void DoDirectPayment(ref bool bResult, ref string strMessage, ref string strTransID, int iInvoiceNo, Payment pay, DataRow rowBilling, DataRow rowShipping)
    {
        //設定收款相關資訊
        IAPIProfile profile = ProfileFactory.createSignatureAPIProfile();
        profile.APIUsername = ConfigurationSettings.AppSettings["PAYPAL_API_USERNAME"];
        profile.APIPassword = ConfigurationSettings.AppSettings["PAYPAL_API_PASSWORD"];
        profile.APISignature = ConfigurationSettings.AppSettings["PAYPAL_API_SIGNATURE"];
        profile.Environment = ConfigurationSettings.AppSettings["PAYPAL_ENVIRONMENT"];

        //TestConnection test = new TestConnection();
        //string result = test.testServerConnection(profile);
        //Response.Write("<hr />" + result + "<hr />");
        NVPCallerServices caller = new NVPCallerServices();
        caller.APIProfile = profile;
        NVPCodec encoder = new NVPCodec();

        //encoder["INVOICE"] = "123456";

        // test code
        encoder["METHOD"] = "DoDirectPayment";
        encoder["INVNUM"] = string.Format("{0}", iInvoiceNo);
        encoder["PAYMENTACTION"] = "Authorization"; //or "Sale"
        encoder["CREDITCARDTYPE"] = pay.CreditCardType;
        encoder["ACCT"] = pay.CreditCardNumber;
        encoder["EXPDATE"] = ChangeMMyyyyFormat(pay.ExpiryMonth.Value, pay.ExpiryYear.Value); //mmyyyy
        encoder["CVV2"] = pay.SecurityID;
        encoder["FIRSTNAME"] = string.Format("{0}", pay.CardHolderName);
        //encoder["LASTNAME"] = string.Format("{0}", rowBilling["LastName"]);
        encoder["STREET"] = string.Format("{0}", rowBilling["Address1"]);
        encoder["STREET2"] = string.Format("{0}", rowBilling["Address2"]);
        encoder["CITY"] = string.Format("{0}", rowBilling["City"]);
        encoder["STATE"] = string.Format("{0}", rowBilling["State"]);
        encoder["ZIP"] = string.Format("{0}", rowBilling["Zip"]);
        encoder["COUNTRYCODE"] = string.Format("{0}", rowBilling["Country"]);
        encoder["CURRENCYCODE"] = "USD";

        encoder["SHIPTONAME"] = string.Format("{0}", rowShipping["Attention"]);
        encoder["SHIPTOSTREET"] = string.Format("{0}", rowShipping["Address1"]);
        encoder["SHIPTOSTREET2"] = string.Format("{0}", rowShipping["Address2"]);
        encoder["SHIPTOCITY"] = string.Format("{0}", rowShipping["City"]);
        encoder["SHIPTOSTATE"] = string.Format("{0}", rowShipping["State"]);
        encoder["SHIPTOZIP"] = string.Format("{0}", rowShipping["Zip"]);
        encoder["SHIPTOCOUNTRYCODE"] = string.Format("{0}", rowShipping["Country"]);

        // transaction total
        encoder["AMT"] = Setting.GetCurrencyFormat("", pay.TotalPrice, 2);
        //encoder["ITEMAMT"] = Setting.GetCurrencyFormat("", pay.ProductTotal, 2);
        //encoder["SHIPPINGAMT"] = Setting.GetCurrencyFormat("", pay.ShippingPrice, 2);
        //encoder["INSURANCEAMT"] = Setting.GetCurrencyFormat("", pay.DryIceCharge, 2);
        //encoder["TAXAMT"] = Setting.GetCurrencyFormat("", pay.TaxRate, 2);
        //encoder["HANDLINGAMT"] = Setting.GetCurrencyFormat("", pay.HandlingPrice, 2);

        //// detail transaction
        //encoder["L_NUMBER0"] = "GTX001";
        //encoder["L_NAME0"] = "GTX Cat 001";
        //encoder["L_DESC0"] = "GTX001 + shipping + taxable";
        //encoder["L_QTY0"] = "2";
        //encoder["L_AMT0"] = "0.39";

        //encoder["L_NUMBER1"] = "GTX002";
        //encoder["L_NAME1"] = "GTX Cat 002";
        //encoder["L_DESC1"] = "GTX002 + shipping + taxable";
        //encoder["L_QTY1"] = "1";
        //encoder["L_AMT1"] = "0.3";

        string pStrrequestforNvp = encoder.Encode();
        string pStresponsenvp = caller.Call(pStrrequestforNvp);

        NVPCodec decoder = new NVPCodec();
        decoder.Decode(pStresponsenvp);

        string strAck = decoder["ACK"];
        if (strAck != null && (strAck == "Success" || strAck == "SuccessWithWarning"))
        {
            bResult = true;
            strTransID = decoder["TRANSACTIONID"];
            strMessage = "";
            //string pStrResQue = "TRANSACTIONID=" + decoder["TRANSACTIONID"] + "<br>" +
            //    "AMT=" + decoder["AMT"] + "<br>" +
            //    "AVSCODE=" + decoder["AVSCODE"] + "<br>" +
            //    "CVV2MATCH=" + decoder["CVV2MATCH"];
        }
        else
        {
            bResult = false;
            strMessage = decoder["L_LONGMESSAGE0"];
            //string pStrError = "ErrorCode=" + decoder["L_ERRORCODE0"] + "<br>" +
            //    "Desc=" + decoder["L_SHORTMESSAGE0"] + "<br>" +
            //    "Desc2=" + decoder["L_LONGMESSAGE0"];
        }
    }

    //從資料庫刪除訂單
    private void DeleteOrder(int iOrderID)
    {
        //資料參數 (刪除訂單)
        Hashtable htParams = new Hashtable();
        htParams.Add("ActionType", "DeleteOrder");
        htParams.Add("ThisOrderID", iOrderID);

        //呼叫邏輯層
        bool bResult;
        string strMessage;
        BLL.DeleteOrder(htParams);
    }


    /// <summary>轉換為MMyyyy格式</summary>
    private string ChangeMMyyyyFormat(object Month, object Year)
    {
        string strMonth = Month.ToString();
        string strYear = Year.ToString();

        strMonth = (strMonth.Length == 1 ? "0" + strMonth : strMonth);
        return strMonth + strYear;
    }
}