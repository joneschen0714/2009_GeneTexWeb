﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_OrderResult : MemberPageBase
{
	protected void Page_Load(object sender, EventArgs e)
	{
		//引用頁面Css & Script
		ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "WindowOpen", ResolveClientUrl("~/Js/fn_WindowOpen.js"));

		if (!IsPostBack)
		{
			string strURL = ResolveUrl(ConfigurationManager.AppSettings["SurveyURL"].ToString());
			string strModalDialog = string.Format("fn_openWindowDialog('{0}','{1}','{2}',800, 750); return false;", "", strURL, "Survey");
 
			btnSurvey.Attributes.Add("onclick", strModalDialog);

			divSurvey.Visible = (Session["OrderConfirmNum"] != null);
		}
	}


	protected void btnSendMsg_Click(object sender, EventArgs e)
	{
		//Session["OrderConfirmNum"] = "123";
		//Session["OrderDate"] = "2009/1/1";
		if (Session["OrderConfirmNum"] != null)
		{
			MemberInfo mi = df.OnlineMemberInfoList[df.PersonalMemberID];
			string strManager = ConfigurationManager.AppSettings["SurveyEmail"].ToString();

			string strURL = ConfigurationManager.AppSettings["SurveyURL"].ToString();
			int iStart = strURL.IndexOf('=') + 1;
			int iSurveyID = Convert.ToInt32(strURL.Substring(iStart));

			Hashtable htParams = new Hashtable();
			htParams.Add("UserID", mi.MemberID);
			htParams.Add("SurveyID", iSurveyID);
			htParams.Add("IP", Request.UserHostAddress);
			htParams.Add("Name", mi.FirstName + " " + mi.LastName);
			htParams.Add("Receiver", strManager);
			htParams.Add("SenderEmail", mi.Email);
			htParams.Add("OrderID", Session["OrderConfirmNum"]);
			htParams.Add("OrderDate", Session["OrderDate"]);

			bool bResult = false;
			string strMessage = "";

			BLL.InsertSurveyLog(ref bResult, ref strMessage, htParams);
			
			Session["OrderConfirmNum"] = null;
			Session.Remove("OrderDate");
			divSurvey.Visible = false;
		}
	}
}
