﻿using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_Login : System.Web.UI.Page
{
    private string strCulture;

    protected void Page_Init(object sender, EventArgs e)
    {
        string strType = Request.QueryString["type"] ?? "";

        //登出狀態
        if (strType == "logout")
        {
            //清除登入記錄
            MemberInfoCollection mic = df.OnlineMemberInfoList;
            mic.Remove(mic[df.PersonalMemberID]);
            df.PersonalMemberID = null;
            Session.Abandon(); //清除目前個人Session

            if (Request.Cookies["autologin"] != null)
            {
                HttpCookie Cookie = new HttpCookie("autologin");
                Cookie.Expires = DateTime.Now.AddDays(-2);
                Response.Cookies.Add(Cookie);
            }

            Response.Redirect("~/WebPage/Member/Login.aspx");
        }
        else if (strType == "register")
        {
            //帳號密碼參數
            Security sec = new Security();
            string strAccount = sec.DecryptQueryString(Request.QueryString["acct"]);
            string strPwd = sec.DecryptPassWord(Request.QueryString["pwd"]);

            //設定控制項值
            txtAccount.Text = strAccount;
            txtPassword.Text = strPwd;

            df.RedirectPageUrl = "~/Default.aspx"; //導向記錄的頁面
            btnSignIn_Click(new object(), new EventArgs()); //登入動作
        }
        else
        {
            //若已登入則導向個人會員頁面
            if (MemberInfo.CheckMemberLogin())
            {
                Response.Redirect("~/WebPage/Member/MyAccount.aspx");
            }

            //取得目前語系
            strCulture = CultureInfo.CurrentCulture.Name;

            SetDefaultValue();
        }
    }

    protected void SetDefaultValue()
    {
        //控制項顯示文字設定 & 相關設定
        lblAccount.Text = "Username *";
        lblPassword.Text = "Password *";
        lblAutomatically.Text = "Please log me in automatically on my next visit";
        lnkForgotPassword.Text = "Forgot Password";
        btnSignIn.Text = "Sign In";
        lnkForgotPassword.NavigateUrl = "~/WebPage/Member/ForgotPassword.aspx";

        //預設Enter按鈕 & 預設焦點
        Page.Form.Attributes.Add("onkeydown", "changeFocusControl('" + btnSignIn.ClientID + "', event)");
        Page.Form.DefaultFocus = txtAccount.ClientID;
    }

    //事件 - 登入按鈕
    protected void btnSignIn_Click(object sender, EventArgs e)
    {
        //設定變數
        string strAccount = txtAccount.Text.Trim();
        string strPassword = txtPassword.Text.Trim();

        //參數集合
        Hashtable htParams = new Hashtable();
        htParams.Add("Account", strAccount);
        htParams.Add("Password", strPassword);
        htParams.Add("Type", "");
        htParams.Add("Status", "Active");

        //呼叫邏輯層
        bool bResult;
        string strMessage;
        BLL.Member_Login(out bResult, out strMessage, htParams);

        //設定回傳狀態 & 訊息
        cvMessage.IsValid = bResult;
        cvMessage.ErrorMessage = strMessage;

        //若驗証成功
        Page.Validate();
        if (Page.IsValid && bResult)
        {
            //取得會員資料
            DataTable dtMemberInfo = BLL.GetMemberInfo(strAccount);
            DataRow rowMemberInfo = dtMemberInfo.Rows[0];

            //設定會員物件
            MemberInfo mi = MemberInfo.GetMemberInfo(rowMemberInfo);

            //判斷全域會員資料集合
            MemberInfoCollection mic = df.OnlineMemberInfoList;

            //若沒在線上會員，則移除會員物件
            if (mic[strAccount] != null)
                mic.Remove(mic[strAccount]);

            mic.Add(mi); //加入會員資料至集合

            df.PersonalMemberID = mi.MemberID; //記錄會員ID

            //寫入Member 加密的account和password Cookie
            if (Request.QueryString["autologin"] != null && Request.QueryString["autologin"] == "Y")
            {
                chkAutomatically.Checked = true;
            }
            if (chkAutomatically.Checked)
                AutoLogin(mi.Account, mi.Password);

            //若記錄的頁面不為Null
            if (df.RedirectPageUrl != null)
            {
                Response.Redirect(df.RedirectPageUrl); //導向記錄的頁面
            }
            else
            {
                Response.Redirect("MyAccount.aspx"); //導向會員登入預設頁面
            }
        }
        else
        {
            cvMessage.IsValid = false;
            if (Request.Cookies["autologin"] != null)
            {
                HttpCookie Cookie = new HttpCookie("autologin");
                Cookie.Expires = DateTime.Now.AddDays(-2);
                Response.Cookies.Add(Cookie);
            }

            bResult = BLL.CheckLoginMemberType(strAccount);

            //若發信成功
            if (bResult)
            {
                cvMessage.ErrorMessage = "Login Information already send mail to your mailbox.";
            }

            SetDefaultValue();
        }
    }

    protected void AutoLogin(string strAccount, string strPassword)
    {
        HttpCookie Cookie = new HttpCookie("autologin");
        Security sec = new Security();
        Cookie.Values.Add("account", sec.EncryptQueryString(strAccount));
        Cookie.Values.Add("password", sec.EncryptPassWord(strPassword));
        Cookie.Expires = DateTime.Now.AddDays(15);
        Response.Cookies.Add(Cookie);
    }
}
