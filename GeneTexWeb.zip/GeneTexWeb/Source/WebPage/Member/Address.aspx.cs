﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Member;
using df = Icon.Definition;

public partial class WebPage_Member_Address : MemberPageBase
{
	string strType = "";
	int iAddressID = 0;

	protected void Page_Load(object sender, EventArgs e)
	{
		//引用頁面Css檔 & JavaScript檔
		ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "WindowsDialog", ResolveUrl("~/Js/fn_WindowOpen.js"));
		string strStyle = "<style type='text/css'>" +
							"#tbAddress th { height:20px; width:130px; }" +
						  "</style>";
		Page.Header.Controls.Add(new LiteralControl(strStyle));

		//預設Enter按鈕
		Page.Form.DefaultButton = btnSubmit.UniqueID;

		//取得網址參數
		strType = Request.QueryString["type"];
		if (Request.QueryString["id"] != null) { iAddressID = int.Parse(Request.QueryString["id"]); }

		if (!IsPostBack)
		{
			//依參數執行動作
			switch (strType)
			{
				case "add":
					SetDefault();
					break;

				case "edit":
					SetDefault();
					FillMemberAddressInfo(iAddressID);
					break;
			}
		}
	}

	private void SetDefault()
	{
		//設定國家下拉選單
		DataTable dtCountry = BLL.GetCountry();
		dtCountry.DefaultView.RowFilter = "CountryCode<>'TW'";
		ddlCountry.DataSource = dtCountry.DefaultView.ToTable();
		ddlCountry.DataBind();

		ddlCountry.Items.Insert(0, new ListItem("--select country--", ""));
		dtCountry.Dispose();
	}

	//設定會員地址資訊
	private void FillMemberAddressInfo(int addressid)
	{
		//取得此地址資訊
		DataRow rowAddress = BLL.GetMemberSingleAddress(df.PersonalMemberID.Value, addressid);

		//設定地址相關欄位
		txtAttention.Text = rowAddress["Attention"].ToString();
		txtInstitution.Text = rowAddress["Institution"].ToString();
		txtAddress1.Text = rowAddress["Address1"].ToString();
		txtAddress2.Text = rowAddress["Address2"].ToString();

		txtCity.Text = rowAddress["City"].ToString();
		txtCounty.Text = rowAddress["County"].ToString();
		txtState.Text = rowAddress["State"].ToString();
		ddlCountry.SelectedValue = rowAddress["Country"].ToString();

		txtZip.Text = rowAddress["Zip"].ToString();
		txtPhone.Text = rowAddress["Phone"].ToString();
		txtPhoneExt.Text = rowAddress["Ext"].ToString();
		txtFax.Text = rowAddress["Fax"].ToString();
		txtEmail.Text = rowAddress["Email"].ToString();
	}

	//增加訊息
	private void AddMessage(string strMessage)
	{
		lblMessage.Text += strMessage + "<br/>";
	}

	//檢查資料正確性
	private bool CheckValueIsOk()
	{
		//宣告變數
		string strCountry = ddlCountry.SelectedValue;
		string strState = txtState.Text.Trim().ToUpper();
		string strCounty = txtCounty.Text.Trim();
		string strCity = txtCity.Text.Trim();

		//錯誤訊息
		if (txtAttention.Text == string.Empty) AddMessage("Attention is required!");
		if (txtAddress1.Text == string.Empty) AddMessage("Address1 is required!");
		if (strCity == string.Empty) AddMessage("City is required!");
		//if (strCounty == string.Empty) { AddMessage("County is required!"); }
		if (strState == string.Empty) { AddMessage("State is required!"); }
		if (strCountry == string.Empty) AddMessage("Country is required!");
		if (txtZip.Text == string.Empty) AddMessage("Zip is required!");
		if (txtPhone.Text == string.Empty) AddMessage("Phone is required!");
		if (txtEmail.Text == string.Empty) AddMessage("Email is required!");

		#region Address條件式驗証
		if (lblMessage.Text == string.Empty)
		{
			if (strCountry == "US")
			{
                if (strState == "CALIFORNIA") { txtState.Text = "CA"; strState = "CA"; } //若加州為全名，改為縮寫
				DataTable dtState = BLL.GetAddressInfo(strCountry, strState, null, null);
                if (dtState.Rows.Count > 0)
                {
                    if (strState == "CA")
                    {
                        dtState.DefaultView.RowFilter = string.Format("CityName='{0}'", strCity); //找出符合City的資料
                        dtState.DefaultView.Sort = "Tax DESC"; //取得最大的Tax資料
                        DataTable dtCity = dtState.DefaultView.ToTable();
                        if (dtCity.Rows.Count > 0)
                        {
                            txtCounty.Text = dtCity.Rows[0]["CountyName"].ToString(); //設定最大稅率的County
                        }
                        else
                        {
                            txtCounty.Text = "";

                            ////若State下無City，則顯示訊息
                            //AddMessage(string.Format("The city did not match, City {0} not recognized in {1}.", strCity, strState));
                        }
                    }
                }
                else
                {
                    //若US下無State，則顯示訊息
                    AddMessage(string.Format("The state did not match, State {0} not recognized in {1}.", strState, strCountry));
                }
            }
		}
		#endregion


		if (lblMessage.Text == string.Empty) { return true; }
		else { return false; }
	}

	//Submit按鈕事件
	protected void btnSubmit_Click(object sender, EventArgs e)
	{
		//檢查資料正確性
		if (CheckValueIsOk())
		{
			//參數集合
			Hashtable htParams = new Hashtable();
			htParams.Add("MemberID", df.PersonalMemberID.Value);
			htParams.Add("Attention", txtAttention.Text.Trim());
			htParams.Add("Institution", txtInstitution.Text.Trim());
			htParams.Add("Address1", txtAddress1.Text.Trim());
			htParams.Add("Address2", txtAddress2.Text.Trim());
			htParams.Add("City", txtCity.Text.Trim());
			htParams.Add("County", txtCounty.Text.Trim());
			htParams.Add("State", txtState.Text.Trim());
			htParams.Add("Zip", txtZip.Text.Trim());
			htParams.Add("Country", ddlCountry.SelectedItem.Value);
			htParams.Add("Phone", txtPhone.Text.Trim());
			htParams.Add("Ext", txtPhoneExt.Text.Trim());
			htParams.Add("Fax", txtFax.Text.Trim());
			htParams.Add("Email", txtEmail.Text.Trim());
			htParams.Add("AddressID", iAddressID);
			htParams.Add("ActiveType", strType);

			//呼叫邏輯層
			bool bResult = false;
			string strMessage;
			BLL.InsertMemberAddress(out bResult, out strMessage, htParams);

			//判斷執行結果
			if (bResult)
				Response.Redirect(df.RedirectPageUrl);
			else
				lblMessage.Text = strMessage;
		}
	}

	//Cancel動作
	protected void btnCancel_Click(object sender, EventArgs e)
	{
		Response.Redirect(df.BackPageUrl);
	}
}