﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class WebPage_Member_ForgotPassword : System.Web.UI.Page
{
    protected override void OnInit(EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Panel1.Visible = true;
            btnBack.Visible = false;
        }
    }

    //Next按鈕
    protected void btnNext_Click(object sender, ImageClickEventArgs e)
    {
        if (Panel1.Visible)
        {
            //設定變數
            string strEmail = txtEmail.Text.Trim();

            //參數集合
            Hashtable htParams = new Hashtable();
            htParams.Add("Email", strEmail);

            //呼叫邏輯層
            bool bResult;
            string strMessage;
            DataTable dtQuestions = BLL.GetPasswordQuestions(out bResult, out strMessage, htParams);

            //設定回傳狀態 & 訊息
            cvMessage.IsValid = bResult;
            cvMessage.ErrorMessage = strMessage;

            //若回傳成功狀態
            if (bResult)
            {
                //設定會員ID & 問題 & 答案
                DataRow rowQuestions = dtQuestions.Rows[0];
                MemberID = int.Parse(rowQuestions["MemberID"].ToString());
				MemberAccount = rowQuestions["Account"].ToString();
				MemberPassword = rowQuestions["Password"].ToString();
                lblQuestion1.Text = rowQuestions["Question"].ToString();
                QuestionAnswer = rowQuestions["Answer"].ToString();

                //切換顯示
                Panel1.Visible = false;
                Panel2.Visible = true;
                btnBack.Visible = true;
            }
        }
        else if (Panel2.Visible)
        {
            //判斷答案是否正確
            string strAnswer = txtAnswer1.Text.Trim();
            if (strAnswer.ToLower() == QuestionAnswer.ToLower())
            {
                Panel2.Visible = false;
                cvMessage.IsValid = true;
                Panel3.Visible = true;
				//顯示Account
				lblAccount.Text = MemberAccount;
            }
            else
            {
                //設定回傳狀態 & 訊息
                cvMessage.IsValid = false;
				//send a mail with the account and password
				Hashtable htParams = new Hashtable();
				htParams.Add("Account", MemberAccount);
				htParams.Add("Password", MemberPassword);
				htParams.Add("ToEmailAddress", txtEmail.Text.Trim());
				bool bResult = BLL.SendPasswordEmail(htParams);
				if (bResult)
					cvMessage.ErrorMessage = "There was an Invalid answer, and the mail has been sent with your account and password.";
                else
					cvMessage.ErrorMessage = "Invalid answer, please try again or call Tel: 1-210-677-8529 Toll-Free: 1-877-GENETEX ";
				htParams.Clear();
            }
        }
        else if (Panel3.Visible)
        {
            //資料參數
			Hashtable htParams = new Hashtable();
            htParams.Add("MemberID", MemberID);
            htParams.Add("NewPassword", txtNewPwd.Text.Trim());
            htParams.Add("ConfirmPassword", txtConfirmPwd.Text.Trim());

            //呼叫邏輯層
            bool bResult;
            string strMessage;
            BLL.ForgotChangePassword(out bResult, out strMessage, htParams);

            if (bResult)
            {
                cvMessage.IsValid = false;
                cvMessage.ErrorMessage = "Your password is changed, Please click <a href='login.aspx' class='a2'>here</a> to login.";
            }
            else
            {
                //設定回傳狀態 & 訊息
                cvMessage.IsValid = false;
                cvMessage.ErrorMessage = strMessage;
            }
        }
    }

    /// <summary>
    /// 設定與取得密碼提示
    /// </summary>
    private string QuestionAnswer
    {
        get { return ViewState["QuestionAnswer"].ToString(); }
        set { ViewState.Add("QuestionAnswer", value); }
    }

    /// <summary>
    /// 設定與取得會員ID
    /// </summary>
    private int MemberID
    {
        get { return int.Parse(ViewState["MemberID"].ToString()); }
        set { ViewState.Add("MemberID", value); }
    }

	/// <summary>
	/// 設定與取得會員Account
	/// </summary>
	private string MemberAccount
	{
		get { return ViewState["MemberAccount"].ToString(); }
		set { ViewState.Add("MemberAccount", value); }
	}

	/// <summary>
	/// 設定與取得會員Password
	/// </summary>
	private string MemberPassword
	{
		get { return ViewState["MemberPassword"].ToString(); }
		set { ViewState.Add("MemberPassword", value); }
	}
}
