﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon.DataBase;
using df = Icon.Definition;
using Icon;

public partial class WebPage_Public_ContactUs : System.Web.UI.Page
{
    DataBase db = new DataBase(Icon.Definition.WebConnStr);
    string strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系


    protected void Page_Init(object sender, EventArgs e)
    {
        //設定語系
        div_CultureInfo.InnerHtml = Resources.ContactUs.ContactUsInfo;
        lblUserName.Text = Resources.ContactUs.UserName;
        lblSubject.Text = Resources.ContactUs.Subject;
        lblEmail.Text = Resources.ContactUs.Email;
        lblContent.Text = Resources.ContactUs.Content;
        btnSubmit.Text = Resources.ContactUs.Submit;
        rev_txtEmail.ErrorMessage = Resources.ErrMsg.FormatError;


        //Enter移動焦點
        txtUserName.Attributes.Add("onkeydown", "return changeFocusControl('" + txtSubject.ClientID + "',event)");
        txtSubject.Attributes.Add("onkeydown", "return changeFocusControl('" + txtEmail.ClientID + "',event)");
        txtEmail.Attributes.Add("onkeydown", "return changeFocusControl('" + txtContent.ClientID + "',event)");

        //預設焦點
        Page.Form.DefaultFocus = txtUserName.ClientID;
    }


    protected void Page_Load(object sender, EventArgs e)
    {

    }


    //送出
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;

        bool bResult = false;
        int iForumID = (int)BLL.GetForumByOne(Resources.Web.sitemap.ContactUs_Title);

		string strManager = ConfigurationManager.AppSettings["ContactUsEmail"].ToString();
        string strMessage = "";
        string strEmail = txtEmail.Text.Trim();
        string strRoot = "GeneTexForum";
        string strXml = string.Format("<{0}>", strRoot);
        strXml += BLL.AddXmlNode("Email", strEmail);
        strXml += BLL.AddXmlNode("Subject", txtSubject.Text);
        strXml += BLL.AddXmlNode("Content", txtContent.Text);
        strXml += BLL.AddXmlNode("ForumID", iForumID.ToString()); //增加到論壇主題
		strXml += BLL.AddXmlNode("Manager", strManager);
        strXml += BLL.AddXmlNode("IP", Request.UserHostAddress);

        BLL.SendInfoToForum(strXml, strRoot, strEmail, ref strMessage, ref bResult);

		Hashtable htParams = new Hashtable();
		htParams.Add("UserName", txtUserName.Text);
		htParams.Add("Subject", txtSubject.Text);
		htParams.Add("Email", txtEmail.Text);
		htParams.Add("Content", txtContent.Text);
		htParams.Add("Receiver", strManager);
		BLL.InsertContactUs(ref bResult, ref strMessage, htParams);

        if (bResult)
            Page.RegisterClientScriptBlock("New", "<script>alert('" + Resources.ErrMsg.MailSuccess + "');location.href='" + Request.Url + "';</script>");
        else if (!bResult)
            Page.RegisterClientScriptBlock("New", "<script>alert('" + Resources.ErrMsg.MailFailure + "');location.href='" + Request.Url + "';</script>");

    }
}
