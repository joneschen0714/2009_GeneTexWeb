﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class WebPage_Public_Literature : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
        //string strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系

        //設定語系
        lblSearchCollection.Text = Resources.Public.Literature_Collection;
        lblSearchPubMed.Text = Resources.Public.Literature_PubMed;
        lblCueCollection.Text = Resources.Public.Literature_CueCollection;
        lblCuePubMed.Text = Resources.Public.Literature_CuePubMed;
        btnSearchCollection.Text = btnSearchPubMed.Text  = "Search";

        //預設Enter按鈕 & 預設焦點
        txtSearchCollection.Attributes.Add("onkeydown", "changeFocusControl('" + btnSearchCollection.ClientID + "', event)");
        txtSearchPubMed.Attributes.Add("onkeydown", "changeFocusControl('" + btnSearchPubMed.ClientID + "', event)");
        Page.Form.DefaultFocus = txtSearchCollection.ClientID;

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        btnSearchPubMed.Attributes.Add("onclick", "GoPubMedWeb();");
    }

    protected void btnSearchCollection_Click(object sender, EventArgs e)
    {
        string strTerm = txtSearchCollection.Text.Replace("'","''");
        string strUrl = "~/WebPage/Product/BrowseByParam.aspx?page=literature";
        Session.Add("LiteratureTerm",strTerm); //因為url不能傳遞兩個參數,改用session記值傳遞參數
        Response.Redirect(strUrl);
    }
}
