﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using df = Icon.Definition;

public partial class WebPage_Public_NewsDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string strType = Request.QueryString["Type"];
        string NewsID = Request.QueryString["NewsID"];

        //資料參數
        Hashtable htParams = new Hashtable();
        htParams.Add("Type", strType);
        htParams.Add("Enabled", 1);

        //呼叫邏輯層
        DataRow rowNews = BLL.GetNewsContent(htParams, NewsID);

        if (rowNews != null)
        {

            lblDate.Text = "Date:"+DateTime.Parse(rowNews["StartDate"].ToString()).ToString("yyyy/MM/dd");
            divContent.InnerHtml = rowNews["Content"].ToString();
        }
    }
}
