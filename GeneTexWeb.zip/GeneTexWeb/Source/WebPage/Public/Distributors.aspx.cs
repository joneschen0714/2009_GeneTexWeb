﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using Icon;
using Icon.DataBase;

public partial class WebPage_Public_Distributors : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }
    public override void DataBind()
    {
        //找經銷商的資料
        DataTable dt = BLL.GetCompany("distributor","");

        reptDistributors.DataSource = dt;
        reptDistributors.DataBind();
    }
    protected void reptDistributors_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if ((e.Item.ItemType == ListItemType.Item) || (e.Item.ItemType == ListItemType.AlternatingItem))
        {
            //控制項變數
            //Image imgCountry = (Image)e.Item.FindControl("imgCountry");
            //Label lblCountry = (Label)e.Item.FindControl("lblCountry");
            //HyperLink hyName = (HyperLink)e.Item.FindControl("hyName");
            //Label lblAddress1 = (Label)e.Item.FindControl("lblAddress1");
            //Label lblAddress2 = (Label)e.Item.FindControl("lblAddress2");
            //Label lblAddress3 = (Label)e.Item.FindControl("lblAddress3");
            //Label lblTel = (Label)e.Item.FindControl("lblTel");
            //Label lblFax = (Label)e.Item.FindControl("lblFax");
            //Label lblEmail = (Label)e.Item.FindControl("lblEmail");

            //設定值
            DataRowView rowView = (DataRowView)e.Item.DataItem;
            //imgCountry.ImageUrl = rowView["Image"].ToString();
            //lblCountry.Text = rowView["Country"].ToString();
            //hyName.Text = rowView["Name"].ToString();
            //hyName.NavigateUrl = rowView["Url"].ToString(); //連結經銷商網站
            //lblAddress1.Text = rowView["Address1"].ToString();
            //lblAddress2.Text = rowView["Address2"].ToString();
            //lblAddress3.Text = rowView["Address3"].ToString();
            //lblTel.Text = rowView["Tel"].ToString();
            //lblFax.Text = rowView["Fax"].ToString();
            //lblEmail.Text = rowView["Email"].ToString();
            Panel palDistributor = (Panel)e.Item.FindControl("palDistributor");
            Literal liDistributor = new Literal();
            //liDistributor.Text = string.Format("<div id='div{0}'>{0}</div>", rowView["id"].ToString());
            liDistributor.Text = string.Format("<div class='fontStyle05'><img src='" + rowView["Image"].ToString() + "' Width='20' Height='13' id='{0}' />  ", rowView["id"].ToString()) + rowView["Country"].ToString();
            liDistributor.Text += "</div><div class='divCompany'><a href='" + rowView["Url"].ToString() + "' Target=_blank>" + rowView["Name"].ToString() + "</a>";
            liDistributor.Text += "</div><div class='divDistributors'>" + rowView["Address1"].ToString();
            if (rowView["Address2"].ToString() != "")
                liDistributor.Text += "</div><div class='divDistributors'>" + rowView["Address2"].ToString();
            if (rowView["Address3"].ToString() != "")
                liDistributor.Text += "</div><div class='divDistributors'>" + rowView["Address3"].ToString();
            if (rowView["Tel"].ToString() != "")
                liDistributor.Text += "</div><div class='divDistributors'>Tel:" + rowView["Tel"].ToString();
            if (rowView["Fax"].ToString() != "")
                liDistributor.Text += "</div><div class='divDistributors'>Fax:" + rowView["Fax"].ToString();
            if (rowView["Email"].ToString() != "")
                liDistributor.Text += "</div><div class='divDistributors'>Email:<a href='mailto:'" + rowView["Email"].ToString() + "'>" + rowView["Email"].ToString() + "</a>";
            liDistributor.Text += "</div><div class='splitter02'></div>";


            palDistributor.Controls.Add(liDistributor);
        }
    }
}
