﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class WebPage_Public_StaticPage : System.Web.UI.Page
{
    string m_strPage = "";
    protected void Page_Init(object sender, EventArgs e)
    {
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        m_strPage = Request.QueryString["page"];
       
        //參數集合
        Hashtable htParams = new Hashtable();
        htParams.Add("ID", "-1"); //不指定ID
        htParams.Add("Type", m_strPage);

        if (m_strPage == "Protocol") 
        {
            SetDefault(false, true);
            DataTable dtProtocols = BLL.GetStaticPage(htParams); //搜尋全部Protocol資訊
            if (dtProtocols != null && dtProtocols.Rows.Count > 0)
            {
                repeProtocol.DataSource = dtProtocols;
                repeProtocol.DataBind();
                dtProtocols.Dispose();
            }
        }
        else  //其他靜態頁面
        {
            SetDefault(true, false);
            divContent.InnerHtml = BLL.GetStaticPageForString(htParams);
        }
        
    }

    //元件初始設定
    private void SetDefault(bool bVisible, bool bIsRepe)
    {
        repeProtocol.Visible = bIsRepe;
    }

    protected void repeProtocol_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            LinkButton btnProtocol = (LinkButton)e.Item.FindControl("btnProtocol");
            btnProtocol.Click += new EventHandler(btnProtocol_Click);
            btnProtocol.Text = string.Format("{0}", rowView["Name"]);
            btnProtocol.CommandArgument = string.Format("{0}", rowView["Id"]);
        }
    }

    protected void btnProtocol_Click(object sender, EventArgs e)
    {
        LinkButton btnProtocol = (LinkButton)sender;
        string strID = btnProtocol.CommandArgument;
        //參數集合
        Hashtable htParams = new Hashtable();
        htParams.Add("id", strID);
        htParams.Add("type", m_strPage);

        SetDefault(true, false);
        divContent.InnerHtml = BLL.GetStaticPageForString(htParams);
    }
}
