﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using Icon;
using Icon.Controls;
using Icon.Controls.myGridView;
using df = Icon.Definition;

public partial class WebPage_Public_News : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        gvNewsList.GridView.RowDataBound += new GridViewRowEventHandler(gvNewsList_RowDataBound);
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }


    //覆寫DataBind
    public override void DataBind()
    {
        //資料參數
        Hashtable htParams = new Hashtable();
        htParams.Add("Type", "News");
        htParams.Add("Enabled", 1);

        //呼叫邏輯層
        DataTable dtNews = BLL.GetAllNews(htParams);

        gvNewsList.Fields.Clear();
        Icon.Controls.myGridView.FieldCollection fc = gvNewsList.Fields;
        fc.Add("Date", "StartDate", true, Unit.Parse("20%"), "");
        fc.Add("Subject", "Name", true, Unit.Parse("80%"), "");
        //fTitle.HorizontalAlign = HorizontalAlign.Left; //文字置左

        gvNewsList.Property.DataKey = "Id";
        gvNewsList.DataTable = dtNews;
        gvNewsList.DataBind();

        gvNewsList.GridView.Width = Unit.Parse("100%");

        //釋放資源
        dtNews.Dispose();
        gvNewsList.Dispose();
    }


    //Row處理事件
    protected void gvNewsList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            TableCell cellTitle = Tool.GetTableCell(e.Row, "Subject", false);
            TableCell cellDate = Tool.GetTableCell(e.Row, "Date", false);
            DataRowView rowView = (DataRowView)e.Row.DataItem;

            //標題超連結
            HyperLink hl = new HyperLink();
            hl.Text = cellTitle.Text;
            hl.NavigateUrl = "~/WebPage/Public/NewsDetail.aspx?Type=News&NewsID=" + rowView["Id"].ToString();

            //發佈日期
            LiteralControl lic = new LiteralControl();
            string strPostDate = DateTime.Parse(rowView["StartDate"].ToString()).ToString("yyyy/MM/dd");
            lic.Text = string.Format("<span class='date'>{0}</span>", strPostDate);

            cellTitle.Controls.Add(hl);
            cellDate.Controls.Add(lic);
        }
    }
}
