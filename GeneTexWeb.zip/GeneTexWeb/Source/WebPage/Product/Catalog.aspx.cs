﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Controls;

public partial class WebPage_Product_Catalog : System.Web.UI.Page
{
    //全域變數
    public string m_CatalogID, m_CampaignCode, m_CampaignID, m_FiltersCode, m_Research, m_GeneID, m_CatNo, m_Keyword, m_Field, m_isResult;

    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gvProductList.GridView.RowDataBound += new GridViewRowEventHandler(gvProductList_RowDataBound);
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        m_CatalogID = Setting.CheckQueryString("CatalogID");
        m_CampaignCode = Setting.CheckQueryString("CampaignCode");
        m_FiltersCode = Setting.CheckQueryString("FilterCode");
        m_Research = Setting.CheckQueryString("Research");
        m_GeneID = Setting.CheckQueryString("GeneID");
        m_CatNo = Setting.CheckQueryString("CatNo");
        m_Keyword = Setting.CheckQueryString("keyword");
        m_Field = Setting.CheckQueryString("field");
        m_isResult = Setting.CheckQueryString("isResult");

        if (!IsPostBack)
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("CatalogID", m_CatalogID);
            htParams.Add("CampaignCode", m_CampaignCode);
            htParams.Add("CatNo", m_CatNo);
            htParams.Add("FilterCode", m_FiltersCode);
            htParams.Add("Research", m_Research);
            htParams.Add("GeneID", m_GeneID);
            htParams.Add("Keyword", m_Keyword);
            htParams.Add("Field", m_Field);

            //抓Catalog
            if (!string.IsNullOrEmpty(m_CatalogID))
            {
                DataTable dtProductClassRel = new DataTable();
                DataTable dtResearchAreaRel = new DataTable();
                DataTable dtCatalog = BLL.GetListByCatalog(htParams, ref dtProductClassRel, ref dtResearchAreaRel);

                Hashtable myParams = new Hashtable();
                myParams.Add("CatalogID", m_CatalogID);
                DataRow row = BLL.GetCatalogData(myParams);
                liMessage.Text = Convert.ToString(row["Description"]);

                dtCatalog.DefaultView.Sort = "SortNum DESC";
                gvProductList_DataBind(dtCatalog.DefaultView.ToTable(), dtProductClassRel, dtResearchAreaRel);
            }

            //抓Campaign
            else if (!string.IsNullOrEmpty(m_CampaignCode))
            {
                DataTable dtProductClassRel = new DataTable();
                DataTable dtResearchAreaRel = new DataTable();
                DataTable dtCampaign = BLL.GetListByCampaign(htParams, ref dtProductClassRel, ref dtResearchAreaRel);

                Hashtable myParams = new Hashtable();
                myParams.Add("CampaignCode", m_CampaignCode);
                DataRow row = BLL.GetCatalogData(myParams);
                m_CampaignID = row["CampaignID"].ToString();
                liMessage.Text = string.Format("{0}<br/><br/>{1}", row["Description"], row["Message"]);

                dtCampaign.DefaultView.Sort = "SortNum DESC";
                gvProductList_DataBind(dtCampaign.DefaultView.ToTable(), dtProductClassRel, dtResearchAreaRel);
            }

            //抓此GeneID下的所有產品
            else if (!string.IsNullOrEmpty(m_GeneID))
            {
                DataTable dtProductClassRel = new DataTable();
                DataTable dtResearchAreaRel = new DataTable();
                DataTable dtCatalog = BLL.GetListByRelatedProduct(htParams, ref dtProductClassRel, ref dtResearchAreaRel);

                dtCatalog.DefaultView.Sort = "SortNum DESC";
                gvProductList_DataBind(dtCatalog.DefaultView.ToTable(), dtProductClassRel, dtResearchAreaRel);
            }

            //抓Keyword Search的產品
            else if (!string.IsNullOrEmpty(m_Keyword))
            {
                if (m_isResult == "Y")
                {
                    DataTable dtProductClassRel = new DataTable();
                    DataTable dtResearchAreaRel = new DataTable();
                    DataTable dtCatalog = BLL.GetListByKeywordSearch(htParams, ref dtProductClassRel, ref dtResearchAreaRel);

                    dtCatalog.DefaultView.Sort = "SortNum DESC";
                    gvProductList_DataBind(dtCatalog.DefaultView.ToTable(), dtProductClassRel, dtResearchAreaRel);
                }
                else
                {
                    palProductList.Visible = false;
                    ShowMessage();
                }
            }
        }
    }

    protected void gvProductList_DataBind(DataTable dtProductList, DataTable dtProductClassRel, DataTable dtResearchAreaRel)
    {
        //建立產品分類資料
        CreateProductClass(dtProductClassRel);
        CreateResearchArea(dtResearchAreaRel);
        SetRemoreFilterTitle();

        //增加欄位
        gvProductList.Fields.Clear();
        Icon.Controls.myGridView.FieldCollection fc = gvProductList.Fields;
        fc.Add("CatNo", "CatNo", false, Unit.Empty, "");
        fc.Add("Product Name", "ProductName", false, Unit.Empty, "");
        fc.Add("Package", "Package", false, Unit.Empty, "");
        fc.Add("Reactivity", "", false, Unit.Empty, "");
        fc.Add("Application", "", false, Unit.Empty, "");
        fc.Add("Images", "ImgCount", false, Unit.Empty, "");
        fc.Add("In Stock", "", false, Unit.Empty, "");
        fc.Add("Price", "Price", false, Unit.Empty, "");
        fc.Add("Special", "PromotionPrice", false, Unit.Empty, "");

        gvProductList.Property.DataKey = "CatNo"; //設定主鍵
        gvProductList.DataTable = dtProductList;
        gvProductList.DataBind();
    }
    protected void gvProductList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem; //取得單筆Row資料來源

            TableCell cellCatNo = Tool.GetTableCell(e.Row, "CatNo", false);
            TableCell cellImages = Tool.GetTableCell(e.Row, "Images", false);
            TableCell cellReactivity = Tool.GetTableCell(e.Row, "Reactivity", false);
            TableCell cellApplication = Tool.GetTableCell(e.Row, "Application", false);
            TableCell cellPrice = Tool.GetTableCell(e.Row, "Price", false);
            TableCell cellSpecialPrice = Tool.GetTableCell(e.Row, "Special", false);
            TableCell cellInStock = Tool.GetTableCell(e.Row, "In Stock", false);

            //變數
            string strCatNo = rowView["CatNo"].ToString();
            string strCatalogItemID = rowView["CatalogItemID"].ToString();
            string strCurrencyName = rowView["CurrencyName"].ToString();
            string strSupplierName = rowView["SupplierName"].ToString().Trim().ToLower();
            int iDecimalNum = Convert.ToInt32(rowView["DecimalNum"]);
            bool bReplaced = Convert.ToBoolean(rowView["BeReplaced"]);

            cellCatNo.Text = string.Format("<a href=\"{0}\">{1}</a>",
                                            ResolveClientUrl("~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + strCatalogItemID + "&CampaignId=" + m_CampaignID),
                                            strCatNo);

            //判斷此產品是否被取代
            if (bReplaced) { cellCatNo.Text += " <font color='Red'>[Replaced]</font>"; }

            //取得產品分類內容
            cellReactivity.Text = BLL.GetProductClassValue(strCatNo, "Reactivity", false);
            cellApplication.Text = BLL.GetProductClassValue(strCatNo, "Application", false);

            //轉換 組成貨幣顯示文字
            if (decimal.Parse(cellPrice.Text) == 0) { cellPrice.Text = "-"; }
            else { cellPrice.Text = Setting.GetCurrencyFormat(strCurrencyName, cellPrice.Text, iDecimalNum); }
            if (decimal.Parse(cellSpecialPrice.Text) == 0) { cellSpecialPrice.Text = "-"; }
            else { cellSpecialPrice.Text = Setting.GetCurrencyFormat(strCurrencyName, cellSpecialPrice.Text, iDecimalNum); }

            //Image顯示
            if (rowView["ImgCount"].ToString() != "")
            {
                cellImages.Text = string.Format("<div align='center'><img title='View Images' src='{0}' onclick=\"GetDynamicProductImages('{1}')\" style='cursor:pointer;' /></div>",
                                                    ResolveClientUrl("~/Images/Images/camera.png"),
                                                    strCatNo);
            }

            //In Stock
            if (strSupplierName == "iconbio")
            {
                cellInStock.Text = string.Format("<div align='center'><img src='{0}' /></div>", ResolveClientUrl("~/Images/Controls/select.png"));
            }
        }
    }

    private void CreateProductClass(DataTable dtProductClassRel)
    {
        liClass.Text = "";
        liFilters.Text = "";

        //建立Filter主項目
        Hashtable htClass = new Hashtable();
        htClass.Add("ProductType", "By ProductType");
        htClass.Add("Clonality", "By Clonality");
        htClass.Add("Host", "By Host");
        htClass.Add("Application", "By Application");
        htClass.Add("Conjugation", "By Conjugation");
        htClass.Add("Specificity", "By Specificity");

        //dtProductClassRel.DefaultView.Sort = "GroupId, Code";
        //DataTable dtProductClassItem = dtProductClassRel.DefaultView.ToTable(true, "Id", "p_Id", "Code", "Type", "Name");

        #region 建立Filter條件
        string[] strFilterCodeList = m_FiltersCode.ToString().Split(',');
        foreach (string strFilterCode in strFilterCodeList)
        {
            DataRow[] rowItems = dtProductClassRel.Select("Code='" + strFilterCode + "'");
            if (rowItems.Length > 0)
            {
                string strType = rowItems[0]["Type"].ToString();
                liFilters.Text += string.Format("<div class='RemoveFilterItem' style='cursor:pointer;' onclick=\"RemoveFilter('{2}')\"><font color='Red'>X</font> {0}: {1}</div>", strType, rowItems[0]["Name"], rowItems[0]["Code"]);
                htClass.Remove(strType);
            }
        }
        #endregion

        #region 建立Filter可選擇項目
        //循序讀取Filter主項目
        foreach (string strType in htClass.Keys)
        {
            int iSubIndex = 0;
            string strItem = "";
            //DataRow[] rowLevel1ItemList = dtProductClassItem.Select("Type='" + strType + "' AND p_Id=0");
            DataRow[] rowLevel1ItemList = dtProductClassRel.Select("Type='" + strType + "' AND p_Id=0");
            for (int i = 0; i < rowLevel1ItemList.Length; i++)
            {
                DataRow rowLevel1 = rowLevel1ItemList[i];
                int iLevel1Count = Convert.ToInt32(rowLevel1["SubCount"]);
                //dtProductClassRel.DefaultView.RowFilter = "Code LIKE '" + rowLevel1["Code"] + "%' AND CatNo <> ''";
                //int iLevel1Count = dtProductClassRel.DefaultView.ToTable(true, "CatNo").Rows.Count;
                if (iLevel1Count > 0)
                {
                    string strAttr = "";
                    if (iSubIndex >= 4) { strAttr = "jTag='SlideItem' style='display:none;'"; }

                    strItem += string.Format("<a {3} onclick=\"AddFilter('{2}')\"> - {0}({1})</a>", rowLevel1["Name"], iLevel1Count, rowLevel1["Code"], strAttr);

                    /*
                    DataRow[] rowLevel2ItemList = dtProductClassItem.Select("p_Id=" + rowLevel1["Id"].ToString());
                    for (int j = 0; j < rowLevel2ItemList.Length; j++)
                    {
                        DataRow rowLevel2 = rowLevel2ItemList[j];
                        int iLevel2Count = dtProductClassRel.Select("Id=" + rowLevel2["Id"].ToString() + " AND CatNo <> ''").Length;
                        if (iLevel2Count > 0)
                        {
                            strItem += string.Format("<li onclick=\"AddFilter('{2}')\"> - {0}({1})</li>", rowLevel2["Name"], iLevel2Count, rowLevel2["Code"]);
                        }
                    }
                    */
                    iSubIndex++;
                }
            }

            string strMoreAttr = "";
            if (iSubIndex > 4) { strMoreAttr = "<a jTag='FilterMoreButton'>more</a>"; }

            //組成顯示項目
            if (iSubIndex > 0)
            {
                liClass.Text += string.Format("<div jTag='divFilterGroup'><label>{0}</label><div>{1}</div>{2}</div>", htClass[strType], strItem, strMoreAttr);
            }
        }
        #endregion
    }
    private void CreateResearchArea(DataTable dtResearchAreaRel)
    {
        if (m_Research != "")
        {
            DataRow[] rowItems = dtResearchAreaRel.Select("Id=" + m_Research);
            if (rowItems.Length > 0)
            {
                DataRow rowItem = rowItems[0];
                liFilters.Text += string.Format("<div class='RemoveFilterItem' style='cursor:pointer;' onclick=\"FillResearch('RemoveResearch',{2})\"><font color='Red'>X</font> {0}: {1}</div>", "ResearchArea", rowItem["Value"], rowItem["Id"]);
            }
        }
        else
        {
            if (dtResearchAreaRel.Rows.Count > 0)
            {
                string strItem = "";
                for (int i = 0; i < dtResearchAreaRel.Rows.Count; i++)
                {
                    string strAttr = "";
                    if (i >= 4) { strAttr = "jTag='SlideItem' style='display:none;'"; }

                    DataRow rowItem = dtResearchAreaRel.Rows[i];
                    strItem += string.Format("<a {3} onclick=\"FillResearch('AddResearch',{2})\"> - {0}({1})</a>", rowItem["Value"], rowItem["subCount"], rowItem["Id"], strAttr);
                }

                string strMoreAttr = "";
                if (dtResearchAreaRel.Rows.Count > 4) { strMoreAttr = "<a jTag='FilterMoreButton'>more</a>"; }

                liClass.Text += string.Format("<div jTag='divFilterGroup'><label>By ResearchArea</label><div>{0}</div>{1}</div><br/>", strItem, strMoreAttr);
            }
        }
    }
    private void SetRemoreFilterTitle()
    {
        if (liFilters.Text.Trim() != "")
        {
            liFilters.Text = "<label id='RemoveFilterTitle'>Remove filters</label><br>" + liFilters.Text;
        }
    }

    protected void btnAction_Click(object sender, EventArgs e)
    {
        string strAction = txtAction.Text;
        string strType = txtClassType.Text;
        string strCode = txtCode.Text;


        #region 重組Url QueryString
        string strQueryString = "";
        string strFilterCode = Setting.CheckQueryString("FilterCode");
        string strResearch = Setting.CheckQueryString("Research");

        foreach (string strKey in Request.QueryString)
        {
            if (strKey != "FilterCode" && strKey != "Research")
                strQueryString += (strQueryString == "" ? "?" : "&") + string.Format("{0}={1}", strKey, Setting.CheckQueryString(strKey));
        }

        if (strAction == "AddFilter")
        {
            strFilterCode += (strFilterCode == "" ? "" : ",") + strCode;
        }
        else if (strAction == "RemoveFilter")
        {
            string strNewCode = "";
            string[] strCodeList = strFilterCode.Split(',');
            foreach (string thisCode in strCodeList)
            {
                if (thisCode != strCode)
                    strNewCode += (strNewCode == "" ? "" : ",") + thisCode;
            }
            strFilterCode = strNewCode;
        }
        else if (strAction == "AddResearch")
        {
            strResearch = strCode;
        }
        else if (strAction == "RemoveResearch")
        {
            strResearch = "";
        }

        if (strFilterCode != "") { strQueryString += "&FilterCode=" + strFilterCode; }
        if (strResearch != "") { strQueryString += "&Research=" + strResearch; }
        #endregion

        //轉向至新的Url
        int indexChar = Request.Url.ToString().IndexOf("?");
        string strCurrentUrl = Request.Url.ToString().Substring(0, indexChar);
        strCurrentUrl += strQueryString;
        Response.Redirect(strCurrentUrl);
    }
    private void ShowMessage()
    {
        string strMessage = "No search results found. This product may be available. Please contact GeneTex at: sales@genetex.com or 1-877-GeneTex";
        lblMessage.Text = strMessage;
        lblMessage.Visible = true;
    }
}