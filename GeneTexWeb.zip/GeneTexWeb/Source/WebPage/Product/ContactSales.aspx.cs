﻿using System;
using System.Data;
using System.Xml;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using df = Icon.Definition;
using System.Globalization;
using Icon;

public partial class WebPage_Product_ContactSales : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
        //string strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系

        //設定語系
        div_CultureInfo.InnerHtml = Resources.Public.ContactSales_ContactUsInfo;
        lblUserName.Text = Resources.Public.ContactSales_UserName;
        lblSubject.Text = Resources.Public.ContactSales_Subject;
        lblEmail.Text = Resources.Public.ContactSales_Email;
        lblCompany.Text = Resources.Public.ContactSales_Company;
        lblCountry.Text = Resources.Public.ContactSales_Country;
        lblState.Text = Resources.Public.ContactSales_State;
        lblPhone.Text = Resources.Public.ContactSales_Phone;
        lblContent.Text = Resources.Public.ContactSales_Content;
        btnSubmit.Text = Resources.Public.ContactSales_Submit;
        rev_txtEmail.ErrorMessage = Resources.ErrMsg.EmailFormatErr;
        //預設Enter按鈕
        Page.Form.DefaultButton = btnSubmit.UniqueID;

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SetDefault();
        }
    }

    //設定預設資料
    private void SetDefault()
    {
        //設定國家下拉選單
        ddlCountry.DataSource = BLL.GetCountry();
        ddlCountry.DataBind();
        ListItem foundItem = ddlCountry.Items.FindByValue(Definition.CountryCode);
        foundItem.Selected = true;

        SetState();
    }

    //選擇國家動作
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        SetState();
    }

    //設定State textbox or dropdownlist 
    private void SetState()
    {
        if (ddlCountry.SelectedValue != string.Empty)
        {
            //取得對應的State資料
            DataTable dtState = BLL.GetState(ddlCountry.SelectedValue);

            //判斷是否有State資料
            if (dtState.Rows.Count > 0)
            {
                //設定State顯示區塊
                rfv_txtState.Visible = false;
                txtState.Visible = false;
                ddlState.Visible = true;

                //設定State下拉選單
                ddlState.Items.Clear();
                ddlState.DataSource = dtState;
                ddlState.DataBind();
            }
            else
            {
                //設定State顯示區塊
                rfv_txtState.Visible = true;
                txtState.Visible = true;
                ddlState.Visible = false;
            }
        }
        else
        {
            txtState.Visible = true;
            ddlState.Visible = false;
        }
        uplState.Update();
    }

    //送出
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //參數集合
        Hashtable htParams = new Hashtable();
        htParams.Add("UserName", txtUserName.Text);
        htParams.Add("Subject", txtSubject.Text);
        htParams.Add("SenderEmail", txtEmail.Text);
        htParams.Add("Company", txtCompany.Text);
        htParams.Add("Country", ddlCountry.SelectedItem.Text); //User Country

        if (ddlState.Visible)
            htParams.Add("State", ddlState.SelectedItem.Text);
        else if (txtState.Visible)
            htParams.Add("State", txtState.Text);

        htParams.Add("Phone", txtPhone.Text);
        htParams.Add("Content", txtContent.Text);

        //呼叫邏輯層
        bool bResult;
        string strMessage;
        BLL.InsertContactSales(out bResult, out strMessage, htParams);
        //若執行成功
        if (bResult)
        {
            string strRoot = "GeneTexForum";
            string strXml = string.Format("<{0}>",strRoot);
            strXml += BLL.AddXmlNode("Email", txtEmail.Text);
            strXml += BLL.AddXmlNode("Subject", txtSubject.Text);
            strXml += BLL.AddXmlNode("Content", txtContent.Text);
            strXml += BLL.AddXmlNode("ForumID", "1"); //增加到論壇主題
            strXml += BLL.AddXmlNode("IP", Request.UserHostAddress);

            BLL.SendInfoToForum(strXml, strRoot, txtEmail.Text, ref strMessage, ref bResult);
        }
        if (bResult)
            Page.RegisterClientScriptBlock("New", "<script>alert('" + Resources.ErrMsg.MailSuccess2 + "');location.href='" + Request.Url + "';</script>");
        else if (!bResult)
            Page.RegisterClientScriptBlock("New", "<script>alert('" + Resources.ErrMsg.MailFailure + "');location.href='" + Request.Url + "';</script>");

    }
}
