﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class WebPage_Product_AdvancedSearch : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));

        div_CultureInfo.InnerHtml = Resources.Public.AdvancedSearch_Info;
        lblKeyword.Text = Resources.Public.AdvancedSearch_Keyword;
        lblSearchIn.Text = Resources.Public.AdvancedSearch_In;
        lblCatalog.Text = Resources.Public.AdvancedSearch_Catalog;
        //lblMfg.Text = Resources.Public.AdvancedSearch_Mfg;
        btnSubmit.Text = Resources.Public.AdvancedSearch_Submit;

        DataRow[] rowArray = BLL.GetAllNodeProductMap("ProductType", 0);
        ddlSearchIn.Items.Add(new ListItem("ALL Product","-1"));
        if (rowArray != null && rowArray.Length > 0)
        {
            foreach (DataRow dr in rowArray)
                ddlSearchIn.Items.Add(new ListItem(dr["Name"].ToString(), dr["Code"].ToString()));
			ViewState["dsCustomers"] = rowArray;
        }

		//預設Enter按鈕 & 預設焦點
		Page.Form.Attributes.Add("onkeydown", "changeFocusControl('" + btnSubmit.ClientID + "', event)");
		Page.Form.DefaultFocus = txtKeyword.ClientID;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    //送出
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (txtCatalog.Text == "" && txtKeyword.Text == "")
        {
            lblError.Text = " *";
            return;
        }
		string strUrl = "~/WebPage/Product/Catalog.aspx?Type=AdvancedSearch";
        Session.Add("AS_Keyword", txtKeyword.Text);
        Session.Add("AS_MapCode", ddlSearchIn.SelectedItem.Value);
        Session.Add("AS_CatNo", txtCatalog.Text);
        Session.Add("AS_Type", 'A');
        Session.Add("AS_ProductMap", "ProductType");

		if (ddlSearchIn.SelectedItem.Value == "-1") //all product
		{
			Session.Add("AS_ProductMap_Id", -1);
		}
		else
		{
			DataRow[] rowArray = (DataRow[])ViewState["dsCustomers"];
			if (rowArray != null && rowArray.Length > 0)
			{
				foreach (DataRow dr in rowArray)
				{
					if (ddlSearchIn.SelectedItem.Text == dr["Name"].ToString() && ddlSearchIn.SelectedItem.Value == dr["Code"].ToString())
					{
						Session.Add("AS_ProductMap_Id", dr["Id"]);
						break;
					}
				}
			}
		}
        Response.Redirect(strUrl);
    }
}
