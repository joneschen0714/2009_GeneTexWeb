﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class WebPage_Product_CatalogDatail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["CatalogID"] != null)
            {
                DataRow dr = BLL.GetCatalogDetail(Request.QueryString["CatalogID"], Request.QueryString["CampaignCode"]);

                string strView = ResolveUrl("~/WebPage/Product/Catalog.aspx?CatalogID=") + dr["ID"].ToString();
                string strCampaign = "";

                //if (dr["ImgSrc"].ToString() != "")
                //   lblHeader.Text = "<img src=" + ResolveUrl(dr["ImgSrc"].ToString()) + " />";
               //lblHeader.Text += dr["Name"].ToString();
               if (Request.QueryString["CampaignCode"] != null)
                {
                    strView = ResolveUrl("~/WebPage/Product/Catalog.aspx?CampaignCode=") + Request.QueryString["CampaignCode"].ToString();
                    strCampaign = dr["CamDescription"].ToString();
                }
                lblDescription.Text = string.Format("<div>{0}<br><br>{1}</div><div align=\"right\"><a href=\"{2}\">View List</a></div>",
                                             dr["Description"], strCampaign, strView);
            }
        }
    }
}
