﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Controls;
using Icon.Controls.myGridView;
using df = Icon.Definition;

public partial class WebPage_Product_Promotion : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        gvList.GridView.RowDataBound += new GridViewRowEventHandler(gvList_RowDataBound);
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }


    //覆寫DataBind
    public override void DataBind()
    {
        //資料參數
        Hashtable htParams = new Hashtable();
        htParams.Add("Type", "Promotion");
        htParams.Add("Enabled", 1);

        //呼叫邏輯層
        DataTable dtNews = BLL.GetAllNews(htParams);

        gvList.Fields.Clear();
        Icon.Controls.myGridView.FieldCollection fc = gvList.Fields;
        fc.Add(Resources.Public.Subject, "Name", true, Unit.Parse("30%"), "").HtmlEncode = false;
        fc.Add(Resources.Public.Description, "Description", true, Unit.Parse("45%"), "").HtmlEncode = false;
        fc.Add(Resources.Public.Between, "", true, Unit.Parse("25%"), "");

        gvList.Property.DataKey = "Id";
        gvList.DataTable = dtNews;
        gvList.DataBind();

        //釋放資源
        dtNews.Dispose();
        gvList.Dispose();
    }


    //Row處理事件
    protected void gvList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            TableCell cellTitle = Tool.GetTableCell(e.Row, "Name", true);
            TableCell cellBetween = Tool.GetTableCell(e.Row, Resources.Public.Between, false);

            //標題超連結
            HyperLink hl = new HyperLink();
            hl.Text = cellTitle.Text;
            hl.NavigateUrl = "~/WebPage/Product/PromotionDetail.aspx?PromotionID=" + rowView["Id"].ToString();
            cellTitle.Controls.Add(hl);

            //日期期間
            string StartDate = DateTime.Parse(rowView["StartDate"].ToString()).ToString("yyyy/MM/dd");
            string EndDate = DateTime.Parse(rowView["EndDate"].ToString()).ToString("yyyy/MM/dd");
            cellBetween.Text = string.Format("{0} ~ {1}", StartDate, EndDate);
        }
    }
}
