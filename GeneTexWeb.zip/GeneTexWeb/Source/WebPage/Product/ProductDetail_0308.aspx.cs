﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.DataBase;
using Icon.Member;
using Icon.Controls;
using df = Icon.Definition;

public partial class WebPage_Product_ProductDetail : System.Web.UI.Page
{
    DataBase db = new DataBase(Icon.Definition.WebConnStr);
    Hashtable DisplayNameTable;

    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css檔 & JavaScript檔
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "Validate", ResolveUrl("~/Js/ControlValidate.js"));
        ScriptManager.RegisterClientScriptInclude(this, typeof(Page), "fn_WindowOpen", ResolveUrl("~/Js/fn_WindowOpen.js"));

        //註冊頁面Css
        string strStyle = "<style type='text/css'>" +
                            "#tbGeneralRef th , #tbSpecificRef th { vertical-align:top; text-align:left; width:20px; }" +
                       "</style>";
        Page.Header.Controls.Add(new LiteralControl(strStyle));
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //設定ViewState變數
            CatNo = BLL.GetCatNo(Request.QueryString["CatNo"], Request.QueryString["CatalogItemID"]);
            CatalogItemID = BLL.GetCatalogItemID(Request.QueryString["CatNo"], Request.QueryString["CatalogItemID"]);
            CampaignID = Request.QueryString["CampaignID"];

            CreateReferenceInfo(); //建立相關參考文獻

            //設定Print Version屬性
            string strURL = ResolveUrl(string.Format("~/WebPage/Product/PrintProduct.aspx?CatNo={0}&CatalogItemID={1}&CampaignID={2}", CatNo, CatalogItemID, CampaignID));
            btnPrint.Attributes.Add("onclick", "fn_WindowOpen('" + strURL + "', 'PrintView', 850, 700); return false;");
            btnPrint1.Attributes.Add("onclick", "fn_WindowOpen('" + strURL + "', 'PrintView', 850, 700); return false;");

            //寫入Cookie
            if (Request.Cookies["historybrowser"] == null)
            {
                HttpCookie Cookie = new HttpCookie("historybrowser");
                Cookie.Values.Add("product", "");
                Cookie.Expires = DateTime.Now.AddDays(10);
                Response.Cookies.Add(Cookie);
            }
			AddCookie(CatalogItemID.ToString());
        }

        //CreateRelatedProduct(); //建立相關產品資訊-GeneTex新版

        CreateDisplayTable();
        SetProductInfo(); //建立產品欄位資訊
    }

	//清除Cookie
	public void ClearCookie()
	{
		HttpCookie Cookie = new HttpCookie("historybrowser");
		Cookie.Expires = DateTime.Now.AddDays(-12);
		Response.Cookies.Add(Cookie);
	}

	//加入Cookie
    public void AddCookie(string cookievalue)
    {

        HttpCookie cookie = new HttpCookie("historybrowser");
        if (Request.Cookies["historybrowser"].Values["product"] != null && Request.Cookies["historybrowser"].Values["product"] != "")
        {
            string strValue = "";
            strValue = Request.Cookies["historybrowser"].Values["product"].ToString();
			//若Cookies已有值,則略過
			string[] strRead = strValue.Split(new String[] { "," }, StringSplitOptions.RemoveEmptyEntries);
			bool bIsOK = true;

			for (int i = 0; i < strRead.Length; i++)
			{
				if (strRead[i] == cookievalue)
				{
					bIsOK = false;
					break;
				}
			}
			if (bIsOK)
			{
				strValue = cookievalue + "," + strValue;
				cookie.Values.Add("product", strValue);
				cookie.Expires = DateTime.Now.AddDays(10);
				Response.Cookies.Add(cookie);
			}
        }
        else
        {
            cookie.Values.Add("product", cookievalue);
            cookie.Expires = DateTime.Now.AddDays(10);
            Response.Cookies.Add(cookie);
        }
    }


    //相關產品List - 新版
    private void CreateRelatedProduct()
    {
        //呼叫邏輯層
        DataTable dtRelated = BLL.GetProductRelated(CatNo, "Related");

        //循序讀取關連產品資料
        foreach (DataRow row in dtRelated.Rows)
        {
            //表格物件
            TableRow tr = new TableRow();
            TableCell tdProduct = new TableCell();
            TableCell tdCatNo = new TableCell();

            //設定Product欄位控制項
            HyperLink linkProduct = new HyperLink();
            linkProduct.Text = row["ProductName"].ToString();
            linkProduct.NavigateUrl = string.Format("ProductDetail.aspx?CatNo={0}", row["RelatedCatNo"]);
            linkProduct.CssClass = "a2";
            tdProduct.Controls.Add(linkProduct);
            tdProduct.Controls.Add(new LiteralControl("<br/>" + row["ApplicationAbbrev"].ToString()));

            //設定CatNo欄位控制項
            Label lblCatNo = new Label();
            lblCatNo.Text = row["RelatedCatNo"].ToString();
            tdCatNo.Controls.Add(lblCatNo);

            //設定表格控制項
            tr.Cells.Add(tdProduct);
            tr.Cells.Add(tdCatNo);
            tbRelatedProduct.Rows.Add(tr);
        }
        palRelatedProduct.Visible = (dtRelated.Rows.Count > 0);
    }


    //建立DisplayName資料
    private void CreateDisplayTable()
    {
        DisplayNameTable = new Hashtable();
        DisplayNameTable.Add("CatNo", "Catalog Number");
        DisplayNameTable.Add("ProductName", "Product Name");
        DisplayNameTable.Add("FullName", "Full Name");
        DisplayNameTable.Add("Manufacturer_MfgPart", "Manufacturer & Mfg Part#");
        DisplayNameTable.Add("ProductDescription", "Product Description");
        DisplayNameTable.Add("Synonyms", "Synonyms");
        //DisplayNameTable.Add("ProductType", "Product Type");
        DisplayNameTable.Add("Background", "Background");
        DisplayNameTable.Add("Clonality", "Clonality");
        DisplayNameTable.Add("CloneNo", "Clone No");
        DisplayNameTable.Add("Host", "Host");
        DisplayNameTable.Add("Isotype", "Isotype");
        DisplayNameTable.Add("LigChain", "Lig Chain");
        DisplayNameTable.Add("Immunogen", "Immunogen");
        DisplayNameTable.Add("AntigenSpecies", "Antigen Species");
        DisplayNameTable.Add("TestedApplications", "Tested Applications");
        DisplayNameTable.Add("ApplicationNote", "Application Note");
        DisplayNameTable.Add("Specificity", "Specificity");
        //DisplayNameTable.Add("ApplicationAbbrev", "Application Abbrev");
        DisplayNameTable.Add("SpeciesCrossReactivity", "Species Cross Reactivity");
        DisplayNameTable.Add("PositiveControls", "Positive Controls");
        DisplayNameTable.Add("Target", "Target");
        DisplayNameTable.Add("PredictedTargetSize", "Predicted Target Size(KDa)");
        DisplayNameTable.Add("CellularLocalization", "Cellular Localization");
        DisplayNameTable.Add("Conjugation", "Conjugation");
        DisplayNameTable.Add("ConjuationNote", "Conjuation Note");
        DisplayNameTable.Add("FormSupplied", "Form Supplied");
        DisplayNameTable.Add("Conc", "Concentration");
        DisplayNameTable.Add("Purification", "Purification");
        DisplayNameTable.Add("PurificationNote", "Purification Note");
        DisplayNameTable.Add("StorageBuffer", "Storage Buffer");
        DisplayNameTable.Add("StorageInstruction", "Storage Instruction");
        DisplayNameTable.Add("Notes", "Notes");
    }


    //設定產品資訊
    private void SetProductInfo()
    {
        DataTable dt = BLL.GetProductDetail(CatalogItemID); //呼叫邏輯層 (取得產品資訊)
        DataRow row = dt.Rows[0];

        BLL.ChangeProductDetailData(row); //轉換產品內容格式及資料

        for (int i = 0; i < row.ItemArray.Length; i++) //循序增加欄位資訊
        {
            string strTitle = row.Table.Columns[i].ColumnName;
            string strValue = row[i].ToString();
            AddProductInfo(strTitle, strValue);
        }

        DataTable dtOrderInfo = BLL.GetProductOrderInfo(CatalogItemID, CampaignID); //呼叫邏輯層 (取得產品購物資訊)
        if (dtOrderInfo.Rows.Count > 0)
        {
            SetOrderCart(dtOrderInfo.Rows[0], row["ProductName"]); //設定購物車資訊
        }
        else
        {
            palShoppingCart.Visible = false;
            palMessage.Visible = true;
            liMessage.Text = "<label style='color:red;'>We apologize. GeneTex, Inc. no longer carries this product. Please check the replacement information on the right column of this page, or please contact us if there are any questions: support@genetex.com.</label><br/><br/><br/>";
        }

        InsertSearchLog(""); //記錄檢索的記錄

        //Meta Data (給搜尋引擎使用)
        string strMeta = "<meta name=\"keywords\" content=\"CatNo:" + row["CatNo"].ToString() + "\" />" +
                         "<meta name=\"keywords\" content=\"ProductName:" + row["ProductName"].ToString() + "\" />";
        Page.Header.Controls.Add(new LiteralControl(strMeta));
    }

    //記錄檢索的記錄
    private void InsertSearchLog(string strValue)
    {
        //判斷是否已經看過此CatNo
        bool bContain = df.lstCatalogItemID.Contains(CatalogItemID);
        if (bContain)
            return;
        else
            df.lstCatalogItemID.Add(CatalogItemID);

        //取得使用者IP
        string ClientIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (ClientIP == null || ClientIP == "")
        {
            ClientIP = Request.ServerVariables["REMOTE_ADDR"];
        }

        //過濾IP，濾掉iconbio,本機和genetex
        bool bFilter = BLL.FilterIP(ClientIP);
        if (bFilter)
            return;

        bool bResult = true; //是否有結果

        Hashtable htParams = new Hashtable();
        htParams.Add("IP", ClientIP);
        htParams.Add("Keyword", strValue);
        htParams.Add("IsResult", bResult);
        htParams.Add("Member_ID", df.PersonalMemberID);
        htParams.Add("Type", "Clicked");
        htParams.Add("CatNo", CatNo);
        htParams.Add("CatalogItem_ID", CatalogItemID);

        bResult = false;
        string strMessage = "";
        BLL.InsertSearchLog(ref bResult, ref strMessage, htParams);
    }

    //增加欄位資訊
    private void AddProductInfo(string Title, string Value)
    {
        if (Value.Trim() != "") //若不為空值
        {
            string strDisplayName = "";
            if (DisplayNameTable.ContainsKey(Title)) //若欄名有在DisplayName表裡
            {
                strDisplayName = DisplayNameTable[Title].ToString(); //取得Display欄名

                //宣告Table相關物件
                TableRow row = new TableRow();
                TableHeaderCell HeadCell = new TableHeaderCell();
                TableCell cellData = new TableCell();

                HeadCell.Height = 20;
                HeadCell.CssClass = "BottomLineStyle1";
                cellData.CssClass = "BottomLineStyle1";

                //設定Cell資料
                HeadCell.Text = "<nobr>" + strDisplayName + "</nobr>";
                cellData.Text = Value;

                //增加Row至Table
                row.Cells.Add(HeadCell);
                row.Cells.Add(cellData);
                tableProductInfo.Rows.Add(row);
            }
        }
    }


    //建立參考文獻List
    private void CreateReferenceInfo()
    {
        //呼叫邏輯層(取得文獻資料)
        DataTable dtRef = BLL.GetProductReference(CatNo);

        //循序讀取General文獻資料列
        int iNo = 1;
        DataRow[] rowGeneralArray = dtRef.Select("Type='General'");
        palGeneralRef.Visible = (rowGeneralArray.Length > 0);
        foreach (DataRow rowGeneral in rowGeneralArray)
        {
            liGeneralRef.Text += string.Format("<tr><th>{0}.</th><td>{1}</td></tr>", iNo, rowGeneral["Ref"]);
            iNo++;
        }

        //循序讀取Specific文獻資料列
        iNo = 1;
        DataRow[] rowSpecificArray = dtRef.Select("Type='Specific'");
        palSpecificRef.Visible = (rowSpecificArray.Length > 0);
        foreach (DataRow rowSpecific in rowSpecificArray)
        {
            liSpecificRef.Text += string.Format("<tr><th>{0}.</th><td>{1}</td></tr>", iNo, rowSpecific["Ref"]);
            iNo++;
        }
    }


    //設定購物車
    private void SetOrderCart(DataRow rowData, object ProductName)
    {
        //宣告表格物件
        TableRow row = new TableRow();
        TableCell cellProductName = new TableCell();
        TableCell cellCatNo = new TableCell();
        TableCell cellPackage = new TableCell();
        TableCell cellPrice = new TableCell();
        TableCell cellSpecialPrice = new TableCell();

        //樣式
        cellProductName.HorizontalAlign = HorizontalAlign.Left;
        cellCatNo.HorizontalAlign = HorizontalAlign.Left;
        cellPackage.HorizontalAlign = HorizontalAlign.Right;
        cellPrice.HorizontalAlign = HorizontalAlign.Right;
        cellSpecialPrice.HorizontalAlign = HorizontalAlign.Right;

        //加入表格
        row.Cells.Add(cellProductName);
        row.Cells.Add(cellCatNo);
        row.Cells.Add(cellPackage);
        row.Cells.Add(cellPrice);
        row.Cells.Add(cellSpecialPrice);
        tbShoppintCart.Rows.AddAt(1, row);

        //設定值
        cellProductName.Text = ProductName.ToString();
        cellCatNo.Text = rowData["CatNo"].ToString();
        cellPackage.Text = rowData["Package"].ToString();


        #region 轉換貨幣格式 yunyu
        string strCurrencyName = rowData["CurrencyName"].ToString();
        int iDecimalNum = int.Parse(rowData["DecimalNum"].ToString());

        cellPrice.Text = SetMoneyFormat(strCurrencyName, rowData["Price"].ToString(), iDecimalNum); //轉換 組成貨幣顯示文字
        cellSpecialPrice.Text = SetMoneyFormat(strCurrencyName, rowData["PromotionPrice"].ToString(), iDecimalNum); //轉換 組成貨幣顯示文字
        #endregion

        BLL.LimitShoppingCartQuantity(txtQty, decimal.Parse(rowData["Price"].ToString())); //限制加入Shopping Cart的數量
    }


    //Ice Bucket按鈕
    protected void btnIceBucket_Click(object sender, EventArgs e)
    {
        //資料參數 (傳至商業邏輯層處理)
        Hashtable htParams = new Hashtable();
        htParams.Add("CatalogItemID", CatalogItemID);
        htParams.Add("CampaignID", CampaignID);
        htParams.Add("CatNo", CatNo);
        htParams.Add("Qty", txtQty.Text.Trim());

        bool bResult = false;
        string strMessage = "";
        BLL.AddProductToShoppingCart(ref bResult, ref strMessage, htParams);

        if (bResult)
        {
            Response.Redirect("~/WebPage/Member/IceBucket.aspx"); //導向購物車頁面
        }
        else
        {
            lblShoppingMessage.Text = strMessage;
            lblShoppingMessage.Visible = true;
        }
    }


    //Wish List按鈕
    protected void btnWishList_Click(object sender, EventArgs e)
    {
        bool bMemberLogin = MemberInfo.CheckMemberLogin();
        if (bMemberLogin) //檢查會員是否登入
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("MemberID", df.PersonalMemberID);
            htParams.Add("CatalogItemID", CatalogItemID);
            htParams.Add("CampaignID", CampaignID);
            htParams.Add("InsertDate", DateTime.Now);

            //呼叫邏輯層
            bool bResult;
            string strMessage;
            BLL.InsertMemberWishList(out bResult, out strMessage, htParams);

            //判斷執行狀態
            if (bResult)
            {
                Response.Redirect("~/WebPage/Member/WishList.aspx");
            }
            else
            {
                //顯示錯誤訊息
                lblShoppingMessage.Text = strMessage;
                lblShoppingMessage.Visible = true;
            }
        }
        else
        {
            //顯示錯誤訊息
            lblShoppingMessage.Text = "Please Login!";
            lblShoppingMessage.Visible = true;
        }
    }


    //轉換金錢格式
    private string SetMoneyFormat(string strCurrency, string strValue, int iDecimal)
    {
        if (decimal.Parse(strValue) > 0)
        {
            strValue = string.Format(strCurrency + " ${0:N" + iDecimal + "}", decimal.Parse(strValue));
        }
        else
        {
            strValue = " - ";
        }
        return strValue;
    }


    #region 屬性

    //取得與設定CatalogItemID
    private int CatalogItemID
    {
        get { return int.Parse(ViewState["CatalogItemID"].ToString()); }
        set { ViewState.Add("CatalogItemID", value); }
    }

    //取得與設定CatNo
    private string CatNo
    {
        get { return ViewState["CatNo"].ToString(); }
        set { ViewState.Add("CatNo", value); }
    }

    //取得與設定CampaignCode
    private object CampaignID
    {
        get { return ViewState["CampaignID"]; }
        set { ViewState.Add("CampaignID", value); }
    }

    #endregion
}