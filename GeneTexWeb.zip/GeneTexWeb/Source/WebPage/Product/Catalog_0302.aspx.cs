﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class WebPage_Product_Catalog : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CreateProductTypeTree();
        }
    }

    private void CreateProductTypeTree()
    {
        Hashtable htParams = new Hashtable();
        htParams.Add("Type", "ProductType");

        DataTable dtProductType = BLL.GetProductType(htParams);

        TreeNode baseNode = new TreeNode("Product Type", "", "");
        baseNode.SelectAction = TreeNodeSelectAction.None;
        treeProductType.Nodes.Add(baseNode);

        AddNode(dtProductType, treeProductType.Nodes[0], 0);
    }

    private void AddNode(DataTable dtResult, TreeNode node, int sid)
    {
        DataRow[] rowArray = dtResult.Select("s_Id=" + sid);

        foreach (DataRow row in rowArray)
        {
            string strText = row["Name"].ToString();
            string strCode = row["Code"].ToString();

            TreeNode SubNode = new TreeNode(strText, strCode, null);
            node.ChildNodes.Add(SubNode);

            AddNode(dtResult, SubNode, Convert.ToInt32(strID));
        }
    }

    protected void treeProductType_SelectedNodeChanged(object sender, EventArgs e)
    {

    }
}