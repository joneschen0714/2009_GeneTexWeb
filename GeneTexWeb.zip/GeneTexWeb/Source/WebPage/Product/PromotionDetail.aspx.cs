﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using df = Icon.Definition;

public partial class WebPage_Product_PromotionDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataBase db = new DataBase(Icon.Definition.WebConnStr);

        string PromotionID = Request.QueryString["PromotionID"];

		SqlParams param = new SqlParams();
		param.Add("Id", PromotionID);
		
		db.SqlParams = param;
        string strSql = "SELECT Name, [Content] FROM News WHERE Id=@Id";
        db.StrSQL = strSql;
        DataTable dtNews = db.ExecuteDataTable();
        DataRow rowNews = dtNews.Rows[0];

        //設定值
        //lblTitle.Text = rowNews["Name"].ToString();
        //if (lblTitle.Text == "Free trials")
        //{
        //    HyperLink hl = new HyperLink();
        //    hl.CssClass = "a3";
        //    hl.Text = lblTitle.Text;
        //    hl.NavigateUrl = "~/WebPage/Product/Catalog.aspx?Type=HomePromotion&Value=D";
        //    lblTitle.Controls.Add(hl);
        //}
        divContent.InnerHtml = rowNews["Content"].ToString();
    }
}
