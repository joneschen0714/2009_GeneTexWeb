﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Xml;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using System.Globalization;

public partial class WebPage_Product_GoTermMap : System.Web.UI.Page
{
    string strCulture;
    string ImgPath = "~/Images/Images/"; //TreeView圖示路徑
    DataBase db = new DataBase(Icon.Definition.WebConnStr);

    protected void Page_Load(object sender, EventArgs e)
    {
        strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系

        if (!IsPostBack) //第一次進入
        {
            DataBind();
        }
    }


    public new void DataBind()
    {
        string GoTermFileName = ddlGoType.SelectedValue;

        dsGoTerm.DataFile = "~/XmlFile/" + GoTermFileName;
        treeGoTermMap.DataSourceID = "dsGoTerm";
        dsGoTerm.Dispose();
    }


    protected void treeGoTermMap_TreeNodeDataBound(object sender, TreeNodeEventArgs e)
    {
        XmlElement node = (XmlElement)e.Node.DataItem;
        e.Node.Text = node.Attributes["NAME"].Value + " (" + node.Attributes["COUNT"].Value + ")";
        e.Node.NavigateUrl = "Catalog.aspx?Type=GoTerm&Code=" + node.Attributes["GOID"].Value; //連結
    }


    protected void ddlGoType_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataBind();
    }


    protected void Page_Unload(object sender, EventArgs e)
    {
        foreach (Control ctrl in Page.Controls)
            ctrl.Dispose();
        Page.Dispose();
    }
}
