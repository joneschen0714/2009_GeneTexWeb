﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.DataBase;
using Icon.Member;
using Icon.Controls;
using df = Icon.Definition;

public partial class WebPage_Product_ProductDetail : System.Web.UI.Page
{
    public string m_CatNo, m_CatalogItemID, m_CampaignID, m_GeneID, m_isKit;
    private string p_SupplierName;

    protected void Page_Init(object sender, EventArgs e)
    {
        Literal liStyle = new Literal();
        liStyle.Text = "<style>" +
                          "#divProductTab { position:relative; height:26px; }" +
                          "#divProductTab > ul { position:absolute; margin:0; padding:0; list-style:none; }" +
                          ".ProductTab { width:100px; height:26px; background:url(../../Images/Images/Pdetail_tab_gray_.gif) no-repeat; text-align:center; font-weight:bold; float:left; cursor:pointer; padding-top:5px; }" +
                          ".ProductTabActive { width:100px; height:26px; background:url(../../Images/Images/Pdetail_tab_yellow.gif) no-repeat; text-align:center; font-weight:bold; float:left; cursor:pointer; padding-top:5px; }" +
                          ".ProductFieldItem > td, .ProductFieldItem > th { border-bottom:#dea030 1px dashed; padding:3px 0 3px 0; }" +
                          ".ProductFieldItem > th { border-right:Transparent 10px dashed; text-align:left; }" +
                          ".RelatedProductList { list-style:none; padding-left:10px; margin:0; }" +
                          ".RelatedProductList > li { padding:3px 0 3px 0; }" +
                       "</style>";
        Page.Header.Controls.Add(liStyle);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        m_CatNo = BLL.GetCatNo(Setting.CheckQueryString("CatNo"), Setting.CheckQueryString("CatalogItemID"));
        m_CatalogItemID = BLL.GetCatalogItemID(Setting.CheckQueryString("CatNo"), Setting.CheckQueryString("CatalogItemID")).ToString();
        m_CampaignID = Request.QueryString["CampaignID"];
        m_isKit = Setting.CheckQueryString("isKit");

        if (!IsPostBack)
        {
            CreateDataSheet();
            CreateProductKit();
            CreateBioInformation();
            CreateRelatedProducts();
            CreateReference();
        }
    }

    private void CreateDataSheet()
    {
        string strContentID = "DataSheet";
        SetTabItem(strContentID);

        DataTable dt = BLL.GetProductDetail(m_CatalogItemID); //呼叫邏輯層 (取得產品資訊)
        DataRow row = dt.Rows[0];

        BLL.ChangeProductDetailData(row); //轉換產品內容格式及資料
        p_SupplierName = row["SupplierName"].ToString();
        //lblProductName.Text = row["ProductName"].ToString();

        #region 建立DataSheet內容
        string strDataSheetContent = "<table>";
        Hashtable DisplayNameTable = CreateDisplayTable(); //取得產品DisplayName List
        for (int i = 0; i < row.ItemArray.Length; i++) //循序增加欄位資訊
        {
            string strTitle = row.Table.Columns[i].ColumnName;
            string strValue = row[i].ToString();

            if (strValue.Trim() != "") //若不為空值
            {
                if (DisplayNameTable.ContainsKey(strTitle)) //若欄名有在DisplayName表裡
                {
                    string strDisplayName = DisplayNameTable[strTitle].ToString(); //取得Display欄名
                    strDataSheetContent += string.Format("<tr class='ProductFieldItem'><th><nobr>{0}</nobr></th><td>{1}</td></tr>", strDisplayName, strValue);
                }
            }
        }
        strDataSheetContent += "</table>";
        liDataSheet.Text = strDataSheetContent;
        #endregion

        #region 建立ShoppingCart內容
        if (m_isKit != "Y")
        {
            DataTable dtOrderInfo = BLL.GetProductOrderInfo(m_CatalogItemID, m_CampaignID); //呼叫邏輯層 (取得產品購物資訊)

            if (dtOrderInfo.Rows.Count > 0)
            {
                //變數
                DataRow rowData = dtOrderInfo.Rows[0];
                string strPrice = "", strSpecialPrice = "", strAvailability = "";

                #region 設定值
                if (Convert.ToDecimal(rowData["Price"]) == 0) { strPrice = "-"; }
                else { strPrice = Setting.GetCurrencyFormat(rowData["CurrencyName"].ToString(), rowData["Price"], Convert.ToInt32(rowData["DecimalNum"])); }
                if (Convert.ToDecimal(rowData["PromotionPrice"]) == 0) { strSpecialPrice = "-"; }
                else { strSpecialPrice = Setting.GetCurrencyFormat(rowData["CurrencyName"].ToString(), rowData["PromotionPrice"], Convert.ToInt32(rowData["DecimalNum"])); }

                strAvailability = row["SupplierName"].ToString().ToLower() == "iconbio" ? "In Stock" : "";
                #endregion

                liShoppingCartItem.Text += string.Format("<tr class='Row'>" +
                                                            "<td>{0}</td>" +
                                                            "<td>{1}</td>" +
                                                            "<td>{2}</td>" +
                                                            "<td>{3}&nbsp;</td>" +
                                                         "</tr>",
                                                         rowData["Package"],
                                                         strPrice,
                                                         strSpecialPrice,
                                                         strAvailability);
            }
            else
            {
                palShoppingCart.Visible = false;
                palMessage.Visible = true;
                liMessage.Text = "<label style='color:red;'>We apologize. GeneTex, Inc. no longer carries this product. Please check the replacement information on the right column of this page, or please contact us if there are any questions: support@genetex.com.</label><br/><br/><br/>";
            }
        }
        else
        {
            palShoppingCart.Visible = false;
        }
        #endregion

        InsertSearchLog(""); //記錄檢索的記錄

        //Meta Data (給搜尋引擎使用)
        string strMeta = "<meta name=\"keywords\" content=\"CatNo:" + row["CatNo"].ToString() + "\" />" +
                         "<meta name=\"keywords\" content=\"ProductName:" + row["ProductName"].ToString() + "\" />";
        Page.Header.Controls.Add(new LiteralControl(strMeta));

        m_GeneID = row["GeneID"].ToString();
    }
    private void CreateBioInformation()
    {
        DataTable dtBioInformation = BLL.GetBioInformationList(m_CatNo, p_SupplierName);
        if (dtBioInformation != null)
        {
            foreach (DataRow row in dtBioInformation.Rows)
            {
                string strSwissProt = "";
                foreach (string strSwissProtVal in row["SwissProt"].ToString().Split('|'))
                {
                    strSwissProt += (strSwissProt == "" ? "" : ", ")
                                 + string.Format("<a target='_blank' href='http://www.uniprot.org/uniprot/{0}?KeepThis=true&'>{0}</a>", strSwissProtVal);
                }

                liBioInformation.Text += string.Format("<tr class=\"Row\">" +
                                                "<td>{0}</td>" +
                                                "<td><a target='_blank' href='http://www.ncbi.nlm.nih.gov/sites/entrez?db=gene&cmd=search&term={2}&KeepThis=true&'>{1}</a></td>" +
                                                "<td><a target='_blank' href='http://www.ncbi.nlm.nih.gov/sites/entrez?db=gene&cmd=search&term={2}&KeepThis=true&'>{2}</a></td>" +
                                                "<td>{3}</td>" +
                                                "<td>{4}</td>" +
                                                "<td>{5}</td>" +
                                                "<td><a target='_blank' href='http://www.ncbi.nlm.nih.gov/entrez/dispomim.cgi?id={6} '>{6}</a></td>" +
                                             "</tr>",
                                             row["Species"],
                                             row["GeneName"],
                                             row["GeneID"],
                                             row["Isoform"],
                                             row["ProteinAccession"],
                                             strSwissProt,
                                             row["OMIM"]);
            }

            if (dtBioInformation.Rows.Count > 0)
            {
                string strContentID = "BioInformation";
                SetTabItem(strContentID);
            }
        }
    }
    private void CreateRelatedProducts()
    {
        Hashtable htParams = new Hashtable();
        htParams.Add("CatNo", m_CatNo);
        htParams.Add("GeneID", m_GeneID);
        htParams.Add("Research", "");
        htParams.Add("FilterCode", "");

        DataTable dtProductClassRel = new DataTable();
        DataTable dtResearchAreaTable = new DataTable();
        DataTable dtCatalog = BLL.GetListByRelatedProduct(htParams, ref dtProductClassRel, ref dtResearchAreaTable);
        //dtProductClassRel.DefaultView.Sort = "GroupId, Code";
        //DataTable dtProductClassItem = dtProductClassRel.DefaultView.ToTable(true, "Id", "p_Id", "Code", "Type", "Name");

        #region 建立Filter可選擇項目
        //循序讀取Filter主項目
        DataRow[] rowLevel1ItemList = dtProductClassRel.Select("Type='ProductType' AND p_Id=0");
        string strItem = "";
        foreach (DataRow rowLevel1 in rowLevel1ItemList)
        {
            //dtProductClassRel.DefaultView.RowFilter = "Code LIKE '" + rowLevel1["Code"] + "%' AND CatNo <> ''";
            //int iLevel1Count = dtProductClassRel.DefaultView.ToTable(true, "CatNo").Rows.Count;
            int iLevel1Count = Convert.ToInt32(rowLevel1["SubCount"]);
            if (iLevel1Count > 0)
            {
                liClass.Text += string.Format("<li><a href=\"Catalog.aspx?CatNo={4}&GeneID={3}&FilterCode={2}\"> - {0}({1})</a></li>", rowLevel1["Name"], iLevel1Count, rowLevel1["Code"], m_GeneID, m_CatNo);

                DataRow[] rowLevel2ItemList = dtProductClassRel.Select("p_Id=" + rowLevel1["Id"].ToString());
                foreach (DataRow rowLevel2 in rowLevel2ItemList)
                {
                    //int iLevel2Count = dtProductClassRel.Select("Id=" + rowLevel2["Id"].ToString() + " AND CatNo <> ''").Length;
                    int iLevel2Count = Convert.ToInt32(rowLevel2["SubCount"]);
                    if (iLevel2Count > 0)
                    {
                        liClass.Text += string.Format("<li><a href=\"Catalog.aspx?CatNo={4}&GeneID={3}&FilterCode={2}\">　 - {0}({1})</a></li>", rowLevel2["Name"], iLevel2Count, rowLevel2["Code"], m_GeneID, m_CatNo);
                    }
                }
            }
        }

        //組成顯示項目
        if (liClass.Text != "")
        {
            liClass.Text = string.Format("<ul class=\"RelatedProductList\">{0}</ul>", liClass.Text);
            string strContentID = "RelatedProducts";
            SetTabItem(strContentID);
        }
        #endregion
    }
    private void CreateReference()
    {
        //呼叫邏輯層(取得文獻資料)
        DataTable dtRef = BLL.GetProductReference(m_CatNo);

        if (dtRef.Rows.Count > 0)
        {
            string strContentID = "Reference";
            SetTabItem(strContentID);

            #region General文獻資料
            int iNo = 1;
            string strGeneralContent = "";
            DataRow[] rowGeneralArray = dtRef.Select("Type='General'");
            foreach (DataRow rowGeneral in rowGeneralArray)
            {
                strGeneralContent += string.Format("<tr><th>{0}.</th><td>{1}</td></tr>", iNo, rowGeneral["Ref"]);
                iNo++;
            }
            if (strGeneralContent != "") { strGeneralContent = string.Format("<br/><div><label class='fontStyle05'>General References</label><br/><table>{0}</table></div>", strGeneralContent); }
            #endregion

            #region Specific文獻資料
            iNo = 1;
            string strSpecificContent = "";
            DataRow[] rowSpecificArray = dtRef.Select("Type='Specific'");
            foreach (DataRow rowSpecific in rowSpecificArray)
            {
                strSpecificContent += string.Format("<tr><th>{0}.</th><td>{1}</td></tr>", iNo, rowSpecific["Ref"]);
                iNo++;
            }
            if (strSpecificContent != "") { strSpecificContent = string.Format("<br/><div><label class='fontStyle05'>Specific References</label><br/><table>{0}</table></div>", strSpecificContent); }
            #endregion

            liReference.Text = string.Format("{0}{1}", strGeneralContent, strSpecificContent);
        }
    }

    private void CreateProductKit()
    {
        DataTable dtProductKit = BLL.GetProductKitData(m_CatNo);
        if (dtProductKit != null)
        {
            foreach (DataRow row in dtProductKit.Rows)
            {
                string strProductKit = "";
                strProductKit = string.Format("<tr class='Row'>" +
                                                  "<td><a onclick=\"fn_WindowOpen('{3}', 'PrintView', 850, 700); return false;\">{0}</a></td>" +
                                                  "<td>{1}</td>" +
                                                  "<td>{2}</td>" +
                                              "</tr>",
                                              row["CatNo"],
                                              row["ProductName"],
                                              row["Package"],
                                              ResolveUrl("~/WebPage/Product/PrintProduct.aspx?CatNo=" + m_CatNo));

                liProductKit.Text += strProductKit;
            }
        }

        palProductKit.Visible = (liProductKit.Text != "");
    }

    protected void btnIceBucket_Click(object sender, EventArgs e)
    {
        bool bResult = false;
        string strMessage = "";

        //判斷產品是否在購物車重覆
        bResult = BLL.CheckProductExistsShoppingCart(int.Parse(m_CatalogItemID), m_CatNo, ref strMessage);

        if (bResult)
        {
            //驗証數量格式
            int iQty;
            int.TryParse(txtQty.Text.Trim(), out iQty);
            if (iQty <= 0)
            {
                strMessage = "Qty format error!";
                bResult = false;
            }
            if (bResult)
            {
                //判斷產品是否有折扣，及是否有購買上線
                BLL.GetCatalogDiscount(m_CatalogItemID, ref iQty, ref bResult, ref strMessage);

                if (iQty > 0 && bResult)
                {
                    //資料參數 (傳至商業邏輯層處理)
                    Hashtable htParams = new Hashtable();
                    htParams.Add("CatalogItemID", m_CatalogItemID);
                    htParams.Add("Qty", iQty);
                    htParams.Add("CampaignID", m_CampaignID);
                    htParams.Add("CatNo", m_CatNo);
                    //加入購物車
                    BLL.AddProductToShoppingCart(ref bResult, ref strMessage, htParams);

                    string strScript = "<script>location.href='" + ResolveUrl("~/WebPage/Member/IceBucket.aspx") + "';";
                    if (strMessage != "")
                        strScript += "alert('" + strMessage + "')";
                    //導向購物車頁面
                    Page.RegisterClientScriptBlock("New", strScript + "</script>");
                }
                else
                    Page.RegisterClientScriptBlock("New", "<script>alert('" + strMessage + "')</script>");
            }
            else
            {
                lblShoppingMessage.Text = strMessage;
                lblShoppingMessage.Visible = true;
            }
        }
        else
        {
            lblShoppingMessage.Text = strMessage;
            lblShoppingMessage.Visible = true;
        }
    }
    protected void btnWishList_Click(object sender, EventArgs e)
    {
        bool bMemberLogin = MemberInfo.CheckMemberLogin();
        if (bMemberLogin) //檢查會員是否登入
        {
            //資料參數
            Hashtable htParams = new Hashtable();
            htParams.Add("MemberID", df.PersonalMemberID);
            htParams.Add("CatalogItemID", m_CatalogItemID);
            if (m_CampaignID != "")
                htParams.Add("CampaignID", m_CampaignID);
            htParams.Add("InsertDate", DateTime.Now);

            //呼叫邏輯層
            bool bResult;
            string strMessage;
            BLL.InsertMemberWishList(out bResult, out strMessage, htParams);

            //判斷執行狀態
            if (bResult)
            {
                Response.Redirect("~/WebPage/Member/WishList.aspx");
            }
            else
            {
                //顯示錯誤訊息
                lblShoppingMessage.Text = strMessage;
                lblShoppingMessage.Visible = true;
            }
        }
        else
        {
            //顯示錯誤訊息
            lblShoppingMessage.Text = "Please Login!";
            lblShoppingMessage.Visible = true;
        }
    }


    private void SetTabItem(string Text)
    {
        liTab.Text += "<li jTag='" + Text + "' GroupTag='MainTab' class='ProductTab'>" + Text + "</li>　";
    }

    private void InsertSearchLog(string strValue)
    {
        //判斷是否已經看過此CatNo
        bool bContain = df.lstCatalogItemID.Contains(Convert.ToInt32(m_CatalogItemID));
        if (bContain)
            return;
        else
            df.lstCatalogItemID.Add(Convert.ToInt32(m_CatalogItemID));

        //取得使用者IP
        string ClientIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (ClientIP == null || ClientIP == "")
        {
            ClientIP = Request.ServerVariables["REMOTE_ADDR"];
        }

        //過濾IP，濾掉iconbio,本機和genetex
        bool bFilter = BLL.FilterIP(ClientIP);
        if (bFilter)
            return;

        bool bResult = true; //是否有結果

        Hashtable htParams = new Hashtable();
        htParams.Add("IP", ClientIP);
        htParams.Add("Keyword", strValue);
        htParams.Add("IsResult", bResult);
        htParams.Add("Member_ID", df.PersonalMemberID);
        htParams.Add("Type", "Clicked");
        htParams.Add("CatNo", m_CatNo);
        htParams.Add("CatalogItem_ID", m_CatalogItemID);

        bResult = false;
        string strMessage = "";
        BLL.InsertSearchLog(ref bResult, ref strMessage, htParams);
    }

    private Hashtable CreateDisplayTable()
    {
        Hashtable DisplayNameTable = new Hashtable();
        DisplayNameTable.Add("CatNo", "Catalog Number");
        //DisplayNameTable.Add("ProductName", "Product Name");
        DisplayNameTable.Add("FullName", "Full Name");
        DisplayNameTable.Add("Manufacturer_MfgPart", "Manufacturer & Mfg Part#");
        DisplayNameTable.Add("ProductDescription", "Product Description");
        DisplayNameTable.Add("Synonyms", "Synonyms");
        //DisplayNameTable.Add("ProductType", "Product Type");
        DisplayNameTable.Add("Background", "Background");
        DisplayNameTable.Add("Clonality", "Clonality");
        DisplayNameTable.Add("CloneNo", "Clone No");
        DisplayNameTable.Add("Host", "Host");
        DisplayNameTable.Add("Isotype", "Isotype");
        DisplayNameTable.Add("LigChain", "Lig Chain");
        DisplayNameTable.Add("Immunogen", "Immunogen");
        DisplayNameTable.Add("AntigenSpecies", "Antigen Species");
        DisplayNameTable.Add("TestedApplications", "Tested Applications");
        DisplayNameTable.Add("ApplicationNote", "Application Note");
        DisplayNameTable.Add("Specificity", "Specificity");
        //DisplayNameTable.Add("ApplicationAbbrev", "Application Abbrev");
        DisplayNameTable.Add("SpeciesCrossReactivity", "Species Cross Reactivity");
        DisplayNameTable.Add("PositiveControls", "Positive Controls");
        DisplayNameTable.Add("Target", "Target");
        DisplayNameTable.Add("PredictedTargetSize", "Predicted Target Size(KDa)");
        DisplayNameTable.Add("CellularLocalization", "Cellular Localization");
        DisplayNameTable.Add("Conjugation", "Conjugation");
        DisplayNameTable.Add("ConjuationNote", "Conjuation Note");
        DisplayNameTable.Add("FormSupplied", "Form Supplied");
        DisplayNameTable.Add("Conc", "Concentration");
        DisplayNameTable.Add("Purification", "Purification");
        DisplayNameTable.Add("PurificationNote", "Purification Note");
        DisplayNameTable.Add("StorageBuffer", "Storage Buffer");
        DisplayNameTable.Add("StorageInstruction", "Storage Instruction");
        DisplayNameTable.Add("Notes", "Notes");
        return DisplayNameTable;
    }
}