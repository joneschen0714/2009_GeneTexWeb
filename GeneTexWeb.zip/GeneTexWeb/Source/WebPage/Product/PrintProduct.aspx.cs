﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.DataBase;

public partial class PrintProduct : System.Web.UI.Page
{
    Hashtable DisplayNameTable;

    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css & Script
        Page.Header.Controls.Add(new LiteralControl("<link type='text/css' rel='stylesheet' href='" + ResolveClientUrl("~/Css/css.css") + "' />"));

        reptProductAttachment.ItemDataBound += new RepeaterItemEventHandler(reptProductAttachment_ItemDataBound);
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        //設定ViewState變數
        if (!IsPostBack)
        {
            CatNo = BLL.GetCatNo(Request.QueryString["CatNo"], Request.QueryString["CatalogItemID"]);
            CatalogItemID = BLL.GetCatalogItemID(Request.QueryString["CatNo"], Request.QueryString["CatalogItemID"]);
            CampaignID = Request.QueryString["CampaignID"];

            if (CatNo != null && CatNo != "")
            {
                DataBind();
            }
        }

        CreateDisplayTable();
        SetProductInfo(); //建立產品欄位資訊
    }

    //建立DisplayName資料
    private void CreateDisplayTable()
    {
        DisplayNameTable = new Hashtable();
        DisplayNameTable.Add("CatNo", "Catalog Number");
        //DisplayNameTable.Add("ProductName", "Product Name");
        DisplayNameTable.Add("ProductDescription", "Product Description");
        DisplayNameTable.Add("Synonyms", "Synonyms");
        //DisplayNameTable.Add("ProductType", "Product Type");
        DisplayNameTable.Add("Background", "Background");
        DisplayNameTable.Add("Clonality", "Clonality");
        DisplayNameTable.Add("CloneNo", "Clone No");
        DisplayNameTable.Add("Host", "Host");
        DisplayNameTable.Add("Isotype", "Isotype");
        DisplayNameTable.Add("LigChain", "Lig Chain");
        DisplayNameTable.Add("Immunogen", "Immunogen");
        DisplayNameTable.Add("AntigenSpecies", "Antigen Species");
        DisplayNameTable.Add("TestedApplications", "Tested Applications");
        DisplayNameTable.Add("ApplicationNote", "Application Note");
        DisplayNameTable.Add("Specificity", "Specificity");
        DisplayNameTable.Add("SpeciesCrossReactivity", "Species Cross Reactivity");
        DisplayNameTable.Add("PositiveControls", "Positive Controls");
        DisplayNameTable.Add("Target", "Target");
        DisplayNameTable.Add("CellularLocalization", "Cellular Localization");
        DisplayNameTable.Add("Conjugation", "Conjugation");
        DisplayNameTable.Add("ConjuationNote", "Conjuation Note");
        DisplayNameTable.Add("FormSupplied", "Form Supplied");
        DisplayNameTable.Add("Conc", "Concentration");
        DisplayNameTable.Add("Purification", "Purification");
        DisplayNameTable.Add("PurificationNote", "Purification Note");
        DisplayNameTable.Add("StorageBuffer", "Storage Buffer");
        DisplayNameTable.Add("StorageInstruction", "Storage Instruction");
        DisplayNameTable.Add("General References", "General References:"); //參考資料
    }

    //設定產品資訊
    private void SetProductInfo()
    {
        DataRow row = BLL.GetProductDetail(CatalogItemID).Rows[0]; //呼叫邏輯層 (取得產品資訊)

        //循序讀取欄位資訊
        for (int i = 0; i < row.ItemArray.Length; i++)
        {
            string strTitle = row.Table.Columns[i].ColumnName;
            string strValue = row[i].ToString();
            if (strTitle == "ProductName")
                lblProduct.Text = strValue;
            else
                AddProductInfo(strTitle, strValue);
        }
    }

    //增加欄位資訊
    private void AddProductInfo(string Title, string Value)
    {
        if (Value.Trim() != "") //若不為空值
        {
            string strDisplayName = "";
            if (DisplayNameTable.ContainsKey(Title)) //若欄名有在DisplayName表裡
            {
                strDisplayName = DisplayNameTable[Title].ToString(); //取得Display欄名

                //宣告Table相關物件
                TableRow row = new TableRow();
                TableHeaderCell HeadCell = new TableHeaderCell();
                TableCell cellData = new TableCell();

                HeadCell.Height = 20;
                HeadCell.CssClass = "BottomLineStyle1";
                cellData.CssClass = "BottomLineStyle1";

                //設定Cell資料
                HeadCell.Text = "<nobr>" + strDisplayName + "</nobr>";
                cellData.Text = Value;

                //增加Row至Table
                row.Cells.Add(HeadCell);
                row.Cells.Add(cellData);
                tableProductInfo.Rows.Add(row);
            }
        }
    }

    public override void DataBind()
    {
        DataBase db = new DataBase(Icon.Definition.WebConnStr);
        //參數
        SqlParams param = new SqlParams();
        param.Add("CatNo", CatNo, SqlDbType.VarChar);

        //資料欄位
        db.SqlParams = param;
        db.StrSQL = "SELECT Path, Type, Description FROM ProductAttachment WHERE CatNo=@CatNo AND Enabled=1";
        DataTable dt = db.ExecuteDataTable();

        reptProductAttachment.DataSource = dt;
        reptProductAttachment.DataBind();

        CreateReferenceInfo();
    }

    protected void reptProductAttachment_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if ((e.Item.ItemType == ListItemType.Item) || (e.Item.ItemType == ListItemType.AlternatingItem))
        {
            Label lblDescription = (Label)e.Item.FindControl("lblDescription");
            Image Img = (Image)e.Item.FindControl("Img");

            DataRowView rowView = (DataRowView)e.Item.DataItem;
            string strUrl = rowView["Path"].ToString();


            if (rowView["Type"].ToString() == "Image") //Image Type
                Img.ImageUrl = strUrl;

            lblDescription.Text = rowView["Description"].ToString();
        }
    }

    //建立參考文獻List
    private void CreateReferenceInfo()
    {
        //呼叫邏輯層(取得文獻資料)
        DataTable dtRef = BLL.GetProductReference(CatNo);

        //循序讀取General文獻資料列
        int iNo = 1;
        DataRow[] rowGeneralArray = dtRef.Select("Type='General'");
        palGeneralRef.Visible = (rowGeneralArray.Length > 0);
        foreach (DataRow rowGeneral in rowGeneralArray)
        {
            liGeneralRef.Text += string.Format("<tr><th valign='top'>{0}.</th><td>{1}</td></tr>", iNo, rowGeneral["Ref"]);
            iNo++;
        }

        //循序讀取Specific文獻資料列
        iNo = 1;
        DataRow[] rowSpecificArray = dtRef.Select("Type='Specific'");
        palSpecificRef.Visible = (rowSpecificArray.Length > 0);
        foreach (DataRow rowSpecific in rowSpecificArray)
        {
            liSpecificRef.Text += string.Format("<tr><th valign='top'>{0}.</th><td>{1}</td></tr>", iNo, rowSpecific["Ref"]);
            iNo++;
        }
    }

    //取得與設定CatalogItemID
    private int CatalogItemID
    {
        get { return int.Parse(ViewState["CatalogItemID"].ToString()); }
        set { ViewState.Add("CatalogItemID", value); }
    }

    //取得與設定CatNo
    private string CatNo
    {
        get { return ViewState["CatNo"].ToString(); }
        set { ViewState.Add("CatNo", value); }
    }

    //取得與設定CampaignCode
    private object CampaignID
    {
        get { return ViewState["CampaignID"]; }
        set { ViewState.Add("CampaignID", value); }
    }
}
