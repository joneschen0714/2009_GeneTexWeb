﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class WebPage_Product_Message : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strType = Request.QueryString["type"];
        string strVal = Request.QueryString["val"]; //被取代的CatNo
        string strVal1 = Request.QueryString["val1"]; //取代的CatNo

        if (!IsPostBack)
        {
            if (strType == "replaced")
            {
                lblMessage.Text = string.Format("We apologize. GeneTex, Inc. no longer carries {0}.  This product has been replaced by {1}.  Please contact us if there are any questions: support@genetex.com",
                                                strVal,
                                                string.Format("<a href='ProductDetail.aspx?CatNo={0}'>{0}</a>", strVal1));
            }
            else if (strType == "unload")
            {
                lblMessage.Text = string.Format("This product not found.  Please link to <a href='{0}/WebPage/Product/ProductDetail.aspx?CatNo={1}'>{1}</a>.  Please contact us if there are any questions: support@genetex.com",
                                                ResolveUrl("~"),
                                                strVal);
            }
        }
    }
}
