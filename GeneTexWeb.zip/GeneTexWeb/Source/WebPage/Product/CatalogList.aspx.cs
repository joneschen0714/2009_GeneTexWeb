﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class WebPage_CatalogList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable dtCatalogList = BLL.GetAllCatalog();//.DefaultView.ToTable(true, new string[] { "CatalogID", "CatalogName", "ImgSrc", "Description", "NewsType" });
            if (dtCatalogList != null && dtCatalogList.Rows.Count > 0)
            {
                reptCatalogList.DataSource = dtCatalogList;
                reptCatalogList.DataBind();
            }
        }
    }
    protected void reptCatalogList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            //取得控制項
            Label lblImage = (Label)e.Item.FindControl("lblImage");
            Label lblContent = (Label)e.Item.FindControl("lblContent");

            if(rowView["ImgSrc"].ToString() != "")
                lblImage.Text = "<img src=" + ResolveUrl(rowView["ImgSrc"].ToString()) + " />";

            string strTypeLink = "" ;
            string strMore = ResolveUrl("~/WebPage/Product/CatalogDetail.aspx?CatalogID=") + rowView["CatalogID"].ToString();
            string strView = ResolveUrl("~/WebPage/Product/Catalog.aspx?CatalogID=") + rowView["CatalogID"].ToString();

            if (rowView["CampaignID"].ToString() != "")
            {
                strMore += "&CampaignCode=" + rowView["CampaignCode"].ToString();
                strView = ResolveUrl("~/WebPage/Product/Catalog.aspx?CampaignCode=") + rowView["CampaignCode"].ToString();
            }

            if (rowView["NewsType"] is DBNull || rowView["NewsType"].ToString() == "Page")
                strTypeLink = strMore;
            else if (rowView["NewsType"].ToString() == "List")
                strTypeLink = strView;

            lblContent.Text = string.Format("<div class='fontStyle05 a2'><a href=\"{0}\"  class='fontStyle05 a2'>{1}</a></div>{2}<a href=\"{3}\" class='a2'> more >></a><div class='viewList'><a href=\"{4}\"  class='a2'>View List</a></div>",
                                            strTypeLink, rowView["CatalogName"], rowView["Description"], strMore, strView);

        }
    }
}
