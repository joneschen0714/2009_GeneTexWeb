﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;
using Icon.Controls;

public partial class WebPage_Product_BrowseByLetter : System.Web.UI.Page
{
    string m_strPage = "";

    protected void Page_Init(object sender, EventArgs e)
    {
        gvProductList.GridView.RowDataBound += new GridViewRowEventHandler(gvProductList_RowDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        m_strPage = Request.QueryString["page"];
        if (!IsPostBack)
        {
            string strTerm = null;
            if (m_strPage == "literature")
            {
                strTerm = Session["LiteratureTerm"].ToString();
                Session.Remove("LiteratureTerm");
                if (strTerm != null)
                {
					lblProfuct.Text = Resources.Web.sitemap.LiteratureSearchResults_Title + " of \"" + strTerm + "\"";
					gvProductList.Visible = false;
                }
            }
            DataTable dtProducts = null;
            //參數集合
            Hashtable htParams = new Hashtable();
            htParams.Add("Page", m_strPage);
            htParams.Add("Param", strTerm);
            dtProducts = BLL.GetProductsByParam(htParams); //搜尋全部產品
           
            if (dtProducts != null && dtProducts.Rows.Count > 0)
            {
                DataBind(dtProducts);
                dtProducts.Dispose();
            }
        }
    }

    //DataBind
    public void DataBind(DataTable dtProducts)
    {
        gvProductList.Fields.Clear();
        Icon.Controls.myGridView.FieldCollection fc = gvProductList.Fields;

        if (m_strPage == "literature")
        {
			fc.Add("CatNo", "CatNo", true, Unit.Empty, "");
            fc.Add("Reference", "Ref", true, Unit.Empty, "");
            fc.Add("PubMed", "PubMed", true, Unit.Empty, "");

            gvProductList.Property.DataKey = "Id";
        }
        
        gvProductList.DataTable = dtProducts;
		gvProductList.DataBind();
		gvProductList.Visible = true;


        //釋放資源
        dtProducts.Dispose();
        gvProductList.Dispose();
    }

    //Row處理事件
    protected void gvProductList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (m_strPage == null) return;
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //轉成PubMed連結
            TableCell cellPubMed = Tool.GetTableCell(e.Row, "PubMed", false);
            string strTerm = "";

            if (m_strPage == "literature")
            {
				TableCell cellCatNo = Tool.GetTableCell(e.Row, "CatNo", false);

				DataRowView rowView = (DataRowView)e.Row.DataItem;

				HyperLink hl = new HyperLink();
				hl.Text = cellCatNo.Text;
				hl.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + rowView["CatalogItemID"].ToString();
				cellCatNo.Controls.Add(hl);

                //轉成PubMed連結
                if (cellPubMed.Text == null || cellPubMed.Text.Trim() == "") return;
                strTerm = cellPubMed.Text;
                TableCell cellRef = Tool.GetTableCell(e.Row, "Reference", false);
                cellRef.Text = cellRef.Text.TrimStart();
            }

            strTerm = strTerm.Replace("&nbsp;", "");
            if (cellPubMed == null || strTerm == "") return;
            HyperLink hPubMed = new HyperLink();
            hPubMed.Text = "Link";
            hPubMed.NavigateUrl = "javascript:void window.open('http://www.ncbi.nlm.nih.gov/sites/entrez?db=pubmed&cmd=search&term="+ strTerm + "')";

            cellPubMed.Controls.Add(hPubMed);
        }
    }
}
