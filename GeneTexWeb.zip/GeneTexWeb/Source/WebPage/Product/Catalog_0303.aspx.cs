﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using System.Globalization;
using Icon;
using df = Icon.Definition;
using Icon.Controls;
using System.Collections.Generic;
using Icon.Member;

public partial class WebPage_Product_Catalog : System.Web.UI.Page
{
    DataBase db;
    string aType, aCode, aValue, aField;
    string strCulture;

    protected void Page_Init(object sender, EventArgs e)
    {
        gvProductList.GridView.RowDataBound += new GridViewRowEventHandler(gvProductList_RowDataBound);

        //註冊頁面Css
        string strStyle = "<style type='text/css'>" +
                            ".DynamicImageStyle td {border-color:#CCCCCC; border-style:solid; border-width:0px 0px 1px 0px;}" +
                       "</style>";
        Page.Header.Controls.Add(new LiteralControl(strStyle));
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        aType = Request.QueryString["Type"];
        aCode = Request.QueryString["Code"];
        aValue = Request.QueryString["Value"];
        aField = Request.QueryString["Field"];
        string strCatalogType = Request.QueryString["CatalogType"];

        if (!IsPostBack)
        {
            //型錄類型資料
            ddlCatalog.DataSource = BLL.GetAllCatalog().DefaultView.ToTable(true, new string[] { "CatalogName", "CatalogType" });
            ddlCatalog.DataBind();

            if (strCatalogType != null) //找CatalogType
            {
                //若對應不到CatalogType，則隱藏，否則反之
                ListItem li = ddlCatalog.Items.FindByValue(strCatalogType);
                if (li == null) { divCatalog.Visible = false; }
                else { li.Selected = true; }

                DataTable dtPromotion = GetCatalogTable(strCatalogType);
                DataBind(dtPromotion);
            }
            else if (aType == "ProductMap")
            {
                divCatalog.Visible = false;
                SetMapNodeList(aType, aCode);
                DataTable dtMap = GetMapTable("A", aCode);
                DataBind(dtMap);
            }
            else if (aType == "SearchArea")
            {
                divCatalog.Visible = false;
                SetMapNodeList(aType, aCode);
                DataTable dtMap = GetResearchAreaTable(aCode);
                DataBind(dtMap);
            }
            else if (aType == "ProductType")
            {
                divCatalog.Visible = false;
                SetMapNodeList(aType, aCode);
                DataTable dtMap = GetProductTypeTable(aCode);
                DataBind(dtMap);
            }
            else if (aType == "ProductSearch")
            {
                //若值跟欄位都不為空
                divCatalog.Visible = false;
                if (aValue != null)
                {
                    DataTable dtSearch = GetProductSearch(aValue);
                    DataBind(dtSearch);
                }
                else
                {
                    //無資料顯示
                    gvProductList.Visible = false;
                    divSearch.Visible = false;
                    lblMessage.Visible = true;
                    lblMessage.Text = "No search results found.  This product may be available.  Please contact GeneTex at: sales@genetex.com or 1-877-GeneTex";
                }
            }
            else if (aType == "HomePromotion")
            {
                divCatalog.Visible = false;
                ddlCatalog.SelectedValue = aValue;
                DataTable dtPromotion = GetCatalogTable(aValue);
                DataBind(dtPromotion);
            }
            else if (aType == "BrowseByNum")
            {
                divCatalog.Visible = false;
                SetDefault("Product No. 0000", true, false);
                DataTable dtSearch = GetCatalogTable("A");
                DataBind(dtSearch);
            }
            else if (aType == "BrowseByLetter")
            {
                divCatalog.Visible = false;
                SetDefault("Product Name", false, true);
                DataTable dtSearch = GetCatalogTable("A");
                DataBind(dtSearch);
            }
            else if (aType == "AdvancedSearch")
            {
                divCatalog.Visible = false;
                SetDefault("", false, false);
                Hashtable htParams = new Hashtable();
                htParams.Add("Keyword", Session["AS_Keyword"].ToString());
                htParams.Add("MapCode", Session["AS_MapCode"].ToString());
                htParams.Add("CatNo", Session["AS_CatNo"].ToString());
                htParams.Add("Type", Session["AS_Type"].ToString());
                DataTable dtSearch = BLL.GetProductsByAdvanced(htParams);
                DataBind(dtSearch);
                InsertSearchLog(Session["AS_Keyword"].ToString(), dtSearch);

                Session.Remove("AS_Keyword");
                Session.Remove("AS_MapCode");
                Session.Remove("AS_CatNo");
                Session.Remove("AS_Type");
                Session.Remove("AS_ProductMap_Id");
            }
            else
            {
                ddlCatalog_SelectedIndexChanged(sender, e);
            }
        }
        else if (gvProductList.DataTable != null)
        {
            lblMessage.Text = "";
            lblMessage.Visible = false;
        }
        else if (gvProductList.DataTable == null)
        {
            lblMessage.Visible = true;
            lblMessage.Text = "Please try again. Session has expired.";
            return;
        }
    }


    //元件初始設定
    private void SetDefault(string strProfuct, bool bPanelNum, bool bLetter)
    {
        divBrowseByParam.Visible = true;
        lblProduct.Text = strProfuct;
        PanelNum.Visible = bPanelNum;
        PanelLetter.Visible = bLetter;
        gvProductList.Visible = false;
    }


    protected void Link_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        string strParam = lb.ID.Replace("lb", "");

        DataTable dtProducts = null;
        int n;

        if (int.TryParse(strParam, out n))　//數字
        {
            strParam = "GTX" + strParam;
            lblProduct.Text = "Product No. " + strParam + "0000";
        }
        else if (strParam.Length == 1 && char.IsLetter(strParam, 0)) //字母
            lblProduct.Text = "Product Name \"" + strParam + "\"";

        //參數集合
        Hashtable htParams = new Hashtable();
        htParams.Add("ActionType", aType);
        htParams.Add("Type", "A");
        htParams.Add("Value", strParam);

        dtProducts = BLL.GetCatalogProduct(htParams);
        if (dtProducts != null && dtProducts.Rows.Count > 0)
        {
            DataBind(dtProducts);
        }
        else
        {
            gvProductList.GridView.Columns.Clear();
            gvProductList.DataReload();
            gvProductList.Visible = false;
        }
    }


    //DataBind
    public void DataBind(DataTable dtMap)
    {
        gvProductList.Fields.Clear();
        Icon.Controls.myGridView.FieldCollection fc = gvProductList.Fields;
        if (dtMap.Columns.Contains("CatalogName")) { fc.Add("Catalog", "CatalogName", true, Unit.Empty, ""); } //若有CatalogName則顯示
        fc.Add("Product Name", "ProductName", true, Unit.Empty, "");
        fc.Add("CatNo", "CatNo", true, Unit.Empty, "");
        fc.Add("Host", "Host", true, Unit.Empty, "");
        fc.Add("Application", "ApplicationAbbrev", true, Unit.Empty, "");
        //fc.Add("Reactivity", "CrossReactivity", true, Unit.Empty, "");
        fc.Add("Package", "Package", true, Unit.Empty, "");
        fc.Add("Price", "Price", true, Unit.Empty, "");
        fc.Add("Special Price", "PromotionPrice", true, Unit.Empty, "");
        fc.Add("Image", "", false, Unit.Empty, "");
        //fc.Add("Related", "About", true, Unit.Empty, "");
        //fc.Add("PubMed", "", false, Unit.Empty, "");

        dtMap.DefaultView.Sort = "SortNum DESC, ProductName"; //依SortNum反序, ProductName正序
        gvProductList.Property.DataKey = "CatNo"; //設定主鍵
        gvProductList.DataTable = dtMap;

        //移除顯示筆數
        DropDownList ddlRowSize = (DropDownList)gvProductList.FindControl("ddlRowSize");
        ddlRowSize.Width = 50;
        ddlRowSize.Items.Remove("50");
        ddlRowSize.Items.Remove("100");

        if (dtMap != null && dtMap.Rows.Count > 0)
        {
            gvProductList.DataBind();
            gvProductList.Visible = true;
            lblMessage.Text = "";
            lblMessage.Visible = false;
        }
        else
        {
            gvProductList.Visible = false;
            divSearch.Visible = false;
            lblMessage.Visible = true;
            lblMessage.Text = "No search results found.  This product may be available.  Please contact GeneTex at: sales@genetex.com or 1-877-GeneTex";
        }

        //釋放資源
        dtMap.Dispose();
        gvProductList.Dispose();
    }


    //Row處理事件
    protected void gvProductList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            TableCell cellCatNo = Tool.GetTableCell(e.Row, "CatNo", false);
            TableCell cellHost = Tool.GetTableCell(e.Row, "Host", false);
            TableCell cellProductName = Tool.GetTableCell(e.Row, "Product Name", false);
            TableCell cellPrice = Tool.GetTableCell(e.Row, "Price", false);
            TableCell cellSpecialPrice = Tool.GetTableCell(e.Row, "Special Price", false);
            TableCell cellImage = Tool.GetTableCell(e.Row, "Image", false);
            //TableCell cellAbout = Tool.GetTableCell(e.Row, "Related", false);
            //TableCell cellPubMed = Tool.GetTableCell(e.Row, "PubMed", false);//轉成PubMed連結
            DataRowView rowView = (DataRowView)e.Row.DataItem;

            //宣告變數
            string strCatNo = rowView["CatNo"].ToString();
            string strCatalogItemID = rowView["CatalogItemID"].ToString();
            //string strTestedApplications = rowView["ApplicationAbbrev"].ToString();
            string strProductType = rowView["ProductType"].ToString();
            string strCurrencyName = rowView["CurrencyName"].ToString();
            int iDecimalNum = int.Parse(rowView["DecimalNum"].ToString());
            int iImgCount;
            int.TryParse(rowView["ImgCount"].ToString(), out iImgCount);


            //在CatNo欄位加上Replaced標記
            string strReplaced = (rowView["BeReplaced"].ToString() == "True" ? "(R)" : "");
            cellCatNo.Text += string.Format("<label style='color:red;'>{0}</label>", strReplaced);


            //把Product Name轉成連結
            HyperLink hl = new HyperLink();
            hl.Text = cellProductName.Text;
            hl.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + strCatalogItemID;
            cellProductName.Controls.Add(hl);

            //若有FullName，則增加至ProductName下方
            if (rowView["FullName"].ToString().Trim() != "")
            {
                cellProductName.Controls.Add(new LiteralControl("<br />"));
                cellProductName.Controls.Add(new LiteralControl(
                                                string.Format("<label class='Memo1'>({0})</label>",
                                                    rowView["FullName"])));
            }

            /*
            //在Host下加ProductType
            cellHost.Controls.Add(new LiteralControl(cellHost.Text));
            cellHost.Controls.Add(new LiteralControl("<br/>" + strProductType));
            */
              
            /*
            //設定相關產品
            string strRelated = "";
            DataTable dtRelated = BLL.GetProductRelated(strCatNo);
            if (dtRelated.Rows.Count > 0)
            {
                foreach (DataRow rowRelated in dtRelated.Rows)
                {
                    strRelated += string.Format("<br/><a href='ProductDetail.aspx?CatalogItemID={1}'>{0}</a>", rowRelated["RelatedCatNo"], rowRelated["CatalogItemID"]);
                }
                cellAbout.Controls.Add(new LiteralControl(strRelated.Substring(5)));
            }
            */


            //轉換 組成貨幣顯示文字
            cellPrice.Text = SetMoneyFormat(strCurrencyName, cellPrice.Text, iDecimalNum);
            cellSpecialPrice.Text = SetMoneyFormat(strCurrencyName, cellSpecialPrice.Text, iDecimalNum);


            /*
            //得到PubMed查詢字串
            string strTerm = BLL.GetPubMed(rowView["CatNo"].ToString()).Trim();
            if (strTerm == "") return;
            HyperLink hPubMed = new HyperLink();
            hPubMed.Text = "Link";
            hPubMed.NavigateUrl = "javascript:void window.open('http://www.ncbi.nlm.nih.gov/sites/entrez?db=pubmed&cmd=search&term=" + strTerm + "')";
            cellPubMed.Controls.Add(hPubMed);
            */

            //Image顯示
            if (iImgCount > 0)
            {
                Image img = new Image();
                img.ImageUrl = "~/Images/Images/camera.png";
                img.ToolTip = "View Images";
                img.Style.Add("cursor","pointer");
                img.Attributes.Add("onclick", "GetDynamicProductImages('" + strCatNo + "')"); //動態建立產品圖片
                cellImage.Controls.Add(img);
            }
        }
    }


    //取得從ProductMap導過來的資料
    private DataTable GetMapTable(string strType, string strCode)
    {
        Setting.RemoveSessionDataTable(); //清除DataTable Session

        //建立參數
        Hashtable htParams = new Hashtable();
        htParams.Add("ActionType", "ProductMap");
        htParams.Add("Type", "A");
        htParams.Add("Value", "%" + strCode + "%");

        DataTable dt = BLL.GetCatalogProduct(htParams);
        return dt;
    }


    //取得從ResearchArea導過來的資料
    private DataTable GetResearchAreaTable(string code)
    {
        Setting.RemoveSessionDataTable(); //清除DataTable Session

        //建立參數
        Hashtable htParams = new Hashtable();
        htParams.Add("ActionType", "ProductOtherMap");
        htParams.Add("ClassType", "SearchArea");
        htParams.Add("Value", code + "%");

        DataTable dt = BLL.GetCatalogProduct(htParams);
        return dt;
    }


    //取得從ProductType導過來的資料
    private DataTable GetProductTypeTable(string code)
    {
        Setting.RemoveSessionDataTable(); //清除DataTable Session

        //建立參數
        Hashtable htParams = new Hashtable();
        htParams.Add("ActionType", "ProductOtherMap");
        htParams.Add("ClassType", "ProductType");
        htParams.Add("Value", code + "%");

        DataTable dt = BLL.GetCatalogProduct(htParams);
        return dt;
    }


    //取得產品全文檢索的資料
    private DataTable GetProductSearch(string strText)
    {
        Setting.RemoveSessionDataTable(); //清除DataTable Session

        DataTable dt = BLL.GetProductSearchList(strText);
        return dt;
    }


    //Catalog選單切換事件
    protected void ddlCatalog_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strType = ddlCatalog.SelectedValue;

        DataTable dtAllCatalog = BLL.GetAllCatalog();
        dtAllCatalog.DefaultView.RowFilter = "CatalogType='" + strType + "'";
        dtAllCatalog.DefaultView.Sort = "Discount";
        DataTable dtNew = dtAllCatalog.DefaultView.ToTable();

        //若是Campaign，則導向至CampaignList頁面
        if (dtNew.Rows[0]["CampaignID"].ToString() != "")
        {
            Response.Redirect("~/WebPage/Product/Campaign.aspx?CatalogType=" + strType);
        }

        if (dtNew.Rows[0]["FilePath"] != null) //若有下載路徑,則show出來
        {
            lilFilePath.Visible = true;
            lilFilePath.Text = dtNew.Rows[0]["FilePath"].ToString();
        }
        else
            lilFilePath.Visible = false;

        btnReset_Click(new object(), new EventArgs()); //重新設定查詢條件
        DataTable dt = GetCatalogTable(strType);
        DataBind(dt);
    }


    //取得Catalog分類的資料
    private DataTable GetCatalogTable(string strCatalog)
    {
        Setting.RemoveSessionDataTable(); //清除DataTable Session

        //建立參數
        Hashtable htParams = new Hashtable();
        htParams.Add("ActionType", "GetCatalogProduct");
        htParams.Add("Type", strCatalog);

        DataTable dt = BLL.GetCatalogProduct(htParams);
        return dt;
    }

    //記錄檢索的記錄
    private void InsertSearchLog(string Value, DataTable dt)
    {
        //取得使用者IP
        string ClientIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (ClientIP == null || ClientIP == "")
        {
            ClientIP = Request.ServerVariables["REMOTE_ADDR"];
        }

        //過濾IP，濾掉iconbio,本機和genetexc
		//bool bFilter = BLL.FilterIP(ClientIP);
		//if (bFilter)
		//    return;

        bool bResult = (dt.Rows.Count > 0 ? true : false); //是否有結果

        Hashtable htParams = new Hashtable();
        htParams.Add("IP", ClientIP);
        htParams.Add("KeyWord", Value);
        htParams.Add("IsResult", bResult);
        htParams.Add("Member_ID", df.PersonalMemberID);

        if (aType == "AdvancedSearch")
        {
            htParams.Add("Type", "Advanced");
            htParams.Add("CatNo", Session["AS_CatNo"]);
            htParams.Add("ProductMap_ID", Session["AS_ProductMap_Id"]);
        }

        bResult = false;
        string strMessage = "";
        BLL.InsertSearchLog(ref bResult, ref strMessage, htParams);

    }

    //轉換金錢格式
    private string SetMoneyFormat(string strCurrency, string strValue, int iDecimal)
    {
        if (decimal.Parse(strValue) > 0)
        {
            strValue = string.Format(strCurrency + " ${0:N" + iDecimal + "}", decimal.Parse(strValue));
        }
        else
        {
            strValue = " - ";
        }
        return strValue;
    }


    //設定子節點清單
    private void SetMapNodeList(string type, string code)
    {
        //取得Tree分類資料
        DataTable dtNodeList = BLL.GetAllNodeProductMap(type);
        //設定目前節點
        DataRow CurrentRow = dtNodeList.Select("Code='" + code + "'")[0]; //目前節點資料
        lblCurrentTreeNodeName.Text = string.Format("{0} ({1})", CurrentRow["Name"], CurrentRow["Count"]);

        //設定上層節點
        lilParentNode.Text = string.Empty;
        List<string> lstURL = new List<string>(); //做推疊,先找到的後SHOW出來
        GetParentNode(dtNodeList, CurrentRow["s_Id"].ToString(), type, ref lstURL);

        if (lstURL.Count == 0)
        {
            lilParentNode.Text = string.Empty;
            lilParentNode.Visible = false;
        }
        else
        {
            foreach (string strURL in lstURL)
                lilParentNode.Text += strURL;
        }
        lstURL.Clear();
        //設定上層節點
        //DataRow[] ParentRowArray = dtNodeList.Select("Id=" + CurrentRow["s_Id"].ToString());
        //if (ParentRowArray.Length > 0)
        //{
        //    DataRow ParentRow = ParentRowArray[0];
        //    linkParentNode.Text = string.Format("Parent Node : {0} ({1})", ParentRow["Name"], ParentRow["Count"]);
        //    linkParentNode.NavigateUrl = string.Format("Catalog.aspx?Type={0}&Code={1}", type, ParentRow["Code"]);
        //}
        //else
        //{
        //    divParentNode.Visible = false;
        //} 

        //設定子節點
        DataRow[] rowArray = dtNodeList.Select("s_Id=" + CurrentRow["Id"].ToString());
        if (rowArray.Length > 0)
        {
            foreach (DataRow row in rowArray)
            {
                if (row["Count"].ToString() == "0") continue;
                liTreeNode.Text += string.Format("<a href='Catalog.aspx?Type={0}&Code={1}' class='a2'>{2} ({3})</a><br/>", type, row["Code"], row["Name"], row["Count"]);
            }
        }
        divTreeNode.Visible = true;
    }

    //找母節點
    private void GetParentNode(DataTable dtNodeList, string strNode, string type, ref List<string> lstURL)
    {
        DataRow[] ParentRowArray = dtNodeList.Select("Id=" + strNode);

        if (ParentRowArray.Length > 0)
        {
            DataRow ParentRow = ParentRowArray[0];

            string strURL = string.Format("<a href=Catalog.aspx?Type={0}&Code={1} class='a2'>{2}({3})</a>{4}",
                type, ParentRow["Code"], ParentRow["Name"], ParentRow["Count"], "&nbsp;<img src=../../Images/Images/back.png>&nbsp;");

            lstURL.Insert(0, strURL);
            GetParentNode(dtNodeList, ParentRow["s_Id"].ToString(), type, ref lstURL);
        }
    }


    //List進階查詢按鈕事件
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string strWhere = "";

        if (Q_txtProductName.Text.Trim() != "")
            strWhere += (strWhere == "" ? "" : " AND ") + "ProductName LIKE '%" + Q_txtProductName.Text.Trim() + "%'";

        if (Q_txtHost.Text.Trim() != "")
            strWhere += (strWhere == "" ? "" : " AND ") + "Host LIKE '%" + Q_txtHost.Text.Trim() + "%'";

        if (Q_txtCatNo.Text.Trim() != "")
            strWhere += (strWhere == "" ? "" : " AND ") + "CatNo LIKE '%" + Q_txtCatNo.Text.Trim() + "%'";

        //if (Q_txtProductType.Text.Trim() != "")
        //    strWhere += (strWhere == "" ? "" : " AND ") + "ProductType LIKE '%" + Q_txtProductType.Text.Trim() + "%'" + " OR Clonality LIKE '%" + Q_txtProductType.Text.Trim() + "%'";

        if (gvProductList.DataTable != null)
        {

            DataTable dtResult = gvProductList.DataTable;
            dtResult.DefaultView.RowFilter = strWhere;
            gvProductList.DataBind();
        }
    }

    //重新設定查詢條件
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Q_txtProductName.Text = "";
        Q_txtHost.Text = "";
        Q_txtCatNo.Text = "";
        //Q_txtProductType.Text = "";
    }
}