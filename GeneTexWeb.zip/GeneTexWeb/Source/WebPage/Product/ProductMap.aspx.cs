﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using Icon;
using System.Globalization;

public partial class WebPage_Product_ProductMap : System.Web.UI.Page
{
    DataTable dtMap;
    string strCulture, strType;
    string ImgPath = "~/Images/Images/"; //TreeView圖示路徑


    protected void Page_Load(object sender, EventArgs e)
    {
        DataBase db = new DataBase(Icon.Definition.WebConnStr);
        strCulture = CultureInfo.CurrentCulture.Name; //取得目前語系
        strType = Request.QueryString["type"]; //產品分類類型

        if (!IsPostBack)
        {
            //呼叫邏輯層（取得分類資料）
            dtMap = BLL.GetAllNodeProductMap(strType);

            if (strType == "ProductMap")
            {
                CreateBaseNode("Product Map");
                AddNode(treeProductMap.Nodes[0], 0); //建立節點

                //摺疊第一層所有子節點
                foreach (TreeNode node in treeProductMap.Nodes[0].ChildNodes)
                {
                    node.CollapseAll();
                }
            }
            else if (strType == "SearchArea")
            {
                CreateBaseNode("Research Areas");
                AddNode(treeProductMap.Nodes[0], 0); //建立節點

                //摺疊第一層所有子節點
                foreach (TreeNode node in treeProductMap.Nodes[0].ChildNodes)
                {
                    node.CollapseAll();
                }
            }
            else if (strType == "ProductType")
            {
                CreateBaseNode("Product Type");
                AddNode(treeProductMap.Nodes[0], 0); //建立節點

                //摺疊第一層所有子節點
                foreach (TreeNode node in treeProductMap.Nodes[0].ChildNodes)
                {
                    node.CollapseAll();
                }
            }
        }
    }

    //建立主節點
    private void CreateBaseNode(string val)
    {
        TreeNode baseNode = new TreeNode(val, "", "");
        baseNode.SelectAction = TreeNodeSelectAction.None; //取消連結
        treeProductMap.Nodes.Add(baseNode);
    }

    //遞迴 - 建立節點
    private void AddNode(TreeNode node, int sid)
    {
        DataRow[] rowArray = dtMap.Select("s_Id=" + sid); //取得符合s_Id的資料

        foreach (DataRow row in rowArray) //循序讀取資料陣列
        {
            string strID = row["Id"].ToString();
            string strText = row["Name"].ToString();
            string strCode = row["Code"].ToString();
            string strCount = row["Count"].ToString();
            //string strImgName = (sid == 0 ? "link_icon.gif" : "product_menu_icon.gif"); //若為根目錄則為資料夾圖示，否則為頁面圖示

            //跳過計數為0的節點
            if (strCount != "0")
            {
                //TreeNode SubNode = new TreeNode(strText, strCode, ImgPath + strImgName); //新節點
                TreeNode SubNode = new TreeNode(strText, strCode, null); //新節點
                SubNode.NavigateUrl = string.Format("Catalog.aspx?Type={0}&Code={1}", strType, strCode); //連結
                SubNode.Text = SubNode.Text.Insert(0, "&nbsp;");
                SubNode.Text += " (" + strCount + ")"; //計數

                node.ChildNodes.Add(SubNode); //增加節點

                AddNode(SubNode, int.Parse(strID)); //遞迴 - 增加子節點
            }
        }
    }
}
