﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon;

public partial class WebPage_Product_ResearchAreaPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        DataTable dtResearchArea = BLL.GetResearchAreaData();

        foreach (DataRow rowItem in dtResearchArea.Rows)
        {
            liResearchArea.Text += string.Format("<div style='margin :5px 0 0 0;' ><a href=\"{2}\"  class ='a2'>{0}({1})</a></div>",
                                                 rowItem["Value"],
                                                 rowItem["subCount"],
                                                 ResolveClientUrl("~/WebPage/Product/Catalog.aspx?CatalogID="+ rowItem["CatalogID"].ToString() +"&Research=" + rowItem["Id"].ToString()));
        }
    }
}
