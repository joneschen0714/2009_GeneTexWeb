﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Icon.DataBase;
using System.Globalization;
using Icon;
using df = Icon.Definition;
using Icon.Controls;
using System.Collections.Generic;
using Icon.Member;

public partial class WebPage_Product_Campaign : System.Web.UI.Page
{
    public string CampaignID;

    DataBase db;
    string aType, aCode, aValue;
    string strCulture;

    protected void Page_Init(object sender, EventArgs e)
    {
        gvProductList.GridView.RowDataBound += new GridViewRowEventHandler(gvProductList_RowDataBound);

        //註冊頁面Css
        string strStyle = "<style type='text/css'>" +
                            ".DynamicImageStyle td {border-color:#CCCCCC; border-style:solid; border-width:0px 0px 1px 0px;}" +
                       "</style>";
        Page.Header.Controls.Add(new LiteralControl(strStyle));
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string strCatalogType = Request.QueryString["CatalogType"];

        if (!IsPostBack)
        {
            //型錄類型資料
            ddlCatalog.DataSource = BLL.GetAllCatalog().DefaultView.ToTable(true, new string[] { "CatalogName", "CatalogType" });
            ddlCatalog.DataBind();

            if (strCatalogType != "")
            {
                ddlCatalog.SelectedValue = strCatalogType;
                ddlCatalog_SelectedIndexChanged(sender, e);
            }
        }
        else if (gvProductList.DataTable != null)
        {
            lblMessage.Text = "";
            lblMessage.Visible = false;
        }
        else if (gvProductList.DataTable == null)
        {
            lblMessage.Visible = true;
            lblMessage.Text = "Please try again. Session has expired.";
            return;
        }
    }


    //元件初始設定
    private void SetDefault(string strProfuct, bool bPanelNum, bool bLetter)
    {
        gvProductList.Visible = false;
    }


    //DataBind
    public void DataBind(DataTable dtMap)
    {
        gvProductList.Fields.Clear();
        Icon.Controls.myGridView.FieldCollection fc = gvProductList.Fields;
        fc.Add("Product Name", "ProductName", true, Unit.Empty, "");
        fc.Add("CatNo", "CatNo", true, Unit.Empty, "");
        fc.Add("Host", "Host", true, Unit.Empty, "");
        fc.Add("Application", "ApplicationAbbrev", true, Unit.Empty, "");
        //fc.Add("Reactivity", "CrossReactivity", true, Unit.Empty, "");
        fc.Add("Package", "Package", true, Unit.Empty, "");
        fc.Add("Price", "Price", true, Unit.Empty, "");
        fc.Add("Special Price", "PromotionPrice", true, Unit.Empty, "");
        fc.Add("Image", "", false, Unit.Empty, "");
        //fc.Add("Related", "About", true, Unit.Empty, "");
        //fc.Add("PubMed", "", false, Unit.Empty, "");

        dtMap.DefaultView.Sort = "SortNum DESC, ProductName"; //依SortNum反序, ProductName正序
        gvProductList.Property.DataKey = "CatNo"; //設定主鍵
        gvProductList.DataTable = dtMap;

        //移除顯示筆數
        DropDownList ddlRowSize = (DropDownList)gvProductList.FindControl("ddlRowSize");
        ddlRowSize.Width = 50;
        ddlRowSize.Items.Remove("50");
        ddlRowSize.Items.Remove("100");

        if (dtMap != null && dtMap.Rows.Count > 0)
        {
            gvProductList.DataBind();
            gvProductList.Visible = true;
            lblMessage.Text = "";
            lblMessage.Visible = false;
        }
        else
        {
            gvProductList.Visible = false;
            divSearch.Visible = false;
            lblMessage.Visible = true;
            lblMessage.Text = "No search results found.  This product may be available.  Please contact GeneTex at: sales@genetex.com or 1-877-GeneTex";
        }

        //釋放資源
        dtMap.Dispose();
        gvProductList.Dispose();
    }


    //Row處理事件
    protected void gvProductList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            TableCell cellCatNo = Tool.GetTableCell(e.Row, "CatNo", false);
            TableCell cellHost = Tool.GetTableCell(e.Row, "Host", false);
            TableCell cellProductName = Tool.GetTableCell(e.Row, "Product Name", false);
            TableCell cellPrice = Tool.GetTableCell(e.Row, "Price", false);
            TableCell cellSpecialPrice = Tool.GetTableCell(e.Row, "Special Price", false);
            TableCell cellImage = Tool.GetTableCell(e.Row, "Image", false);
            //TableCell cellAbout = Tool.GetTableCell(e.Row, "Related", false);
            //TableCell cellPubMed = Tool.GetTableCell(e.Row, "PubMed", false);//轉成PubMed連結
            DataRowView rowView = (DataRowView)e.Row.DataItem;

            //宣告變數
            string strCatNo = rowView["CatNo"].ToString();
            string strCatalogItemID = rowView["CatalogItemID"].ToString();
            //string strTestedApplications = rowView["ApplicationAbbrev"].ToString();
            string strProductType = rowView["ProductType"].ToString();
            string strCurrencyName = rowView["CurrencyName"].ToString();
            int iDecimalNum = int.Parse(rowView["DecimalNum"].ToString());
            int iImgCount;
            int.TryParse(rowView["ImgCount"].ToString(), out iImgCount);
            string strCampaignID = rowView["CampaignID"].ToString();


            //在CatNo欄位加上Replaced標記
            string strReplaced = (rowView["BeReplaced"].ToString() == "True" ? "(R)" : "");
            cellCatNo.Text += string.Format("<label style='color:red;'>{0}</label>", strReplaced);


            //把Product Name轉成連結
            HyperLink hl = new HyperLink();
            hl.Text = cellProductName.Text;
            hl.NavigateUrl = "~/WebPage/Product/ProductDetail.aspx?CatalogItemID=" + strCatalogItemID + "&CampaignID=" + strCampaignID;
            cellProductName.Controls.Add(hl);

            //若有FullName，則增加至ProductName下方
            if (rowView["FullName"].ToString().Trim() != "")
            {
                cellProductName.Controls.Add(new LiteralControl("<br />"));
                cellProductName.Controls.Add(new LiteralControl(
                                                string.Format("<label class='Memo1'>({0})</label>",
                                                    rowView["FullName"])));
            }

            /*
            //在Host下加ProductType
            cellHost.Controls.Add(new LiteralControl(cellHost.Text));
            cellHost.Controls.Add(new LiteralControl("<br/>" + strProductType));
            */

            /*
            //設定相關產品
            string strRelated = "";
            DataTable dtRelated = BLL.GetProductRelated(strCatNo);
            if (dtRelated.Rows.Count > 0)
            {
                foreach (DataRow rowRelated in dtRelated.Rows)
                {
                    strRelated += string.Format("<br/><a href='ProductDetail.aspx?CatalogItemID={1}'>{0}</a>", rowRelated["RelatedCatNo"], rowRelated["CatalogItemID"]);
                }
                cellAbout.Controls.Add(new LiteralControl(strRelated.Substring(5)));
            }
            */


            //轉換 組成貨幣顯示文字
            cellPrice.Text = SetMoneyFormat(strCurrencyName, cellPrice.Text, iDecimalNum);
            cellSpecialPrice.Text = SetMoneyFormat(strCurrencyName, cellSpecialPrice.Text, iDecimalNum);

            /*
            //得到PubMed查詢字串
            string strTerm = BLL.GetPubMed(rowView["CatNo"].ToString()).Trim();
            if (strTerm == "") return;
            HyperLink hPubMed = new HyperLink();
            hPubMed.Text = "Link";
            hPubMed.NavigateUrl = "javascript:void window.open('http://www.ncbi.nlm.nih.gov/sites/entrez?db=pubmed&cmd=search&term=" + strTerm + "')";
            cellPubMed.Controls.Add(hPubMed);
            */

            //Image顯示
            if (iImgCount > 0)
            {
                Image img = new Image();
                img.ImageUrl = "~/Images/Images/camera.png";
                img.ToolTip = "View Images";
                img.Style.Add("cursor", "pointer");
                img.Attributes.Add("onclick", "GetDynamicProductImages('" + strCatNo + "')"); //動態建立產品圖片
                cellImage.Controls.Add(img);
            }
        }
    }


    //取得Campaign的產品資料
    private DataTable GetCatalogTable(object CampaignID)
    {
        Setting.RemoveSessionDataTable(); //清除DataTable Session
        DataTable dt = BLL.GetCampaignCatalogProduct(CampaignID);
        return dt;
    }


    //Catalog選單切換事件
    protected void ddlCatalog_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strType = ddlCatalog.SelectedValue;

        //挑出目前選擇的資料
        DataTable dtAllCatalog = BLL.GetAllCatalog();
        dtAllCatalog.DefaultView.RowFilter = "CatalogType='" + strType + "'";
        dtAllCatalog.DefaultView.Sort = "Discount";
        DataTable dtNew = dtAllCatalog.DefaultView.ToTable();

        CampaignID = dtNew.Rows[0]["CampaignID"].ToString(); //記錄CampaignID給前台使用

        //若是Catalog，則導向至CatalogList頁面
        if (dtNew.Rows[0]["CampaignID"].ToString() == "")
        {
            Response.Redirect("~/WebPage/Product/Catalog.aspx?CatalogType=" + dtNew.Rows[0]["CatalogType"].ToString());
        }

        //btnReset_Click(new object(), new EventArgs()); //重新設定查詢條件

        if (dtNew.Rows[0]["FilePath"] != null) //若有下載路徑,則show出來
        {
            lilFilePath.Visible = true;
            lilFilePath.Text = dtNew.Rows[0]["FilePath"].ToString();
        }
        else
            lilFilePath.Visible = false;

        DataTable dt = GetCatalogTable(dtNew.Rows[0]["CampaignID"]);
        DataBind(dt);
    }


    //轉換金錢格式
    private string SetMoneyFormat(string strCurrency, string strValue, int iDecimal)
    {
        if (decimal.Parse(strValue) > 0)
        {
            strValue = string.Format(strCurrency + " ${0:N" + iDecimal + "}", decimal.Parse(strValue));
        }
        else
        {
            strValue = " - ";
        }
        return strValue;
    }


    //List進階查詢按鈕事件
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string strWhere = "";

        if (Q_txtProductName.Text.Trim() != "")
            strWhere += (strWhere == "" ? "" : " AND ") + "ProductName LIKE '%" + Q_txtProductName.Text.Trim() + "%'";

        if (Q_txtHost.Text.Trim() != "")
            strWhere += (strWhere == "" ? "" : " AND ") + "Host LIKE '%" + Q_txtHost.Text.Trim() + "%'";

        if (Q_txtCatNo.Text.Trim() != "")
            strWhere += (strWhere == "" ? "" : " AND ") + "CatNo LIKE '%" + Q_txtCatNo.Text.Trim() + "%'";

        //if (Q_txtProductType.Text.Trim() != "")
        //    strWhere += (strWhere == "" ? "" : " AND ") + "ProductType LIKE '%" + Q_txtProductType.Text.Trim() + "%'" + " OR Clonality LIKE '%" + Q_txtProductType.Text.Trim() + "%'";

        if (gvProductList.DataTable != null)
        {

            DataTable dtResult = gvProductList.DataTable;
            dtResult.DefaultView.RowFilter = strWhere;
            gvProductList.DataBind();
        }
    }

    //重新設定查詢條件
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Q_txtProductName.Text = "";
        Q_txtHost.Text = "";
        Q_txtCatNo.Text = "";
        //Q_txtProductType.Text = "";
    }
}